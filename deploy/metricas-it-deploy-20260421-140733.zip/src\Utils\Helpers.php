<?php

use App\Models\Usuario;

/**
 * Obtener usuario actual de sesión
 */
function getCurrentUser() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }

    $usuarioModel = new Usuario();
    return $usuarioModel->findWithRelations($_SESSION['user_id']);
}

/**
 * Verificar si está logueado
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Verificar si es super admin
 */
function isSuperAdmin() {
    $user = getCurrentUser();
    return $user && $user['rol'] === 'super_admin';
}

/**
 * Verificar si es admin de departamento
 */
function isDeptAdmin() {
    $user = getCurrentUser();
    return $user && in_array($user['rol'], ['super_admin', 'dept_admin']);
}

/**
 * Obtener conexión a BD
 */
function getDB() {
    static $db = null;

    if ($db === null) {
        $config = require __DIR__ . '/../../config/database.php';
        $dsn = "mysql:host={$config['host']};dbname={$config['database']};charset={$config['charset']}";
        $db = new PDO($dsn, $config['username'], $config['password'], $config['options']);
    }

    return $db;
}

/**
 * Redirigir
 */
function redirect($url) {
    $config = require __DIR__ . '/../../config/app.php';
    $base_url = $config['base_url'];

    if (strpos($url, 'http') === 0) {
        header('Location: ' . $url);
    } else {
        header('Location: ' . $base_url . $url);
    }
    exit;
}

/**
 * Sanitizar entrada
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Escapar salida HTML
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Generar URL base
 */
function baseUrl($path = '') {
    $config = require __DIR__ . '/../../config/app.php';
    return $config['base_url'] . $path;
}

/**
 * Generar URL de asset
 */
function asset($path) {
    return baseUrl('/public/assets/' . ltrim($path, '/'));
}

/**
 * Debug helper
 */
function dd(...$vars) {
    foreach ($vars as $var) {
        echo '<pre>';
        var_dump($var);
        echo '</pre>';
    }
    die();
}

/**
 * Mostrar mensaje flash
 */
function setFlash($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

/**
 * Obtener y limpiar mensaje flash
 */
function getFlash($type) {
    if (isset($_SESSION['flash'][$type])) {
        $message = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $message;
    }
    return null;
}

/**
 * Formatear fecha
 */
function formatDate($date, $format = 'd/m/Y') {
    if (empty($date)) return '';
    $dt = new DateTime($date);
    return $dt->format($format);
}

/**
 * Formatear número
 */
function formatNumber($number, $decimals = 0) {
    return number_format($number, $decimals, '.', ',');
}

<?php
/**
 * Funciones Helper del Sistema
 */

// ==========================================
// AUTENTICACIÓN
// ==========================================

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }

    // Cargar datos del usuario desde sesión
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'nombre' => $_SESSION['user_nombre'] ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'rol' => $_SESSION['user_rol'] ?? 'viewer',
        'departamento_id' => $_SESSION['user_departamento_id'] ?? null,
        'avatar_icono' => $_SESSION['user_avatar_icono'] ?? null,
        'avatar_color' => $_SESSION['user_avatar_color'] ?? null,
        'tema' => $_SESSION['user_tema'] ?? 'light',
    ];
}

function isDeptAdmin() {
    $user = getCurrentUser();
    return $user && in_array($user['rol'], ['super_admin', 'dept_admin']);
}

function isSuperAdmin() {
    $user = getCurrentUser();
    return $user && $user['rol'] === 'super_admin';
}

// ==========================================
// UTILIDADES
// ==========================================

function sanitize($string) {
    return htmlspecialchars(trim($string), ENT_QUOTES, 'UTF-8');
}

function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function baseUrl($path = '') {
    return BASE_URL . $path;
}

function redirect($url) {
    header("Location: " . baseUrl($url));
    exit;
}

// ==========================================
// FLASH MESSAGES
// ==========================================

function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// ==========================================
// VALIDACIÓN
// ==========================================

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

// ==========================================
// FORMATEO
// ==========================================

function formatNumber($number, $decimals = 0) {
    return number_format($number, $decimals, '.', ',');
}

function formatDate($date, $format = 'd/m/Y') {
    if (empty($date)) return '';
    $dt = new DateTime($date);
    return $dt->format($format);
}

function formatDateTime($datetime, $format = 'd/m/Y H:i') {
    if (empty($datetime)) return '';
    $dt = new DateTime($datetime);
    return $dt->format($format);
}
?>

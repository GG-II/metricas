# 📊 Dashboard de Métricas IT - Documentación

Sistema de visualización y gestión de métricas para múltiples áreas de TI con dashboards interactivos, métricas calculadas automáticas y gestión de períodos.

## 🚀 Inicio Rápido

- **URL Producción**: https://siscoop.cicrl.com.gt/metricas-it/
- **Usuario Demo**: admin / Admin123!
- **Base de Datos**: metricas_it_dev

## 📖 Índice de Documentación

### Para Usuarios
- [**Guía de Usuario**](04-guia-usuario.md) - Cómo usar el dashboard y visualizar métricas
- [**Guía de Administrador**](05-guia-administrador.md) - Gestión de métricas, áreas y gráficos

### Para Técnicos/Desarrolladores
- [**Instalación**](01-instalacion.md) - Requisitos e instalación paso a paso
- [**Arquitectura del Sistema**](02-arquitectura.md) - Componentes y flujo de datos
- [**Base de Datos**](03-base-de-datos.md) - Esquema completo y relaciones
- [**Métricas Calculadas**](06-metricas-calculadas.md) - Sistema de cálculo automático
- [**Guía de Desarrollo**](07-desarrollo.md) - Extender funcionalidades y crear gráficos
- [**Despliegue**](08-despliegue.md) - Deploy en AWS IIS
- [**Troubleshooting**](09-troubleshooting.md) - Solución de problemas comunes

## 🎯 Características Principales

### ✅ Dashboards Interactivos
- 9 tipos de gráficos diferentes
- Drag & drop con GridStack
- Auto-guardado de posiciones
- Responsive design

### ✅ Gestión de Métricas
- CRUD completo de métricas
- Captura de valores por período
- Métricas calculadas automáticas
- Histórico de valores

### ✅ Áreas Dinámicas
- Software Factory
- Infraestructura
- Soporte Técnico
- Ciberseguridad
- Medios Digitales

### ✅ Sistema de Períodos
- Gestión por mes/año
- Comparación entre períodos
- Históricos automáticos

### ✅ Métricas Calculadas
- Suma automática de componentes
- Cálculo en tiempo real (JavaScript)
- Sin intervención manual

## 🛠️ Stack Tecnológico

### Backend
- **PHP 8.5.4**
- **MySQL 8.0**
- **PDO** para acceso a datos
- **MVC Pattern**

### Frontend
- **Tabler UI** (Bootstrap 5)
- **GridStack.js** para drag & drop
- **Chart.js** para gráficos
- **Vanilla JavaScript**

### Servidor
- **Windows Server 2016**
- **IIS 10**
- **MySQL80 Service**

## 📊 Tipos de Gráficos Disponibles

1. **KPI Card** - Tarjeta de indicador clave
2. **Progress Bar** - Barra de progreso vs objetivo
3. **Bar Chart** - Gráfico de barras
4. **Line Chart** - Gráfico de líneas
5. **Comparison** - Comparación actual vs anterior
6. **Multi-Bar** - Múltiples métricas en barras
7. **Donut Chart** - Gráfico de dona
8. **Gauge** - Indicador tipo velocímetro
9. **Data Table** - Tabla de datos

## 🔐 Niveles de Acceso

### Usuario Regular
- ✅ Ver dashboards
- ✅ Cambiar área/período
- ❌ No puede editar métricas

### Administrador
- ✅ Todo lo de usuario regular
- ✅ Administrar métricas
- ✅ Configurar gráficos
- ✅ Gestión completa del sistema

## 📂 Estructura del Proyecto

```
metricas-it/
├── admin/                      # Panel de administración
│   ├── metricas.php           # Captura de valores
│   ├── configurar-metricas.php # CRUD métricas
│   └── graficos.php           # CRUD gráficos
├── components/                 # Componentes de gráficos
│   └── charts/                # 9 tipos de gráficos
├── includes/                   # Funciones y utilidades
├── models/                     # Modelos de datos
├── partials/                   # Header, footer, sidebar
├── assets/                     # CSS, JS, imágenes
├── config.php                  # Configuración
└── index.php                   # Dashboard principal
```

## 🔄 Flujo de Trabajo Típico

1. **Configurar Métricas** (Admin)
   - Crear métricas para un área
   - Definir tipo, unidad, objetivo
   - Marcar si es calculada

2. **Capturar Valores** (Admin)
   - Ingresar valores del período
   - Métricas calculadas se suman automáticamente
   - Agregar notas opcionales

3. **Configurar Dashboard** (Admin)
   - Agregar gráficos
   - Asignar métricas a cada gráfico
   - Personalizar colores y títulos

4. **Visualizar** (Todos)
   - Ver dashboard
   - Cambiar área/período
   - Reorganizar gráficos (drag & drop)

## 📞 Soporte y Contacto

- **Repositorio**: (agregar URL)
- **Issues**: (agregar URL)
- **Documentación**: `/docs/`

## 📝 Licencia

(Agregar información de licencia)

---

**Versión del Sistema**: 1.0  
**Última Actualización**: Abril 2026  
**Desarrollado para**: CICRL Guatemala
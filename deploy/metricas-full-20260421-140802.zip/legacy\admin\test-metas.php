<?php
/**
 * Script de prueba del sistema de metas
 * Prueba las funciones principales antes de crear la UI
 */

require_once '../config.php';
require_once '../models/Meta.php';
require_once '../models/Metrica.php';
require_once '../models/ValorMetrica.php';
require_once '../models/Periodo.php';

echo "<h1>Test del Sistema de Metas</h1>";
echo "<pre>";

try {
    $metaModel = new Meta();
    $metricaModel = new Metrica();
    $valorModel = new ValorMetrica();
    $periodoModel = new Periodo();
    
    // ==========================================
    // TEST 1: Crear metas de prueba
    // ==========================================
    echo "==========================================\n";
    echo "TEST 1: Crear metas de prueba\n";
    echo "==========================================\n\n";
    
    $periodo_id = 3; // Marzo 2026
    $area_id = 1; // Software Factory
    
    // Obtener métricas del área
    $metricas = $metricaModel->getByArea($area_id);
    echo "Métricas encontradas en Software Factory: " . count($metricas) . "\n\n";
    
    // Crear meta para "Proyectos finalizados" (mayor_igual)
    $metrica_proyectos = array_filter($metricas, fn($m) => $m['slug'] === 'proyectos_finalizados');
    $metrica_proyectos = reset($metrica_proyectos);
    
    if ($metrica_proyectos) {
        echo "Creando meta para: " . $metrica_proyectos['nombre'] . "\n";
        
        $meta_data = [
            'metrica_id' => $metrica_proyectos['id'],
            'periodo_id' => $periodo_id,
            'valor_objetivo' => 12,
            'tipo_comparacion' => 'mayor_igual',
            'activo' => 1
        ];
        
        $meta_id = $metaModel->createOrUpdate($meta_data);
        echo "✓ Meta creada/actualizada (ID: $meta_id)\n";
        echo "  Objetivo: 12 proyectos (alcanzar o superar)\n\n";
    }
    
    // Crear meta para "Bugs producción" (menor_igual)
    $metrica_bugs = array_filter($metricas, fn($m) => $m['slug'] === 'bugs_produccion');
    $metrica_bugs = reset($metrica_bugs);
    
    if ($metrica_bugs) {
        echo "Creando meta para: " . $metrica_bugs['nombre'] . "\n";
        
        $meta_data = [
            'metrica_id' => $metrica_bugs['id'],
            'periodo_id' => $periodo_id,
            'valor_objetivo' => 5,
            'tipo_comparacion' => 'menor_igual',
            'activo' => 1
        ];
        
        $meta_id = $metaModel->createOrUpdate($meta_data);
        echo "✓ Meta creada/actualizada (ID: $meta_id)\n";
        echo "  Objetivo: 5 bugs (no superar)\n\n";
    }
    
    // ==========================================
    // TEST 2: Obtener metas
    // ==========================================
    echo "==========================================\n";
    echo "TEST 2: Obtener metas por área y período\n";
    echo "==========================================\n\n";
    
    $metas = $metaModel->getByAreaYPeriodo($area_id, $periodo_id);
    echo "Metas encontradas: " . count($metas) . "\n\n";
    
    foreach ($metas as $meta) {
        echo "- {$meta['metrica_nombre']}:\n";
        echo "  Objetivo: {$meta['valor_objetivo']} {$meta['unidad']}\n";
        echo "  Tipo: {$meta['tipo_comparacion']}\n";
        echo "  Calculada: " . ($meta['es_calculada'] ? 'Sí' : 'No') . "\n\n";
    }
    
    // ==========================================
    // TEST 3: Calcular cumplimiento
    // ==========================================
    echo "==========================================\n";
    echo "TEST 3: Calcular cumplimiento de metas\n";
    echo "==========================================\n\n";
    
    if ($metrica_proyectos) {
        echo "Métrica: " . $metrica_proyectos['nombre'] . "\n";
        
        // Obtener valor actual
        $valor_data = $valorModel->getByMetricaYPeriodo($metrica_proyectos['id'], $periodo_id);
        
        if ($valor_data) {
            echo "Valor actual: " . $valor_data['valor'] . "\n";
            
            $meta = $metaModel->getByMetricaYPeriodo($metrica_proyectos['id'], $periodo_id);
            if ($meta) {
                echo "Meta: " . $meta['valor_objetivo'] . "\n";
                
                $cumplimiento = calcularCumplimiento($valor_data['valor'], $meta);
                
                echo "Cumplimiento: " . round($cumplimiento['porcentaje'], 1) . "%\n";
                echo "Estado: " . $cumplimiento['mensaje'] . "\n";
                echo "Cumplido: " . ($cumplimiento['cumplido'] ? '✓ SÍ' : '✗ NO') . "\n\n";
            }
        }
    }
    
    // ==========================================
    // TEST 4: Obtener valor con meta (enriquecido)
    // ==========================================
    echo "==========================================\n";
    echo "TEST 4: Obtener datos enriquecidos\n";
    echo "==========================================\n\n";
    
    if ($metrica_proyectos) {
        $datos_completos = $valorModel->getByMetricaYPeriodoConMeta($metrica_proyectos['id'], $periodo_id);
        
        if ($datos_completos) {
            echo "Métrica: " . $datos_completos['nombre'] . "\n";
            echo "Valor actual: " . $datos_completos['valor'] . " " . $datos_completos['unidad'] . "\n";
            echo "Valor anterior: " . ($datos_completos['valor_anterior'] ?? 'N/A') . "\n";
            echo "Tiene meta: " . ($datos_completos['tiene_meta'] ? 'Sí' : 'No') . "\n";
            
            if ($datos_completos['tiene_meta']) {
                $meta = $datos_completos['meta'];
                $cumplimiento = $meta['cumplimiento'];
                
                echo "\nMeta:\n";
                echo "  Objetivo: " . $meta['valor_objetivo'] . "\n";
                echo "  Tipo: " . $meta['tipo_comparacion'] . "\n";
                echo "\nCumplimiento:\n";
                echo "  Porcentaje: " . round($cumplimiento['porcentaje'], 1) . "%\n";
                echo "  Estado: " . $cumplimiento['mensaje'] . "\n";
                echo "  Cumplido: " . ($cumplimiento['cumplido'] ? '✓ SÍ' : '✗ NO') . "\n";
            }
            echo "\n";
        }
    }
    
    // ==========================================
    // TEST 5: Sugerencia de tipo de meta
    // ==========================================
    echo "==========================================\n";
    echo "TEST 5: Sugerencia automática de tipo\n";
    echo "==========================================\n\n";
    
    $test_slugs = [
        'proyectos_finalizados' => 'mayor_igual',
        'bugs_produccion' => 'menor_igual',
        'cumplimiento_sla' => 'rango',
        'tiempo_resolucion' => 'menor_igual',
        'releases' => 'mayor_igual'
    ];
    
    foreach ($test_slugs as $slug => $esperado) {
        $sugerido = getTipoMetaSugerido($slug);
        $correcto = ($sugerido === $esperado) ? '✓' : '✗';
        echo "$correcto $slug -> $sugerido (esperado: $esperado)\n";
    }
    echo "\n";
    
    // ==========================================
    // TEST 6: Formateo de metas
    // ==========================================
    echo "==========================================\n";
    echo "TEST 6: Formateo de valores de meta\n";
    echo "==========================================\n\n";
    
    $tests_formato = [
        ['valor' => 1500000, 'tipo' => 'decimal', 'unidad' => 'Q', 'esperado' => 'Q 1,500,000.00'],
        ['valor' => 98.5, 'tipo' => 'porcentaje', 'unidad' => '', 'esperado' => '98.50%'],
        ['valor' => 30, 'tipo' => 'tiempo', 'unidad' => 'minutos', 'esperado' => '30 min'],
        ['valor' => 125, 'tipo' => 'tiempo', 'unidad' => 'minutos', 'esperado' => '2h 5min'],
        ['valor' => 42, 'tipo' => 'numero', 'unidad' => 'proyectos', 'esperado' => '42 proyectos']
    ];
    
    foreach ($tests_formato as $test) {
        $resultado = formatearMeta($test['valor'], $test['tipo'], $test['unidad']);
        echo "{$test['tipo']}: {$test['valor']} -> $resultado\n";
    }
    echo "\n";
    
    // ==========================================
    // TEST 7: Copiar metas
    // ==========================================
    echo "==========================================\n";
    echo "TEST 7: Copiar metas entre períodos\n";
    echo "==========================================\n\n";
    
    $periodo_origen = 3; // Marzo
    $periodo_destino = 4; // Abril
    
    echo "Copiando metas de Marzo a Abril...\n";
    $resultado_copia = $metaModel->copiarMetas($periodo_origen, $periodo_destino, $area_id, false);
    
    if ($resultado_copia['success']) {
        echo "✓ Operación exitosa\n";
        echo "  Copiadas: " . $resultado_copia['copiadas'] . "\n";
        echo "  Saltadas: " . $resultado_copia['saltadas'] . "\n";
        echo "  Total: " . $resultado_copia['total'] . "\n\n";
    }
    
    // ==========================================
    // TEST 8: Resumen de cumplimiento
    // ==========================================
    echo "==========================================\n";
    echo "TEST 8: Resumen de cumplimiento del área\n";
    echo "==========================================\n\n";
    
    $resumen = obtenerResumenCumplimientoArea($area_id, $periodo_id);
    
    echo "Software Factory - Marzo 2026:\n";
    echo "  Total metas: " . $resumen['total_metas'] . "\n";
    echo "  Cumplidas: " . $resumen['metas_cumplidas'] . " (" . round($resumen['porcentaje_cumplidas'], 1) . "%)\n";
    echo "  Parciales: " . $resumen['metas_parciales'] . " (" . round($resumen['porcentaje_parciales'], 1) . "%)\n";
    echo "  Incumplidas: " . $resumen['metas_incumplidas'] . " (" . round($resumen['porcentaje_incumplidas'], 1) . "%)\n";
    echo "  Cumplimiento global: " . round($resumen['cumplimiento_global'], 1) . "%\n\n";
    
    // ==========================================
    // TEST 9: Métricas calculadas con metas
    // ==========================================
    echo "==========================================\n";
    echo "TEST 9: Meta calculada (suma de componentes)\n";
    echo "==========================================\n\n";
    
    // Buscar una métrica calculada
    $metricas_calculadas = array_filter($metricas, fn($m) => $m['es_calculada'] == 1);
    
    if (!empty($metricas_calculadas)) {
        $metrica_calc = reset($metricas_calculadas);
        echo "Métrica calculada: " . $metrica_calc['nombre'] . "\n";
        
        // Intentar obtener meta calculada
        $meta_calc = $metaModel->calcularMetaCalculada($metrica_calc['id'], $periodo_id);
        
        if ($meta_calc) {
            echo "✓ Meta calculada automáticamente: " . $meta_calc['valor_objetivo'] . "\n";
            echo "  (Suma de metas de componentes)\n\n";
        } else {
            echo "✗ No se pudo calcular (componentes sin meta)\n\n";
        }
    } else {
        echo "No hay métricas calculadas en esta área\n\n";
    }
    
    // ==========================================
    // TEST 10: Histórico con metas (para burndown)
    // ==========================================
    echo "==========================================\n";
    echo "TEST 10: Histórico con metas (burndown)\n";
    echo "==========================================\n\n";
    
    if ($metrica_proyectos) {
        $historico = $valorModel->getHistoricoConMetas($metrica_proyectos['id'], 6);
        
        echo "Histórico de " . $metrica_proyectos['nombre'] . " (últimos 6 meses):\n\n";
        
        foreach ($historico as $dato) {
            $mes = [
                1 => 'Ene', 2 => 'Feb', 3 => 'Mar', 4 => 'Abr',
                5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Ago',
                9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dic'
            ];
            
            echo $mes[$dato['periodo']] . " " . $dato['ejercicio'] . ": ";
            echo "Valor=" . ($dato['valor'] ?? 'N/A') . ", ";
            echo "Meta=" . ($dato['meta']['valor_objetivo'] ?? 'N/A') . "\n";
        }
        echo "\n";
    }
    
    echo "==========================================\n";
    echo "✓ TODOS LOS TESTS COMPLETADOS\n";
    echo "==========================================\n";
    
} catch (Exception $e) {
    echo "\n\n✗ ERROR: " . $e->getMessage() . "\n";
    echo "Archivo: " . $e->getFile() . "\n";
    echo "Línea: " . $e->getLine() . "\n";
    echo "\nStack trace:\n" . $e->getTraceAsString() . "\n";
}

echo "</pre>";
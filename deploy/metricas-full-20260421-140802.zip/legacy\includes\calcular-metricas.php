<?php
/**
 * Sistema de cálculo automático de métricas calculadas
 */

function calcularMetricasAutomaticas($periodo_id) {
    try {
        // Usar la conexión global
        $db = getDB();
        
        if (!$db) {
            error_log("calcularMetricasAutomaticas: No hay conexión a BD");
            return false;
        }
        
        // Obtener métricas calculadas
        $stmt = $db->prepare("SELECT id FROM metricas WHERE es_calculada = 1 AND activo = 1");
        $stmt->execute();
        $metricas_calculadas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($metricas_calculadas)) {
            error_log("calcularMetricasAutomaticas: No hay métricas calculadas");
            return true; // No es error, simplemente no hay nada que calcular
        }
        
        foreach ($metricas_calculadas as $metrica_calc) {
            try {
                $metrica_id = (int)$metrica_calc['id'];
                
                // Obtener componentes
                $stmt = $db->prepare("
                    SELECT metrica_componente_id 
                    FROM metricas_componentes 
                    WHERE metrica_calculada_id = ? AND activo = 1
                    ORDER BY orden
                ");
                $stmt->execute([$metrica_id]);
                $componentes = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                if (empty($componentes)) {
                    error_log("calcularMetricasAutomaticas: Métrica $metrica_id sin componentes");
                    continue; // Saltar esta métrica, no es error fatal
                }
                
                // Calcular suma
                $placeholders = implode(',', array_fill(0, count($componentes), '?'));
                $params = array_merge($componentes, [(int)$periodo_id]);
                
                $sql = "
                    SELECT COALESCE(SUM(COALESCE(valor_numero, valor_decimal)), 0) as total
                    FROM valores_metricas
                    WHERE metrica_id IN ($placeholders)
                    AND periodo_id = ?
                ";
                
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $valor_calculado = isset($result['total']) ? $result['total'] : 0;
                
                // Guardar o actualizar valor calculado
                $stmt = $db->prepare("
                    INSERT INTO valores_metricas 
                    (metrica_id, periodo_id, valor_numero, usuario_registro_id, fecha_registro)
                    VALUES (?, ?, ?, 1, NOW())
                    ON DUPLICATE KEY UPDATE 
                    valor_numero = VALUES(valor_numero),
                    fecha_actualizacion = NOW()
                ");
                
                $stmt->execute([$metrica_id, (int)$periodo_id, $valor_calculado]);
                
                error_log("calcularMetricasAutomaticas: Métrica $metrica_id = $valor_calculado");
                
            } catch (Exception $e) {
                // Error en una métrica específica, continuar con las demás
                error_log("calcularMetricasAutomaticas: Error en métrica $metrica_id: " . $e->getMessage());
                continue;
            }
        }
        
        return true;
        
    } catch (Exception $e) {
        error_log("calcularMetricasAutomaticas: Error general: " . $e->getMessage());
        error_log("calcularMetricasAutomaticas: Stack trace: " . $e->getTraceAsString());
        return false;
    }
}
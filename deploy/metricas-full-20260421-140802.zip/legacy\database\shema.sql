CREATE DATABASE  IF NOT EXISTS `metricas_it_dev` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `metricas_it_dev`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: metricas_it_dev
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alertas_disparadas`
--

DROP TABLE IF EXISTS `alertas_disparadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alertas_disparadas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `regla_alerta_id` int NOT NULL,
  `metrica_id` int NOT NULL,
  `periodo_id` int NOT NULL,
  `valor_actual` decimal(10,2) DEFAULT NULL,
  `valor_umbral` decimal(10,2) DEFAULT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci,
  `fecha_disparo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `regla_alerta_id` (`regla_alerta_id`),
  KEY `metrica_id` (`metrica_id`),
  KEY `periodo_id` (`periodo_id`),
  CONSTRAINT `alertas_disparadas_ibfk_1` FOREIGN KEY (`regla_alerta_id`) REFERENCES `reglas_alertas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `alertas_disparadas_ibfk_2` FOREIGN KEY (`metrica_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `alertas_disparadas_ibfk_3` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alertas_disparadas`
--

LOCK TABLES `alertas_disparadas` WRITE;
/*!40000 ALTER TABLE `alertas_disparadas` DISABLE KEYS */;
/*!40000 ALTER TABLE `alertas_disparadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `areas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icono` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Clase de FontAwesome',
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Color HEX para temas',
  `orden` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_slug` (`slug`),
  KEY `idx_orden` (`orden`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Áreas del departamento de IT';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas`
--

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES (1,'Software Factory','software-factory','fa-code','#3B82F6',1,'Desarrollo y mantenimiento de software',1,'2026-04-09 15:20:29'),(2,'Infraestructura','infraestructura','fa-server','#10B981',2,'Gestión de servidores e infraestructura tecnológica',1,'2026-04-09 15:20:29'),(3,'Soporte','soporte','fa-headset','#F59E0B',3,'Mesa de ayuda y soporte técnico',1,'2026-04-09 15:20:29'),(4,'Ciberseguridad','ciberseguridad','fa-shield-alt','#EF4444',4,'Seguridad informática y protección de datos',1,'2026-04-09 15:20:29'),(5,'Medios Digitales','','brand-facebook','#e91e63',5,'Transaccionalidad de canales digitales: CIC Virtual, iOS y Android',1,'2026-04-10 16:00:00');
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comentarios_metricas`
--

DROP TABLE IF EXISTS `comentarios_metricas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comentarios_metricas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `metrica_id` int NOT NULL,
  `periodo_id` int NOT NULL,
  `usuario_id` int NOT NULL,
  `comentario` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `periodo_id` (`periodo_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_metrica_periodo` (`metrica_id`,`periodo_id`),
  CONSTRAINT `comentarios_metricas_ibfk_1` FOREIGN KEY (`metrica_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comentarios_metricas_ibfk_2` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comentarios_metricas_ibfk_3` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentarios_metricas`
--

LOCK TABLES `comentarios_metricas` WRITE;
/*!40000 ALTER TABLE `comentarios_metricas` DISABLE KEYS */;
/*!40000 ALTER TABLE `comentarios_metricas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `tipo` enum('texto','numero','boolean','json') COLLATE utf8mb4_unicode_ci DEFAULT 'texto',
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `modificable` tinyint(1) DEFAULT '1',
  `fecha_modificacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`),
  KEY `idx_clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Configuración del sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'nombre_sistema','Dashboard de KPIs - IT','texto','Nombre del sistema',1,NULL),(2,'periodo_actual','2026-4','texto','Período activo actual (formato: año-mes)',1,NULL),(3,'permitir_edicion_historico','1','boolean','¿Permitir editar períodos pasados?',1,NULL),(4,'registros_por_pagina','25','numero','Cantidad de registros por página en tablas',1,NULL),(5,'timezone','America/Guatemala','texto','Zona horaria del sistema',0,NULL),(6,'formato_fecha','d/m/Y','texto','Formato de fecha para visualización',1,NULL);
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_graficos`
--

DROP TABLE IF EXISTS `configuracion_graficos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion_graficos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `area_id` int NOT NULL,
  `titulo` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_general_ci,
  `tipo` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `configuracion` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grid_x` int DEFAULT '0',
  `grid_y` int DEFAULT '0',
  `grid_w` int DEFAULT '6',
  `grid_h` int DEFAULT '4',
  `activo` tinyint(1) DEFAULT '1',
  `permisos_visualizacion` enum('todos','admin') COLLATE utf8mb4_general_ci DEFAULT 'todos',
  `creado_por` int DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_area_activo` (`area_id`,`activo`),
  KEY `idx_area_grid` (`area_id`,`grid_y`,`grid_x`),
  CONSTRAINT `configuracion_graficos_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`),
  CONSTRAINT `configuracion_graficos_ibfk_2` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `configuracion_graficos_chk_1` CHECK (json_valid(`configuracion`))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_graficos`
--

LOCK TABLES `configuracion_graficos` WRITE;
/*!40000 ALTER TABLE `configuracion_graficos` DISABLE KEYS */;
INSERT INTO `configuracion_graficos` VALUES (8,4,'Avance de Políticas SGSI','Muestra el nivel de formalización y unificación de políticas de seguridad de la información.','progress','{\"metrica_id\":22,\"color\":\"#3b82f6\",\"objetivo\":100,\"altura\":40,\"mostrar_valor\":true}',0,0,12,4,1,'todos',1,'2026-04-10 12:47:53','2026-04-10 12:50:38'),(9,4,'Gestión de Identidades por Mes','Cantidad de altas, bajas y cambios de credenciales gestionados por el área.','bar','{\"metrica_id\":23,\"color\":\"#de7017\",\"periodos\":6,\"altura\":300,\"mostrar_valores\":true}',6,4,6,6,1,'todos',1,'2026-04-10 12:48:33','2026-04-10 12:50:46'),(10,4,'Análisis Proactivos','Cantidad de investigaciones y análisis preventivos realizados en el período.','kpi_card','{\"metrica_id\":24,\"color\":\"#3bd8f7\",\"mostrar_comparacion\":true}',0,4,3,6,1,'todos',1,'2026-04-10 12:49:14','2026-04-10 12:50:49'),(11,4,'Activos Críticos Gestionados','Total de sistemas y licencias corporativas bajo gestión directa del área de Ciberseguridad.','kpi_card','{\"metrica_id\":25,\"color\":\"#863bf7\",\"mostrar_comparacion\":true}',3,4,3,6,1,'todos',1,'2026-04-10 12:49:37','2026-04-10 12:50:50'),(12,5,'Transacciones por CIC Virtual','Comparación de volumen de transacciones entre canales digitales.','kpi_card','{\"metrica_id\":51,\"color\":\"#3bf76a\",\"mostrar_comparacion\":true}',0,4,3,4,1,'todos',1,'2026-04-10 12:52:17','2026-04-11 09:39:00'),(13,5,'Transacciones por fri','Comparación de volumen de transacciones entre canales digitales.','kpi_card','{\"metrica_id\":29,\"color\":\"#3be1f7\",\"mostrar_comparacion\":true}',0,0,3,4,1,'todos',1,'2026-04-10 12:52:58','2026-04-10 13:12:37'),(14,5,'Monto Transaccionado por Canal','Comparación del dinero movilizado por cada canal digital.','comparison','{\"metrica_1_id\":50,\"metrica_2_id\":33,\"color_1\":\"#5bd78a\",\"color_2\":\"#3ec7ea\",\"periodos\":6,\"altura\":350,\"mostrar_valores\":true}',6,0,6,7,1,'todos',1,'2026-04-10 12:53:51','2026-04-11 09:38:50'),(15,5,'Transacciones Tarjetas de Débito','Volumen total de transacciones con tarjetas de débito.','kpi_card','{\"metrica_id\":48,\"color\":\"#c08839\",\"mostrar_comparacion\":true}',3,0,3,4,1,'todos',1,'2026-04-10 12:54:28','2026-04-11 09:38:54'),(16,5,'Monto Transaccionado por Tarjetas de Débito',NULL,'bar','{\"metrica_id\":49,\"color\":\"#f7b23b\",\"periodos\":6,\"altura\":300,\"mostrar_valores\":true}',6,7,6,7,1,'todos',1,'2026-04-10 12:55:34','2026-04-11 09:39:32'),(17,3,'Nivel de Servicio (SLA)',NULL,'progress','{\"metrica_id\":17,\"color\":\"#3b82f6\",\"objetivo\":100,\"altura\":40,\"mostrar_valor\":true}',0,0,12,3,1,'todos',1,'2026-04-10 13:02:22','2026-04-10 13:10:28'),(18,3,'Flujo de Tickets',NULL,'comparison','{\"metrica_1_id\":13,\"metrica_2_id\":14,\"color_1\":\"#3b82f6\",\"color_2\":\"#10b981\",\"periodos\":6,\"altura\":350,\"mostrar_valores\":true}',0,3,9,8,1,'todos',1,'2026-04-10 13:02:39','2026-04-10 13:48:34'),(19,3,'Tiempo de Resolución',NULL,'kpi_card','{\"metrica_id\":16,\"color\":\"#3b82f6\",\"mostrar_comparacion\":true}',9,3,3,4,1,'todos',1,'2026-04-10 13:02:57','2026-04-10 13:10:35'),(20,3,'Gestión de Equipos Instalados',NULL,'kpi_card','{\"metrica_id\":19,\"color\":\"#3bf796\",\"mostrar_comparacion\":true}',0,11,6,4,1,'todos',1,'2026-04-10 13:03:23','2026-04-11 09:46:28'),(21,3,'Gestión de Equipos Reparados',NULL,'kpi_card','{\"metrica_id\":18,\"color\":\"#f73b61\",\"mostrar_comparacion\":true}',6,11,6,4,1,'todos',1,'2026-04-10 13:03:45','2026-04-10 13:48:38'),(22,3,'Soporte a Agencias',NULL,'kpi_card','{\"metrica_id\":52,\"color\":\"#61af4b\",\"mostrar_comparacion\":true}',9,7,3,4,1,'todos',1,'2026-04-10 13:04:46','2026-04-11 09:45:37'),(23,1,'Proyectos en Desarrollo',NULL,'comparison','{\"metrica_1_id\":1,\"metrica_2_id\":2,\"color_1\":\"#3b82f6\",\"color_2\":\"#10b981\",\"periodos\":6,\"altura\":350,\"mostrar_valores\":true}',0,0,5,8,1,'todos',1,'2026-04-10 13:05:30','2026-04-10 13:10:11'),(24,1,'Balance de Bugs (Calidad)',NULL,'comparison','{\"metrica_1_id\":5,\"metrica_2_id\":4,\"color_1\":\"#f73b7d\",\"color_2\":\"#10b981\",\"periodos\":6,\"altura\":350,\"mostrar_valores\":true}',5,0,4,8,1,'todos',1,'2026-04-10 13:06:10','2026-04-10 13:10:09'),(25,1,'Releases a Producción',NULL,'kpi_card','{\"metrica_id\":3,\"color\":\"#3b82f6\",\"mostrar_comparacion\":true}',9,0,3,4,1,'todos',1,'2026-04-10 13:06:55','2026-04-10 13:10:01'),(26,1,'Procesos Automatizados',NULL,'kpi_card','{\"metrica_id\":6,\"color\":\"#3b82f6\",\"mostrar_comparacion\":true}',9,4,3,4,1,'todos',1,'2026-04-10 13:07:14','2026-04-10 13:10:00'),(27,2,'Disponibilidad de Sistemas (Uptime)',NULL,'gauge','{\"metrica_id\":7,\"objetivo\":100,\"color_scheme\":\"green\",\"altura\":280,\"subtitulo\":\"\",\"mostrar_porcentaje\":true,\"animar\":true}',4,0,5,7,1,'todos',1,'2026-04-10 13:07:52','2026-04-11 09:41:27'),(28,2,'Gestión de Vulnerabilidades',NULL,'comparison','{\"metrica_1_id\":9,\"metrica_2_id\":10,\"color_1\":\"#ba1717\",\"color_2\":\"#10b981\",\"periodos\":6,\"altura\":350,\"mostrar_valores\":true}',0,0,4,7,1,'todos',1,'2026-04-10 13:08:15','2026-04-11 09:41:16'),(29,2,'Ataques Bloqueados',NULL,'kpi_card','{\"metrica_id\":11,\"color\":\"#bb3096\",\"mostrar_comparacion\":true}',9,4,3,4,1,'todos',1,'2026-04-10 13:08:34','2026-04-11 09:41:25'),(30,2,'Incidentes del Mes',NULL,'kpi_card','{\"metrica_id\":8,\"color\":\"#a72f5f\",\"mostrar_comparacion\":true}',9,0,3,4,1,'todos',1,'2026-04-10 13:08:51','2026-04-11 09:41:23'),(31,5,'Market Share por Canal (Montos)',NULL,'donut','{\"metricas\":[{\"id\":50,\"color\":\"#3b82f6\"},{\"id\":33,\"color\":\"#10b981\"},{\"id\":49,\"color\":\"#f59e0b\"}],\"altura\":350,\"mostrar_porcentaje\":true}',0,8,6,6,1,'todos',1,'2026-04-10 14:20:44','2026-04-11 08:58:27'),(32,5,'Comparativa de Volumen Operativo',NULL,'multi_bar','{\"metricas\":[{\"id\":51,\"color\":\"#3b82f6\"},{\"id\":29,\"color\":\"#10b981\"},{\"id\":48,\"color\":\"#f59e0b\"}],\"periodos\":6,\"altura\":400,\"mostrar_valores\":true}',0,14,6,8,1,'todos',1,'2026-04-10 14:21:38','2026-04-11 09:39:29'),(33,3,'Soporte a Agencias (Total)',NULL,'multi_bar','{\"metricas\":[{\"id\":36,\"color\":\"#3b82f6\"},{\"id\":37,\"color\":\"#10b981\"},{\"id\":38,\"color\":\"#f59e0b\"},{\"id\":20,\"color\":\"#ef4444\"}],\"periodos\":6,\"altura\":400,\"mostrar_valores\":true}',0,15,12,7,1,'todos',1,'2026-04-10 14:29:22','2026-04-10 15:43:28');
/*!40000 ALTER TABLE `configuracion_graficos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_usuario`
--

DROP TABLE IF EXISTS `configuracion_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion_usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `clave` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `fecha_modificacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuario_clave` (`usuario_id`,`clave`),
  CONSTRAINT `configuracion_usuario_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `configuracion_usuario_chk_1` CHECK (json_valid(`valor`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_usuario`
--

LOCK TABLES `configuracion_usuario` WRITE;
/*!40000 ALTER TABLE `configuracion_usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `configuracion_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventos_timeline`
--

DROP TABLE IF EXISTS `eventos_timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eventos_timeline` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `fecha_evento` date NOT NULL,
  `tipo` enum('migración','incidente','mejora','mantenimiento','otro') COLLATE utf8mb4_unicode_ci DEFAULT 'otro',
  `area_id` int DEFAULT NULL,
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_creacion_id` int DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `area_id` (`area_id`),
  KEY `usuario_creacion_id` (`usuario_creacion_id`),
  KEY `idx_fecha` (`fecha_evento`),
  CONSTRAINT `eventos_timeline_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `eventos_timeline_ibfk_2` FOREIGN KEY (`usuario_creacion_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventos_timeline`
--

LOCK TABLES `eventos_timeline` WRITE;
/*!40000 ALTER TABLE `eventos_timeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `eventos_timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_actividad`
--

DROP TABLE IF EXISTS `log_actividad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_actividad` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `accion` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'login, logout, crear_metrica, editar_valor, etc.',
  `tabla_afectada` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registro_id` int DEFAULT NULL COMMENT 'ID del registro afectado',
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_accion` (`accion`),
  KEY `idx_fecha` (`fecha`),
  CONSTRAINT `log_actividad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Log de actividad de usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_actividad`
--

LOCK TABLES `log_actividad` WRITE;
/*!40000 ALTER TABLE `log_actividad` DISABLE KEYS */;
INSERT INTO `log_actividad` VALUES (1,1,'login',NULL,NULL,NULL,'192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 16:00:32'),(2,1,'editar_usuario','usuarios',1,'Editado usuario: admin','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:39:45'),(3,1,'editar_usuario','usuarios',1,'Editado usuario: admin','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:39:51'),(4,1,'actualizar_perfil','usuarios',1,'Perfil actualizado','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:44:06'),(5,1,'actualizar_perfil','usuarios',1,'Perfil actualizado','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:46:56'),(6,1,'actualizar_perfil','usuarios',1,'Perfil actualizado','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:47:10'),(7,1,'actualizar_metricas','valores_metricas',4,'Actualizadas 6 métricas para Software Factory - Abril 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:49:40'),(8,1,'crear_metrica','metricas',21,'Creada métrica: Proyectos fallidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:50:30'),(9,1,'actualizar_metricas','valores_metricas',4,'Actualizadas 7 métricas para Software Factory - Abril 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:50:40'),(10,1,'eliminar_metrica','metricas',21,'Eliminada métrica: Proyectos fallidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 21:51:10'),(11,1,'crear_grafico','configuracion_graficos',1,'Creado gráfico: Proyectos en Desarrollo','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 22:10:35'),(12,1,'eliminar_grafico','configuracion_graficos',1,'Eliminado gráfico: Proyectos en Desarrollo','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 22:10:46'),(13,1,'crear_grafico','configuracion_graficos',2,'Creado gráfico: Proyectos Archivos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 22:50:06'),(14,1,'crear_grafico','configuracion_graficos',3,'Creado gráfico: Bugs corregidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 22:59:38'),(15,1,'crear_grafico','configuracion_graficos',4,'Creado gráfico: Comparación Bugs','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 23:05:06'),(16,1,'editar_grafico','configuracion_graficos',4,'Editado gráfico: Comparación Bugs','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 23:05:14'),(17,1,'eliminar_grafico','configuracion_graficos',2,'Eliminado gráfico: Proyectos Archivos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-09 23:05:20'),(18,1,'editar_usuario','usuarios',1,'Editado usuario: admin','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-10 14:35:53'),(19,1,'login',NULL,NULL,NULL,'192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 14:36:04'),(20,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 14:49:27'),(21,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 14:49:29'),(22,1,'editar_grafico','configuracion_graficos',3,'Editado gráfico: Bugs corregidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 14:50:59'),(23,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 14:51:10'),(24,1,'crear_grafico','configuracion_graficos',5,'Creado gráfico: Proyectos en desarrollo','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 14:54:15'),(25,1,'editar_grafico','configuracion_graficos',3,'Editado gráfico: Bugs corregidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:10:46'),(26,1,'crear_grafico','configuracion_graficos',1,'Creado gráfico: Proyectos Activos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:13:40'),(27,1,'crear_grafico','configuracion_graficos',2,'Creado gráfico: Bugs corregidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:14:22'),(28,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:14:37'),(29,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:14:40'),(30,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:14:42'),(31,1,'eliminar_grafico','configuracion_graficos',2,'Eliminado gráfico: Bugs corregidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:18:52'),(32,1,'eliminar_grafico','configuracion_graficos',1,'Eliminado gráfico: Proyectos Activos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:18:55'),(33,1,'crear_grafico','configuracion_graficos',3,'Creado gráfico: Bugs corregidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:33:51'),(34,1,'crear_grafico','configuracion_graficos',4,'Creado gráfico: Releases','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:34:11'),(35,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:35:25'),(36,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:35:28'),(37,1,'crear_grafico','configuracion_graficos',5,'Creado gráfico: Proyectos activos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:40:49'),(38,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:41:12'),(39,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:42:06'),(40,1,'crear_grafico','configuracion_graficos',6,'Creado gráfico: Proyectos activos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:43:35'),(41,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:52:36'),(42,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:52:37'),(43,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:52:39'),(44,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:52:42'),(45,1,'crear_grafico','configuracion_graficos',7,'Creado gráfico: Proyectos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:54:57'),(46,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 15:55:05'),(47,1,'logout',NULL,NULL,NULL,'192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-10 17:04:06'),(48,1,'editar_usuario','usuarios',1,'Editado usuario: admin','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 17:04:50'),(49,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Medios Digitales - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:45:46'),(50,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 4 métricas para Ciberseguridad - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:46:51'),(51,1,'crear_grafico','configuracion_graficos',8,'Creado gráfico: Avance de Políticas SGSI','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:47:53'),(52,1,'crear_grafico','configuracion_graficos',9,'Creado gráfico: Gestión de Identidades por Mes','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:48:33'),(53,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:48:42'),(54,1,'crear_grafico','configuracion_graficos',10,'Creado gráfico: Análisis Proactivos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:49:14'),(55,1,'crear_grafico','configuracion_graficos',11,'Creado gráfico: Activos Críticos Gestionados','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:49:37'),(56,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 3 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:49:44'),(57,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:49:45'),(58,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:49:50'),(59,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:49:52'),(60,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:49:55'),(61,1,'editar_grafico','configuracion_graficos',8,'Editado gráfico: Avance de Políticas SGSI','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:27'),(62,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:36'),(63,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:38'),(64,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:40'),(65,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:41'),(66,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:43'),(67,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:46'),(68,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:49'),(69,1,'actualizar_layout_dashboard','configuracion_graficos',4,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:50:50'),(70,1,'crear_grafico','configuracion_graficos',12,'Creado gráfico: Transacciones por CIC Virtual','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:52:17'),(71,1,'crear_grafico','configuracion_graficos',13,'Creado gráfico: Transacciones por fri','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:52:58'),(72,1,'crear_grafico','configuracion_graficos',14,'Creado gráfico: Monto Transaccionado por Canal','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:53:51'),(73,1,'crear_grafico','configuracion_graficos',15,'Creado gráfico: Transacciones Tarjetas de Débito','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:54:28'),(74,1,'crear_grafico','configuracion_graficos',16,'Creado gráfico: Monto Transaccionado por Tarjetas de Débito','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:34'),(75,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 5 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:41'),(76,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:44'),(77,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:47'),(78,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:49'),(79,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:52'),(80,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:54'),(81,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:55:58'),(82,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:00'),(83,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:03'),(84,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:05'),(85,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:07'),(86,1,'eliminar_grafico','configuracion_graficos',3,'Eliminado gráfico: Bugs corregidos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:44'),(87,1,'eliminar_grafico','configuracion_graficos',4,'Eliminado gráfico: Releases','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:45'),(88,1,'eliminar_grafico','configuracion_graficos',5,'Eliminado gráfico: Proyectos activos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:47'),(89,1,'eliminar_grafico','configuracion_graficos',6,'Eliminado gráfico: Proyectos activos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:56:49'),(90,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:58:52'),(91,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Infraestructura - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:59:10'),(92,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 8 métricas para Soporte - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 18:59:31'),(93,1,'crear_grafico','configuracion_graficos',17,'Creado gráfico: Nivel de Servicio (SLA)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:02:22'),(94,1,'crear_grafico','configuracion_graficos',18,'Creado gráfico: Flujo de Tickets','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:02:39'),(95,1,'crear_grafico','configuracion_graficos',19,'Creado gráfico: Tiempo de Resolución','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:02:57'),(96,1,'crear_grafico','configuracion_graficos',20,'Creado gráfico: Gestión de Equipos Instalados','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:03:23'),(97,1,'crear_grafico','configuracion_graficos',21,'Creado gráfico: Gestión de Equipos Reparados','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:03:45'),(98,1,'editar_grafico','configuracion_graficos',20,'Editado gráfico: Gestión de Equipos Instalados','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:04:00'),(99,1,'crear_grafico','configuracion_graficos',22,'Creado gráfico: Soporte a Agencias','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:04:46'),(100,1,'eliminar_grafico','configuracion_graficos',7,'Eliminado gráfico: Proyectos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:05:15'),(101,1,'crear_grafico','configuracion_graficos',23,'Creado gráfico: Proyectos en Desarrollo','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:05:30'),(102,1,'editar_grafico','configuracion_graficos',23,'Editado gráfico: Proyectos en Desarrollo','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:05:39'),(103,1,'crear_grafico','configuracion_graficos',24,'Creado gráfico: Balance de Bugs (Calidad)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:06:10'),(104,1,'crear_grafico','configuracion_graficos',25,'Creado gráfico: Releases a Producción','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:06:55'),(105,1,'crear_grafico','configuracion_graficos',26,'Creado gráfico: Procesos Automatizados','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:07:14'),(106,1,'editar_grafico','configuracion_graficos',23,'Editado gráfico: Proyectos en Desarrollo','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:07:26'),(107,1,'crear_grafico','configuracion_graficos',27,'Creado gráfico: Disponibilidad de Sistemas (Uptime)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:07:52'),(108,1,'crear_grafico','configuracion_graficos',28,'Creado gráfico: Gestión de Vulnerabilidades','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:08:15'),(109,1,'crear_grafico','configuracion_graficos',29,'Creado gráfico: Ataques Bloqueados','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:08:34'),(110,1,'crear_grafico','configuracion_graficos',30,'Creado gráfico: Incidentes del Mes','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:08:51'),(111,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:10'),(112,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:12'),(113,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 3 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:16'),(114,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:18'),(115,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:20'),(116,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 2 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:23'),(117,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:27'),(118,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:28'),(119,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:31'),(120,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:50'),(121,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:53'),(122,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:56'),(123,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:09:58'),(124,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:00'),(125,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:01'),(126,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:03'),(127,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:05'),(128,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:07'),(129,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:09'),(130,1,'actualizar_layout_dashboard','configuracion_graficos',1,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:11'),(131,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:28'),(132,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:30'),(133,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:34'),(134,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:35'),(135,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:37'),(136,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:39'),(137,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:40'),(138,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:44'),(139,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:47'),(140,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:51'),(141,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:53'),(142,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:56'),(143,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:10:59'),(144,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:11:02'),(145,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:11:03'),(146,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:11:05'),(147,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:11:06'),(148,1,'editar_grafico','configuracion_graficos',12,'Editado gráfico: Transacciones por CIC Virtual','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:11:52'),(149,1,'editar_grafico','configuracion_graficos',13,'Editado gráfico: Transacciones por fri','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:07'),(150,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:17'),(151,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:20'),(152,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 2 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:23'),(153,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:25'),(154,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:28'),(155,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:29'),(156,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:32'),(157,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:35'),(158,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:12:37'),(159,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:32:45'),(160,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Infraestructura - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:33:29'),(161,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 8 métricas para Soporte - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:40:14'),(162,1,'crear_metrica','metricas',36,'Creada métrica: Soporte Puntos CIC y Agencia Móvil','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:45:22'),(163,1,'crear_metrica','metricas',37,'Creada métrica: Soporte Anexos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:45:44'),(164,1,'crear_metrica','metricas',38,'Creada métrica: Soporte Centro Médico','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:46:03'),(165,1,'crear_metrica','metricas',39,'Creada métrica: Soporte Total','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:46:21'),(166,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 12 métricas para Soporte - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:47:45'),(167,1,'editar_grafico','configuracion_graficos',22,'Editado gráfico: Soporte a Agencias','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:15'),(168,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:28'),(169,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:29'),(170,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 3 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:33'),(171,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:34'),(172,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:36'),(173,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:38'),(174,1,'editar_metrica','metricas',39,'Editada métrica: Soporte Total','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:48:55'),(175,1,'editar_metrica','metricas',36,'Editada métrica: Soporte Puntos CIC y Agencia Móvil','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:53:04'),(176,1,'editar_metrica','metricas',37,'Editada métrica: Soporte Anexos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:53:10'),(177,1,'editar_metrica','metricas',38,'Editada métrica: Soporte Centro Médico','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 19:53:17'),(178,1,'eliminar_metrica','metricas',28,'Eliminada métrica: Transacciones App Android','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:10:10'),(179,1,'eliminar_metrica','metricas',27,'Eliminada métrica: Transacciones App iOS','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:10:17'),(180,1,'eliminar_metrica','metricas',32,'Eliminada métrica: Monto Android','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:10:20'),(181,1,'eliminar_metrica','metricas',31,'Eliminada métrica: Monto iOS','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:10:23'),(182,1,'editar_metrica','metricas',26,'Editada métrica: Transacciones CIC Virtual (Consolidado)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:10:38'),(183,1,'editar_metrica','metricas',30,'Editada métrica: Monto CIC Virtual (Consolidado)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:10:54'),(184,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Medios Digitales - Marzo 2026','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:12:22'),(185,1,'crear_grafico','configuracion_graficos',31,'Creado gráfico: Market Share por Canal (Montos)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:20:44'),(186,1,'crear_grafico','configuracion_graficos',32,'Creado gráfico: Comparativa de Volumen Operativo','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:21:38'),(187,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:22:04'),(188,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:22:06'),(189,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:22:09'),(190,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:22:13'),(191,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:22:15'),(192,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:22:20'),(193,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:22:30'),(194,1,'editar_grafico','configuracion_graficos',14,'Editado gráfico: Monto Transaccionado por Canal','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:25:34'),(195,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:25:51'),(196,1,'crear_grafico','configuracion_graficos',33,'Creado gráfico: Soporte a Agencias (Total)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:29:22'),(197,1,'editar_grafico','configuracion_graficos',33,'Editado gráfico: Soporte a Agencias (Total)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:35:13'),(198,1,'editar_grafico','configuracion_graficos',33,'Editado gráfico: Soporte a Agencias (Total)','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:35:46'),(199,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','192.168.200.150','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 20:35:59'),(200,1,'login',NULL,NULL,NULL,'190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 21:42:24'),(201,1,'logout',NULL,NULL,NULL,'190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 21:42:36'),(202,1,'login',NULL,NULL,NULL,'190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 21:43:02'),(203,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 21:43:17'),(204,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 21:43:26'),(205,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-10 21:43:28'),(206,1,'login',NULL,NULL,NULL,'186.151.10.45','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','2026-04-10 21:44:47'),(207,1,'logout',NULL,NULL,NULL,'186.151.10.45','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','2026-04-10 21:45:52'),(208,1,'login',NULL,NULL,NULL,'181.174.93.80','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','2026-04-10 22:32:42'),(209,1,'logout',NULL,NULL,NULL,'181.174.93.80','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','2026-04-10 22:36:54'),(210,1,'login',NULL,NULL,NULL,'181.174.93.80','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','2026-04-10 23:50:22'),(211,1,'login',NULL,NULL,NULL,'186.151.10.189','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','2026-04-11 01:49:36'),(212,1,'login',NULL,NULL,NULL,'200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:35:38'),(213,1,'crear_metrica','metricas',40,'Creada métrica: Monto Dock','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:39:44'),(214,1,'crear_metrica','metricas',41,'Creada métrica: Transacciones Dock','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:40:58'),(215,1,'editar_metrica','metricas',41,'Editada métrica: Transacciones Dock','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:41:11'),(216,1,'crear_metrica','metricas',42,'Creada métrica: Monto Coitza','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:49:10'),(217,1,'crear_metrica','metricas',43,'Creada métrica: Transacciones Coitza','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:49:46'),(218,1,'editar_metrica','metricas',42,'Editada métrica: Monto Coitza','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:49:54'),(219,1,'crear_metrica','metricas',44,'Creada métrica: Monto CIC Virtual (Operativo)','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:50:44'),(220,1,'crear_metrica','metricas',45,'Creada métrica: Transacciones CIC Virtual (Operativo)','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:51:14'),(221,1,'crear_metrica','metricas',46,'Creada métrica: Monto CIC Virtual (Créditos)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:52:12'),(222,1,'crear_metrica','metricas',47,'Creada métrica: Transacciones CIC Virtual (Créditos)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:52:37'),(223,1,'editar_metrica','metricas',34,'Editada métrica: Transacciones Tarjetas de Débito','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:53:01'),(224,1,'crear_metrica','metricas',48,'Creada métrica: Transacciones Tarjetas de Débito (Dock + Coitza)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:53:59'),(225,1,'crear_metrica','metricas',49,'Creada métrica: Monto Tarjetas de Débito (Dock + Coitza)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:54:44'),(226,1,'crear_metrica','metricas',50,'Creada métrica: Monto CIC Virtual (Operativo + Créditos)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:55:31'),(227,1,'crear_metrica','metricas',51,'Creada métrica: Transacciones CIC Virtual (Operativo + Créditos)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:55:59'),(228,1,'editar_grafico','configuracion_graficos',14,'Editado gráfico: Monto Transaccionado por Canal','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:56:49'),(229,1,'editar_grafico','configuracion_graficos',12,'Editado gráfico: Transacciones por CIC Virtual','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:57:43'),(230,1,'editar_grafico','configuracion_graficos',15,'Editado gráfico: Transacciones Tarjetas de Débito','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:58:00'),(231,1,'editar_grafico','configuracion_graficos',16,'Editado gráfico: Monto Transaccionado por Tarjetas de Débito','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:58:11'),(232,1,'editar_grafico','configuracion_graficos',31,'Editado gráfico: Market Share por Canal (Montos)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:58:27'),(233,1,'editar_grafico','configuracion_graficos',32,'Editado gráfico: Comparativa de Volumen Operativo','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:58:45'),(234,1,'eliminar_metrica','metricas',34,'Eliminada métrica: Transacciones Tarjetas de Débito','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:59:07'),(235,1,'eliminar_metrica','metricas',35,'Eliminada métrica: Monto Tarjetas de Débito','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:59:11'),(236,1,'eliminar_metrica','metricas',26,'Eliminada métrica: Transacciones CIC Virtual (Consolidado)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:59:19'),(237,1,'eliminar_metrica','metricas',30,'Eliminada métrica: Monto CIC Virtual (Consolidado)','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 14:59:23'),(238,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:38:50'),(239,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:38:53'),(240,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:38:54'),(241,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:38:58'),(242,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:39:00'),(243,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:39:23'),(244,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:39:26'),(245,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:39:29'),(246,1,'actualizar_layout_dashboard','configuracion_graficos',5,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:39:32'),(247,1,'editar_grafico','configuracion_graficos',27,'Editado gráfico: Disponibilidad de Sistemas (Uptime)','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:00'),(248,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 2 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:10'),(249,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 3 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:14'),(250,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:16'),(251,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:18'),(252,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:23'),(253,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:25'),(254,1,'actualizar_layout_dashboard','configuracion_graficos',2,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:41:27'),(255,1,'eliminar_metrica','metricas',39,'Eliminada métrica: Soporte Total','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:44:16'),(256,1,'crear_metrica','metricas',52,'Creada métrica: Soporte Total','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:44:52'),(257,1,'editar_grafico','configuracion_graficos',22,'Editado gráfico: Soporte a Agencias','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:45:23'),(258,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:45:35'),(259,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:45:37'),(260,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:45:40'),(261,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:45:43'),(262,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:46:26'),(263,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:46:28'),(264,1,'actualizar_layout_dashboard','configuracion_graficos',3,'Actualizado layout de 1 gráficos','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 15:46:35'),(265,1,'login',NULL,NULL,NULL,'181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:02:10'),(266,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:02:21'),(267,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:02:37'),(268,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:02:52'),(269,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:46:15'),(270,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:46:19'),(271,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:46:24'),(272,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:51:44'),(273,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:51:50'),(274,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:54:34'),(275,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-11 17:54:38'),(276,1,'login',NULL,NULL,NULL,'190.56.173.61','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','2026-04-12 17:29:44'),(277,1,'login',NULL,NULL,NULL,'190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:04:50'),(278,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:05:00'),(279,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:05:40'),(280,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:05:47'),(281,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:05:51'),(282,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:07:27'),(283,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:07:31'),(284,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:08:36'),(285,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:08:56'),(286,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:11:30'),(287,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:11:35'),(288,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:11:44'),(289,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 14:56:10'),(290,1,'login',NULL,NULL,NULL,'190.143.191.105','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','2026-04-13 15:00:18'),(291,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:01:52'),(292,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:01:56'),(293,1,'logout',NULL,NULL,NULL,'190.143.191.105','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','2026-04-13 15:03:41'),(294,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:03:43'),(295,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:03:48'),(296,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Infraestructura - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:03:55'),(297,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Infraestructura - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:04:00'),(298,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:15:32'),(299,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:15:38'),(300,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:18:44'),(301,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:18:54'),(302,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:20:07'),(303,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 6 métricas para Software Factory - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:23:27'),(304,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 14 métricas para Medios Digitales - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:23:50'),(305,1,'actualizar_metricas','valores_metricas',3,'Actualizadas 14 métricas para Medios Digitales - Marzo 2026','190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-13 15:23:58'),(306,1,'login',NULL,NULL,NULL,'181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-14 21:55:34'),(307,1,'login',NULL,NULL,NULL,'200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-04-14 22:12:01'),(308,1,'login',NULL,NULL,NULL,'181.78.107.79','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 14:53:13'),(309,1,'login',NULL,NULL,NULL,'190.143.191.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 18:00:40'),(310,1,'login',NULL,NULL,NULL,'200.114.118.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 18:06:28');
/*!40000 ALTER TABLE `log_actividad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metas_metricas`
--

DROP TABLE IF EXISTS `metas_metricas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metas_metricas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `metrica_id` int NOT NULL,
  `periodo_id` int NOT NULL,
  `valor_objetivo` decimal(10,2) NOT NULL,
  `tipo_comparacion` enum('mayor_igual','menor_igual','igual','rango') COLLATE utf8mb4_unicode_ci DEFAULT 'mayor_igual',
  `valor_min` decimal(10,2) DEFAULT NULL,
  `valor_max` decimal(10,2) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `metrica_id` (`metrica_id`),
  KEY `periodo_id` (`periodo_id`),
  CONSTRAINT `metas_metricas_ibfk_1` FOREIGN KEY (`metrica_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `metas_metricas_ibfk_2` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metas_metricas`
--

LOCK TABLES `metas_metricas` WRITE;
/*!40000 ALTER TABLE `metas_metricas` DISABLE KEYS */;
/*!40000 ALTER TABLE `metas_metricas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metricas`
--

DROP TABLE IF EXISTS `metricas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metricas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `area_id` int NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icono` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'chart-bar',
  `tipo_valor` enum('numero','porcentaje','tiempo','decimal') COLLATE utf8mb4_unicode_ci DEFAULT 'numero',
  `unidad` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'unidades, %, min, hrs, etc.',
  `tipo_grafico` enum('numero','barra','linea','dona','progreso','area') COLLATE utf8mb4_unicode_ci DEFAULT 'numero',
  `mostrar_en_dashboard` tinyint(1) DEFAULT '1',
  `orden` int NOT NULL,
  `grupo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Para agrupar métricas relacionadas',
  `descripcion` text COLLATE utf8mb4_unicode_ci COMMENT 'Explicación de qué mide esta métrica',
  `formula_calculo` text COLLATE utf8mb4_unicode_ci,
  `es_calculada` tinyint(1) DEFAULT '0',
  `permitir_prediccion` tinyint(1) DEFAULT '0',
  `activo` tinyint(1) DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario_creacion_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_area_slug` (`area_id`,`slug`),
  KEY `usuario_creacion_id` (`usuario_creacion_id`),
  KEY `idx_area_orden` (`area_id`,`orden`),
  KEY `idx_activo` (`activo`),
  KEY `idx_mostrar` (`mostrar_en_dashboard`),
  CONSTRAINT `metricas_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `metricas_ibfk_2` FOREIGN KEY (`usuario_creacion_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Definiciones de métricas del sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metricas`
--

LOCK TABLES `metricas` WRITE;
/*!40000 ALTER TABLE `metricas` DISABLE KEYS */;
INSERT INTO `metricas` VALUES (1,1,'Proyectos activos','proyectos_activos','code','numero','proyectos','numero',1,1,'proyectos','Cantidad de proyectos en desarrollo activo',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(2,1,'Proyectos finalizados','proyectos_finalizados','check','numero','proyectos','numero',1,2,'proyectos','Cantidad de proyectos completados en el período',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(3,1,'Releases','releases','rocket','numero','releases','barra',1,3,'desarrollo','Cantidad de versiones liberadas a producción',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(4,1,'Bugs corregidos','bugs_corregidos','bug','numero','bugs','barra',1,4,'calidad','Cantidad de errores corregidos en el período',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(5,1,'Bugs producción','bugs_produccion','alert-triangle','numero','bugs','barra',1,5,'calidad','Cantidad de errores reportados en producción',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(6,1,'Automatizaciones','automatizaciones','robot','numero','procesos','barra',1,6,'desarrollo','Cantidad de procesos automatizados',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(7,2,'Disponibilidad sistemas','disponibilidad_sistemas','chart-bar','decimal','%','numero',1,1,'disponibilidad','Porcentaje de uptime de los sistemas',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(8,2,'Incidentes infraestructura','incidentes_infraestructura','alert-circle','numero','incidentes','barra',1,2,'incidentes','Cantidad de incidentes de infraestructura',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(9,2,'Vulnerabilidades detectadas','vulnerabilidades_detectadas','shield-x','numero','vulnerabilidades','barra',1,3,'seguridad','Vulnerabilidades identificadas en el período',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(10,2,'Vulnerabilidades corregidas','vulnerabilidades_corregidas','shield-check','numero','vulnerabilidades','barra',1,4,'seguridad','Vulnerabilidades mitigadas en el período',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(11,2,'Ataques bloqueados','ataques_bloqueados','shield-lock','numero','ataques','barra',1,5,'seguridad','Intentos de ataque bloqueados',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(12,2,'Mantenimientos','mantenimientos','tool','numero','mantenimientos','barra',1,6,'mantenimiento','Mantenimientos preventivos realizados',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(13,3,'Tickets recibidos','tickets_recibidos','inbox','numero','tickets','numero',1,1,'tickets','Total de solicitudes de soporte recibidas',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(14,3,'Tickets resueltos','tickets_resueltos','circle-check','numero','tickets','numero',1,2,'tickets','Solicitudes resueltas en el período',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(15,3,'Tickets pendientes','tickets_pendientes','clock','numero','tickets','numero',1,3,'tickets','Solicitudes pendientes de resolución',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(16,3,'Tiempo resolución','tiempo_resolucion','chart-bar','numero','minutos','barra',1,4,'rendimiento','Tiempo promedio de resolución en minutos',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(17,3,'Cumplimiento SLA','cumplimiento_sla','chart-bar','decimal','%','numero',1,5,'rendimiento','Porcentaje de cumplimiento de SLA',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(18,3,'Equipos reparados','equipos_reparados','device-desktop','numero','equipos','barra',1,6,'equipamiento','Cantidad de equipos reparados',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(19,3,'Equipos instalados','equipos_instalados','device-desktop-plus','numero','equipos','barra',1,7,'equipamiento','Cantidad de equipos nuevos instalados',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(20,3,'Soporte agencias','soporte_agencias','chart-bar','numero','visitas','barra',1,8,'agencias','Visitas de soporte a agencias',NULL,0,0,1,'2026-04-09 15:20:29',NULL),(22,4,'Cumplimiento de Políticas (SGSI)','cumplimiento_sgsi','shield-check','porcentaje','%','progreso',1,1,'Gobernanza','Nivel de formalización y unificación del Sistema de Gestión de Seguridad de la Información.',NULL,0,0,1,'2026-04-10 23:44:48',NULL),(23,4,'Gestión de Identidades','gestion_identidades','user-check','numero','usuarios o gestiones','barra',1,1,'Operaciones','Cantidad de altas, bajas y cambios de credenciales en Office 365 y sistemas core.',NULL,0,0,1,'2026-04-10 23:45:26',NULL),(24,4,'Análisis Proactivos Realizados','analisis_proactivos','check','numero','análisis','numero',1,1,'Seguridad','Investigaciones y remediaciones de brechas potenciales antes de su explotación.',NULL,0,0,1,'2026-04-10 23:46:29',NULL),(25,4,'Activos Críticos Gestionados','activos_gestionados','server','numero','Número entero','numero',1,1,'Activos','Sistemas y licencias corporativas bajo la administración directa de Ciberseguridad.',NULL,0,0,1,'2026-04-10 23:47:15',NULL),(29,5,'Transacciones Billetera fri','tx_fri','star','numero','tx','barra',1,4,'Canales Digitales','Total de transacciones movilizadas a través de la billetera virtual fri.',NULL,0,0,1,'2026-04-11 00:07:25',NULL),(33,5,'Monto fri','monto_fri','chart-bar','decimal','Q','barra',1,8,'montos','Monto total transaccionado a través de la billetera virtual fri en el período.',NULL,0,0,1,'2026-04-11 00:11:20',NULL),(36,3,'Soporte Puntos CIC y Agencia Móvil','soporte_puntos_cic','chart-bar','numero','visitas','',1,1,'soporte',NULL,NULL,0,0,1,'2026-04-10 19:45:22',NULL),(37,3,'Soporte Anexos','soporte_anexos','chart-bar','numero','visitas','',1,1,'soporte',NULL,NULL,0,0,1,'2026-04-10 19:45:44',NULL),(38,3,'Soporte Centro Médico','soporte_centro_medico','chart-bar','numero','visitas','',1,1,NULL,NULL,NULL,0,0,1,'2026-04-10 19:46:03',NULL),(40,5,'Monto Dock','monto_dock','briefcase','numero','Q','numero',1,1,'montos',NULL,NULL,0,0,1,'2026-04-11 14:39:44',NULL),(41,5,'Transacciones Dock','tx_dock','chart-line','numero','tx','numero',1,1,'transacciones',NULL,NULL,0,0,1,'2026-04-11 14:40:58',NULL),(42,5,'Monto Coitza','monto_coitza','chart-line','decimal','Q','numero',1,1,'montos',NULL,NULL,0,0,1,'2026-04-11 14:49:10',NULL),(43,5,'Transacciones Coitza','tx_coitza','briefcase','numero','tx','numero',1,1,NULL,NULL,NULL,0,0,1,'2026-04-11 14:49:46',NULL),(44,5,'Monto CIC Virtual (Operativo)','monto_cic_operativo','briefcase','decimal','Q','numero',1,1,NULL,NULL,NULL,0,0,1,'2026-04-11 14:50:44',NULL),(45,5,'Transacciones CIC Virtual (Operativo)','tx_cic_operativo','chart-line','numero','tx','numero',1,1,NULL,NULL,NULL,0,0,1,'2026-04-11 14:51:14',NULL),(46,5,'Monto CIC Virtual (Créditos)','monto_cic_creditos','briefcase','decimal','Q','numero',1,1,NULL,NULL,NULL,0,0,1,'2026-04-11 14:52:12',NULL),(47,5,'Transacciones CIC Virtual (Créditos)','tx_cic_creditos','chart-line','numero','tx','numero',1,1,'transacciones',NULL,NULL,0,0,1,'2026-04-11 14:52:37',NULL),(48,5,'Transacciones Tarjetas de Débito (Dock + Coitza)','tx_tarjeta_debito','chart-line','numero','tx','numero',1,1,NULL,NULL,NULL,1,0,1,'2026-04-11 14:53:59',NULL),(49,5,'Monto Tarjetas de Débito (Dock + Coitza)','monto_tarjeta_debito','briefcase','decimal','Q','numero',1,1,'montos',NULL,NULL,1,0,1,'2026-04-11 14:54:44',NULL),(50,5,'Monto CIC Virtual (Operativo + Créditos)','monto_cic','briefcase','decimal','Q','numero',1,1,'montos',NULL,NULL,1,0,1,'2026-04-11 14:55:31',NULL),(51,5,'Transacciones CIC Virtual (Operativo + Créditos)','tx_cic','chart-line','numero','tx','numero',1,1,'transacciones',NULL,NULL,1,0,1,'2026-04-11 14:55:59',NULL),(52,3,'Soporte Total','soporte_total','headset','numero','visitas','numero',1,1,NULL,NULL,NULL,1,0,1,'2026-04-11 15:44:52',NULL);
/*!40000 ALTER TABLE `metricas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metricas_componentes`
--

DROP TABLE IF EXISTS `metricas_componentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metricas_componentes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `metrica_calculada_id` int NOT NULL,
  `metrica_componente_id` int NOT NULL,
  `operacion` enum('suma','resta','multiplicacion','division') COLLATE utf8mb4_unicode_ci DEFAULT 'suma',
  `orden` int DEFAULT '0',
  `activo` tinyint(1) DEFAULT '1',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_componente` (`metrica_calculada_id`,`metrica_componente_id`),
  KEY `idx_calculada` (`metrica_calculada_id`),
  KEY `idx_componente` (`metrica_componente_id`),
  CONSTRAINT `metricas_componentes_ibfk_1` FOREIGN KEY (`metrica_calculada_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `metricas_componentes_ibfk_2` FOREIGN KEY (`metrica_componente_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metricas_componentes`
--

LOCK TABLES `metricas_componentes` WRITE;
/*!40000 ALTER TABLE `metricas_componentes` DISABLE KEYS */;
INSERT INTO `metricas_componentes` VALUES (1,48,41,'suma',0,1,'2026-04-11 14:53:59'),(2,48,43,'suma',1,1,'2026-04-11 14:53:59'),(3,49,40,'suma',0,1,'2026-04-11 14:54:44'),(4,49,42,'suma',1,1,'2026-04-11 14:54:44'),(5,50,44,'suma',0,1,'2026-04-11 14:55:31'),(6,50,46,'suma',1,1,'2026-04-11 14:55:31'),(7,51,45,'suma',0,1,'2026-04-11 14:55:59'),(8,51,47,'suma',1,1,'2026-04-11 14:55:59'),(9,52,36,'suma',0,1,'2026-04-11 15:44:52'),(10,52,37,'suma',1,1,'2026-04-11 15:44:52'),(11,52,38,'suma',2,1,'2026-04-11 15:44:52'),(12,52,20,'suma',3,1,'2026-04-11 15:44:52');
/*!40000 ALTER TABLE `metricas_componentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificaciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `tipo` enum('info','success','warning','danger') COLLATE utf8mb4_unicode_ci DEFAULT 'info',
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leida` tinyint(1) DEFAULT '0',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_usuario_leida` (`usuario_id`,`leida`),
  KEY `idx_fecha` (`fecha_creacion`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodos`
--

DROP TABLE IF EXISTS `periodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `periodos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ejercicio` year NOT NULL,
  `periodo` tinyint NOT NULL COMMENT 'Mes: 1-12',
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Ej: Abril 2026',
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ejercicio_periodo` (`ejercicio`,`periodo`),
  KEY `idx_ejercicio` (`ejercicio`),
  KEY `idx_periodo` (`periodo`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Períodos de medición de métricas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodos`
--

LOCK TABLES `periodos` WRITE;
/*!40000 ALTER TABLE `periodos` DISABLE KEYS */;
INSERT INTO `periodos` VALUES (1,2026,1,'Enero 2026','2026-01-01','2026-01-31',1,'2026-04-09 15:20:29'),(2,2026,2,'Febrero 2026','2026-02-01','2026-02-28',1,'2026-04-09 15:20:29'),(3,2026,3,'Marzo 2026','2026-03-01','2026-03-31',1,'2026-04-09 15:20:29'),(4,2026,4,'Abril 2026','2026-04-01','2026-04-30',1,'2026-04-09 15:20:29'),(5,2026,5,'Mayo 2026','2026-05-01','2026-05-31',1,'2026-04-09 15:20:29'),(6,2026,6,'Junio 2026','2026-06-01','2026-06-30',1,'2026-04-09 15:20:29'),(7,2026,7,'Julio 2026','2026-07-01','2026-07-31',1,'2026-04-09 15:20:29'),(8,2026,8,'Agosto 2026','2026-08-01','2026-08-31',1,'2026-04-09 15:20:29'),(9,2026,9,'Septiembre 2026','2026-09-01','2026-09-30',1,'2026-04-09 15:20:29'),(10,2026,10,'Octubre 2026','2026-10-01','2026-10-31',1,'2026-04-09 15:20:29'),(11,2026,11,'Noviembre 2026','2026-11-01','2026-11-30',1,'2026-04-09 15:20:29'),(12,2026,12,'Diciembre 2026','2026-12-01','2026-12-31',1,'2026-04-09 15:20:29');
/*!40000 ALTER TABLE `periodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plantillas_dashboard`
--

DROP TABLE IF EXISTS `plantillas_dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plantillas_dashboard` (
  `id` int NOT NULL AUTO_INCREMENT,
  `area_id` int NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `configuracion_layout` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `es_predeterminada` tinyint(1) DEFAULT '0',
  `creado_por` int DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_area_predeterminada` (`area_id`,`es_predeterminada`),
  CONSTRAINT `plantillas_dashboard_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plantillas_dashboard_ibfk_2` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `plantillas_dashboard_chk_1` CHECK (json_valid(`configuracion_layout`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plantillas_dashboard`
--

LOCK TABLES `plantillas_dashboard` WRITE;
/*!40000 ALTER TABLE `plantillas_dashboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `plantillas_dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `predicciones_metricas`
--

DROP TABLE IF EXISTS `predicciones_metricas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `predicciones_metricas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `metrica_id` int NOT NULL,
  `periodo_id` int NOT NULL,
  `valor_predicho` decimal(10,2) DEFAULT NULL,
  `confianza` decimal(5,2) DEFAULT NULL,
  `modelo_utilizado` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_prediccion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `metrica_id` (`metrica_id`),
  KEY `periodo_id` (`periodo_id`),
  CONSTRAINT `predicciones_metricas_ibfk_1` FOREIGN KEY (`metrica_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `predicciones_metricas_ibfk_2` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predicciones_metricas`
--

LOCK TABLES `predicciones_metricas` WRITE;
/*!40000 ALTER TABLE `predicciones_metricas` DISABLE KEYS */;
/*!40000 ALTER TABLE `predicciones_metricas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reglas_alertas`
--

DROP TABLE IF EXISTS `reglas_alertas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reglas_alertas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `metrica_id` int NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `condicion` enum('mayor_que','menor_que','igual_a','cambio_porcentual') COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_umbral` decimal(10,2) DEFAULT NULL,
  `porcentaje_cambio` decimal(5,2) DEFAULT NULL,
  `activa` tinyint(1) DEFAULT '1',
  `notificar_usuarios` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `mensaje_alerta` text COLLATE utf8mb4_unicode_ci,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `metrica_id` (`metrica_id`),
  CONSTRAINT `reglas_alertas_ibfk_1` FOREIGN KEY (`metrica_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reglas_alertas_chk_1` CHECK (json_valid(`notificar_usuarios`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reglas_alertas`
--

LOCK TABLES `reglas_alertas` WRITE;
/*!40000 ALTER TABLE `reglas_alertas` DISABLE KEYS */;
/*!40000 ALTER TABLE `reglas_alertas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relaciones_metricas`
--

DROP TABLE IF EXISTS `relaciones_metricas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relaciones_metricas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `area_id` int NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_relacion` enum('suma','porcentaje','comparativa','progreso') COLLATE utf8mb4_unicode_ci NOT NULL,
  `metrica_1_id` int NOT NULL COMMENT 'Métrica principal',
  `metrica_2_id` int DEFAULT NULL COMMENT 'Métrica secundaria (opcional)',
  `metrica_3_id` int DEFAULT NULL COMMENT 'Métrica terciaria (opcional)',
  `tipo_grafico` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'progress_bar, stacked_bar, pie, etc.',
  `configuracion` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT 'Configuración adicional del gráfico',
  `orden` int DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `metrica_1_id` (`metrica_1_id`),
  KEY `metrica_2_id` (`metrica_2_id`),
  KEY `metrica_3_id` (`metrica_3_id`),
  KEY `idx_area` (`area_id`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `relaciones_metricas_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relaciones_metricas_ibfk_2` FOREIGN KEY (`metrica_1_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relaciones_metricas_ibfk_3` FOREIGN KEY (`metrica_2_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relaciones_metricas_ibfk_4` FOREIGN KEY (`metrica_3_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relaciones_metricas_chk_1` CHECK (json_valid(`configuracion`))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Relaciones entre métricas para visualización';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relaciones_metricas`
--

LOCK TABLES `relaciones_metricas` WRITE;
/*!40000 ALTER TABLE `relaciones_metricas` DISABLE KEYS */;
INSERT INTO `relaciones_metricas` VALUES (1,1,'Progreso de Proyectos','progreso',2,1,NULL,'progress_bar',NULL,1,1,'2026-04-09 15:20:29'),(2,1,'Calidad: Bugs','comparativa',4,5,NULL,'stacked_bar',NULL,2,1,'2026-04-09 15:20:29'),(3,2,'Vulnerabilidades','comparativa',9,10,NULL,'stacked_bar',NULL,1,1,'2026-04-09 15:20:29'),(4,3,'Estado de Tickets','comparativa',13,14,NULL,'stacked_bar',NULL,1,1,'2026-04-09 15:20:29');
/*!40000 ALTER TABLE `relaciones_metricas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportes_generados`
--

DROP TABLE IF EXISTS `reportes_generados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reportes_generados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('mensual','trimestral','anual','personalizado') COLLATE utf8mb4_unicode_ci DEFAULT 'mensual',
  `periodo_inicio_id` int DEFAULT NULL,
  `periodo_fin_id` int DEFAULT NULL,
  `areas_incluidas` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `formato` enum('pdf','excel','csv') COLLATE utf8mb4_unicode_ci DEFAULT 'pdf',
  `ruta_archivo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generado_por` int DEFAULT NULL,
  `fecha_generacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `periodo_inicio_id` (`periodo_inicio_id`),
  KEY `periodo_fin_id` (`periodo_fin_id`),
  KEY `generado_por` (`generado_por`),
  CONSTRAINT `reportes_generados_ibfk_1` FOREIGN KEY (`periodo_inicio_id`) REFERENCES `periodos` (`id`),
  CONSTRAINT `reportes_generados_ibfk_2` FOREIGN KEY (`periodo_fin_id`) REFERENCES `periodos` (`id`),
  CONSTRAINT `reportes_generados_ibfk_3` FOREIGN KEY (`generado_por`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `reportes_generados_chk_1` CHECK (json_valid(`areas_incluidas`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportes_generados`
--

LOCK TABLES `reportes_generados` WRITE;
/*!40000 ALTER TABLE `reportes_generados` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportes_generados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Hash bcrypt',
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_perfil` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rol` enum('admin','viewer') COLLATE utf8mb4_unicode_ci DEFAULT 'viewer',
  `permisos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `areas_asignadas` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `configuracion_dashboard` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `activo` tinyint(1) DEFAULT '1',
  `ultimo_acceso` timestamp NULL DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `usuarios_chk_1` CHECK (json_valid(`permisos`)),
  CONSTRAINT `usuarios_chk_2` CHECK (json_valid(`areas_asignadas`)),
  CONSTRAINT `usuarios_chk_3` CHECK (json_valid(`configuracion_dashboard`))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Usuarios del sistema con control de acceso';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','$2y$10$wJ0lOwh1NnFYLt8TMFVt/OXaoP/my4loUSJJ2I/5yWVUIs8UvB8Ai','Administrador','admin@empresa.com','avatar_1775771230_69d81e5ee8039.png','admin',NULL,NULL,NULL,1,'2026-04-18 18:06:28','2026-04-09 15:20:29','2026-04-18 18:06:28'),(2,'viewer1','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Usuario Visualizador','viewer@empresa.com',NULL,'viewer',NULL,NULL,NULL,1,NULL,'2026-04-09 15:20:29',NULL),(3,'jperez','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Juan Pérez','jperez@empresa.com',NULL,'admin',NULL,NULL,NULL,1,NULL,'2026-04-09 15:20:29',NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `valores_metricas`
--

DROP TABLE IF EXISTS `valores_metricas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `valores_metricas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `metrica_id` int NOT NULL,
  `periodo_id` int NOT NULL,
  `valor_numero` int DEFAULT NULL COMMENT 'Para tipo: numero',
  `valor_decimal` decimal(10,2) DEFAULT NULL COMMENT 'Para tipo: decimal y porcentaje',
  `nota` text COLLATE utf8mb4_unicode_ci COMMENT 'Comentarios adicionales sobre este valor',
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `usuario_registro_id` int DEFAULT NULL,
  `usuario_modificacion_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_metrica_periodo` (`metrica_id`,`periodo_id`),
  KEY `usuario_registro_id` (`usuario_registro_id`),
  KEY `usuario_modificacion_id` (`usuario_modificacion_id`),
  KEY `idx_periodo` (`periodo_id`),
  KEY `idx_metrica` (`metrica_id`),
  KEY `idx_fecha_registro` (`fecha_registro`),
  CONSTRAINT `valores_metricas_ibfk_1` FOREIGN KEY (`metrica_id`) REFERENCES `metricas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `valores_metricas_ibfk_2` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `valores_metricas_ibfk_3` FOREIGN KEY (`usuario_registro_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `valores_metricas_ibfk_4` FOREIGN KEY (`usuario_modificacion_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Valores de métricas por período';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `valores_metricas`
--

LOCK TABLES `valores_metricas` WRITE;
/*!40000 ALTER TABLE `valores_metricas` DISABLE KEYS */;
INSERT INTO `valores_metricas` VALUES (2,29,3,8005,NULL,'Total transacciones billetera virtual.','2026-04-10 18:45:46','2026-04-11 15:37:50',1,1),(4,33,3,NULL,11552295.44,'Monto total movilizado en fri.','2026-04-10 18:45:46','2026-04-11 15:37:50',1,1),(7,22,3,NULL,85.00,'Unificación de 31 sub-políticas a 15 principales. Pendiente formalización de políticas de Respaldo e Inmutabilidad.','2026-04-10 18:46:51',NULL,1,NULL),(8,23,3,25,NULL,'Gestión de licencias Adobe (6), altas de nuevos colaboradores y actualización de credenciales para Consejos y Comités.','2026-04-10 18:46:51',NULL,1,NULL),(9,24,3,1,NULL,'Análisis de vulnerabilidad en librería Axios (v1.14.1 y 0.30.4). Informe de remediación enviado y documentado.','2026-04-10 18:46:51',NULL,1,NULL),(10,25,3,2,NULL,'Migración estratégica de Adobe Enterprise y validación de cotización para mejora de Servidor Corporativo.','2026-04-10 18:46:51',NULL,1,NULL),(11,1,3,18,NULL,NULL,'2026-04-10 18:58:52','2026-04-10 19:32:45',1,1),(12,2,3,10,NULL,NULL,'2026-04-10 18:58:52','2026-04-13 15:23:27',1,1),(13,3,3,27,NULL,NULL,'2026-04-10 18:58:52','2026-04-10 19:32:45',1,1),(14,4,3,38,NULL,NULL,'2026-04-10 18:58:52','2026-04-10 19:32:45',1,1),(15,5,3,25,NULL,NULL,'2026-04-10 18:58:52','2026-04-10 19:32:45',1,1),(16,6,3,42,NULL,NULL,'2026-04-10 18:58:52','2026-04-10 19:32:45',1,1),(17,7,3,NULL,98.00,NULL,'2026-04-10 18:59:10','2026-04-10 19:33:29',1,1),(18,8,3,3,NULL,NULL,'2026-04-10 18:59:10','2026-04-13 15:04:00',1,1),(19,9,3,2,NULL,NULL,'2026-04-10 18:59:10','2026-04-10 19:33:29',1,1),(20,10,3,2,NULL,NULL,'2026-04-10 18:59:10','2026-04-10 19:33:29',1,1),(21,11,3,2,NULL,NULL,'2026-04-10 18:59:10','2026-04-10 19:33:29',1,1),(22,12,3,10,NULL,NULL,'2026-04-10 18:59:10','2026-04-10 19:33:29',1,1),(23,13,3,411,NULL,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(24,14,3,397,NULL,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(25,15,3,14,NULL,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(26,16,3,30,NULL,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(27,17,3,NULL,97.00,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(28,18,3,35,NULL,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(29,19,3,55,NULL,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(30,20,3,9,NULL,NULL,'2026-04-10 18:59:31','2026-04-10 19:40:14',1,1),(31,36,3,5,NULL,NULL,'2026-04-10 19:47:45','2026-04-11 15:46:00',1,1),(32,37,3,3,NULL,NULL,'2026-04-10 19:47:45','2026-04-11 15:46:00',1,1),(33,38,3,3,NULL,NULL,'2026-04-10 19:47:45','2026-04-11 15:46:00',1,1),(35,40,3,574249,NULL,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(36,41,3,1904,NULL,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:58',1,1),(37,42,3,NULL,2172269.43,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(38,43,3,8145,NULL,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(39,44,3,NULL,4408754.69,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(40,45,3,1883,NULL,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(41,46,3,NULL,2331928.26,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(42,47,3,731,NULL,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(43,48,3,10049,NULL,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:58',1,1),(44,49,3,NULL,2746518.43,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(45,50,3,NULL,6740682.95,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(46,51,3,2614,NULL,NULL,'2026-04-11 15:37:50','2026-04-13 15:23:50',1,1),(47,52,3,20,NULL,NULL,'2026-04-11 15:46:00',NULL,1,NULL),(48,36,2,1,NULL,NULL,'2026-04-11 15:50:45','2026-04-11 15:51:28',1,1),(49,37,2,2,NULL,NULL,'2026-04-11 15:50:45','2026-04-11 15:51:28',1,1),(50,52,2,7,NULL,NULL,'2026-04-11 15:50:45','2026-04-11 15:51:28',1,1),(51,19,2,15,NULL,NULL,'2026-04-11 15:50:45','2026-04-11 15:51:28',1,1),(52,20,2,4,NULL,NULL,'2026-04-11 15:50:45','2026-04-11 15:51:28',1,1),(53,38,2,0,NULL,NULL,'2026-04-11 15:51:28',NULL,1,NULL);
/*!40000 ALTER TABLE `valores_metricas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vista_actividad_usuarios`
--

DROP TABLE IF EXISTS `vista_actividad_usuarios`;
/*!50001 DROP VIEW IF EXISTS `vista_actividad_usuarios`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_actividad_usuarios` AS SELECT 
 1 AS `nombre`,
 1 AS `username`,
 1 AS `rol`,
 1 AS `metricas_registradas`,
 1 AS `ultimo_acceso`,
 1 AS `activo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_metricas_actuales`
--

DROP TABLE IF EXISTS `vista_metricas_actuales`;
/*!50001 DROP VIEW IF EXISTS `vista_metricas_actuales`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_metricas_actuales` AS SELECT 
 1 AS `area`,
 1 AS `area_slug`,
 1 AS `metrica`,
 1 AS `metrica_slug`,
 1 AS `tipo_valor`,
 1 AS `unidad`,
 1 AS `periodo`,
 1 AS `valor`,
 1 AS `nota`,
 1 AS `ultima_actualizacion`,
 1 AS `usuario_modificacion`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista_actividad_usuarios`
--

/*!50001 DROP VIEW IF EXISTS `vista_actividad_usuarios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_actividad_usuarios` AS select `u`.`nombre` AS `nombre`,`u`.`username` AS `username`,`u`.`rol` AS `rol`,count(distinct `vm`.`id`) AS `metricas_registradas`,max(`u`.`ultimo_acceso`) AS `ultimo_acceso`,`u`.`activo` AS `activo` from (`usuarios` `u` left join `valores_metricas` `vm` on((`u`.`id` = `vm`.`usuario_registro_id`))) group by `u`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_metricas_actuales`
--

/*!50001 DROP VIEW IF EXISTS `vista_metricas_actuales`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_metricas_actuales` AS select `a`.`nombre` AS `area`,`a`.`slug` AS `area_slug`,`m`.`nombre` AS `metrica`,`m`.`slug` AS `metrica_slug`,`m`.`tipo_valor` AS `tipo_valor`,`m`.`unidad` AS `unidad`,`p`.`nombre` AS `periodo`,coalesce(`vm`.`valor_numero`,`vm`.`valor_decimal`) AS `valor`,`vm`.`nota` AS `nota`,`vm`.`fecha_modificacion` AS `ultima_actualizacion`,`u`.`nombre` AS `usuario_modificacion` from ((((`metricas` `m` join `areas` `a` on((`m`.`area_id` = `a`.`id`))) left join `valores_metricas` `vm` on((`m`.`id` = `vm`.`metrica_id`))) left join `periodos` `p` on((`vm`.`periodo_id` = `p`.`id`))) left join `usuarios` `u` on((`vm`.`usuario_modificacion_id` = `u`.`id`))) where ((`m`.`activo` = 1) and (`a`.`activo` = 1)) order by `a`.`orden`,`m`.`orden` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-20  9:00:59

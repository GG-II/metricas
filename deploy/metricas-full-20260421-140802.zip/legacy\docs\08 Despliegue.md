# 🚀 Guía de Despliegue

Guía completa para desplegar el Dashboard de Métricas IT en AWS con IIS.

## 🎯 Arquitectura de Despliegue

```
┌─────────────────────────────────────────────────┐
│          Internet / Usuarios                     │
└─────────────────┬───────────────────────────────┘
                  │ HTTPS (443)
                  ▼
┌─────────────────────────────────────────────────┐
│      AWS EC2 - Windows Server 2016              │
│  ┌──────────────────────────────────────────┐   │
│  │  IIS 10                                  │   │
│  │  ├─ Site: metricas-it                   │   │
│  │  │  Port: 443 (HTTPS)                   │   │
│  │  │  SSL: Let's Encrypt / AWS Cert       │   │
│  │  └─ Path: C:\inetpub\wwwroot\metricas-it│   │
│  └──────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────┐   │
│  │  PHP 8.5.4                               │   │
│  │  Path: C:\php                            │   │
│  └──────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────┐   │
│  │  MySQL 8.0                               │   │
│  │  Service: MySQL80                        │   │
│  │  Port: 3306 (localhost only)             │   │
│  └──────────────────────────────────────────┘   │
└─────────────────────────────────────────────────┘
```

---

## 📋 Requisitos Previos

### Instancia EC2

- **Sistema Operativo**: Windows Server 2016 o superior
- **Tipo Instancia**: t3.medium (mínimo)
- **RAM**: 4 GB mínimo
- **Disco**: 50 GB SSD
- **Security Group**:
  - Puerto 80 (HTTP) - Abierto
  - Porto 443 (HTTPS) - Abierto
  - Puerto 3389 (RDP) - Solo tu IP
  - Puerto 3306 (MySQL) - CERRADO (solo localhost)

### Dominio

- Dominio registrado: `siscoop.cicrl.com.gt`
- DNS apuntando a IP elástica de EC2
- Certificado SSL (Let's Encrypt o AWS Certificate Manager)

---

## 🛠️ Instalación en AWS

### Paso 1: Conectar a EC2

1. Obtener contraseña de Windows:
   - AWS Console → EC2 → Instancia
   - Actions → Get Windows Password
   - Upload key pair (.pem)
   - Decrypt password

2. Conectar vía RDP:
   - IP: (IP elástica de tu instancia)
   - Usuario: `Administrator`
   - Password: (del paso anterior)

---

### Paso 2: Instalar IIS

```powershell
# Abrir PowerShell como Administrador
Install-WindowsFeature -name Web-Server -IncludeManagementTools

# Instalar CGI para PHP
Install-WindowsFeature Web-CGI-Extension
```

Verificar:
1. Abrir navegador en EC2
2. Ir a `http://localhost`
3. Debe aparecer página por defecto de IIS

---

### Paso 3: Instalar PHP

```powershell
# Descargar PHP 8.5.4 VC15 x64 Non-Thread Safe
# Desde: https://windows.php.net/download/

# Crear directorio
New-Item -Path "C:\php" -ItemType Directory

# Extraer ZIP en C:\php
# Configurar php.ini
Copy-Item "C:\php\php.ini-production" -Destination "C:\php\php.ini"
```

**Editar** `C:\php\php.ini`:

```ini
; Extensiones
extension_dir = "C:\php\ext"
extension=pdo_mysql
extension=mysqli
extension=mbstring
extension=openssl
extension=curl
extension=fileinfo
extension=gd

; Sesiones
session.save_path = "C:\php\sessions"

; Zona horaria
date.timezone = America/Guatemala

; Límites
upload_max_filesize = 10M
post_max_size = 10M
memory_limit = 256M
max_execution_time = 300

; Errores (SOLO en desarrollo)
; display_errors = Off
; log_errors = On
; error_log = C:/php/php_error.log
```

**Crear carpeta de sesiones**:

```powershell
New-Item -Path "C:\php\sessions" -ItemType Directory
icacls "C:\php\sessions" /grant "IIS_IUSRS:(OI)(CI)F" /T
```

**Configurar PHP en IIS**:

1. Abrir IIS Manager
2. Seleccionar servidor → Handler Mappings
3. Add Module Mapping:
   - Request path: `*.php`
   - Module: `FastCgiModule`
   - Executable: `C:\php\php-cgi.exe`
   - Name: `PHP_via_FastCGI`

---

### Paso 4: Instalar MySQL

```powershell
# Descargar MySQL 8.0 Installer
# Desde: https://dev.mysql.com/downloads/installer/

# Ejecutar instalador
# Configuración:
# - Server Type: Development
# - Port: 3306
# - Root Password: (guardar seguro)
# - Windows Service: MySQL80
# - Start at Startup: Yes
```

**Verificar instalación**:

```powershell
# Ver que el servicio esté corriendo
Get-Service MySQL80

# Conectar
mysql -u root -p
```

---

### Paso 5: Configurar Firewall Windows

```powershell
# Permitir IIS en firewall
New-NetFirewallRule -DisplayName "IIS HTTP" -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow
New-NetFirewallRule -DisplayName "IIS HTTPS" -Direction Inbound -LocalPort 443 -Protocol TCP -Action Allow

# MySQL debe estar SOLO en localhost (no abrir puerto 3306 externamente)
```

---

## 📦 Despliegue de la Aplicación

### Paso 1: Transferir Archivos

**Opción A: Git (Recomendado)**

```powershell
# Instalar Git for Windows
# https://git-scm.com/download/win

cd C:\inetpub\wwwroot
git clone <URL_REPOSITORIO> metricas-it
```

**Opción B: FTP/SFTP**

1. Instalar FileZilla Client
2. Conectar vía SFTP a EC2
3. Subir archivos a `C:\inetpub\wwwroot\metricas-it`

**Opción C: RDP + Copiar/Pegar**

1. Conectado vía RDP
2. Copiar archivos desde tu PC
3. Pegar en `C:\inetpub\wwwroot\metricas-it`

---

### Paso 2: Permisos de Carpetas

```powershell
# Dar permisos a IIS
icacls "C:\inetpub\wwwroot\metricas-it" /grant "IIS_IUSRS:(OI)(CI)F" /T

# Permisos específicos para uploads
icacls "C:\inetpub\wwwroot\metricas-it\uploads" /grant "IIS_IUSRS:(OI)(CI)F" /T
```

---

### Paso 3: Crear Base de Datos

```sql
-- Conectar como root
mysql -u root -p

-- Crear base de datos
CREATE DATABASE metricas_it_dev CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Crear usuario
CREATE USER 'metricas_user'@'localhost' IDENTIFIED BY 'PASSWORD_SEGURO_AQUI';
GRANT ALL PRIVILEGES ON metricas_it_dev.* TO 'metricas_user'@'localhost';
FLUSH PRIVILEGES;

-- Salir
EXIT;
```

**Importar esquema**:

```powershell
cd C:\inetpub\wwwroot\metricas-it\database
mysql -u metricas_user -p metricas_it_dev < schema.sql
mysql -u metricas_user -p metricas_it_dev < seed.sql
```

---

### Paso 4: Configurar config.php

**Editar**: `C:\inetpub\wwwroot\metricas-it\config.php`

```php
<?php
// Entorno
define('ENVIRONMENT', 'production');

// Base URL
define('BASE_URL', 'https://siscoop.cicrl.com.gt/metricas-it');
define('BASE_PATH', 'C:/inetpub/wwwroot/metricas-it');

// Base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'metricas_it_dev');
define('DB_USER', 'metricas_user');
define('DB_PASS', 'PASSWORD_SEGURO_AQUI');
define('DB_CHARSET', 'utf8mb4');

// Seguridad en producción
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1);  // Solo HTTPS

// Ocultar errores en producción
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', BASE_PATH . '/logs/php_error.log');

session_start();
```

---

### Paso 5: Configurar Sitio en IIS

1. **IIS Manager**
2. Sites → Add Website:
   - Site name: `metricas-it`
   - Physical path: `C:\inetpub\wwwroot\metricas-it`
   - Binding:
     - Type: `http`
     - IP: All Unassigned
     - Port: `80`
     - Host name: `siscoop.cicrl.com.gt`

3. Agregar binding HTTPS:
   - Sites → metricas-it → Bindings → Add
   - Type: `https`
   - Port: `443`
   - Host name: `siscoop.cicrl.com.gt`
   - SSL Certificate: (seleccionar o crear)

---

## 🔒 Certificado SSL

### Opción 1: Let's Encrypt (Gratuito)

```powershell
# Instalar win-acme
# https://www.win-acme.com/

# Ejecutar
wacs.exe

# Seguir wizard:
# 1. Create certificate (simple for IIS)
# 2. Single binding of an IIS site
# 3. Seleccionar 'metricas-it'
# 4. Aceptar términos
# 5. Completar validación
```

**Renovación automática**:
- win-acme crea tarea programada
- Se renueva automáticamente antes de expirar

### Opción 2: AWS Certificate Manager

1. AWS Console → Certificate Manager
2. Request certificate
3. Domain: `siscoop.cicrl.com.gt`
4. Validation: DNS
5. Agregar registros CNAME en DNS
6. Esperar validación
7. Usar con Application Load Balancer (si aplica)

---

## 🌐 Configurar DNS

### En tu proveedor DNS:

```
Tipo  Nombre                     Valor
────────────────────────────────────────────────
A     siscoop.cicrl.com.gt      XX.XX.XX.XX (IP Elástica EC2)
```

**Verificar propagación**:

```powershell
nslookup siscoop.cicrl.com.gt
```

Debe retornar la IP de tu EC2.

---

## ✅ Verificación Post-Despliegue

### Checklist

```powershell
# 1. PHP funciona
echo "<?php phpinfo(); ?>" > C:\inetpub\wwwroot\metricas-it\test.php
# Visitar: https://siscoop.cicrl.com.gt/metricas-it/test.php
# ELIMINAR después

# 2. MySQL conecta
echo "<?php
require_once 'config.php';
require_once 'includes/db.php';
try {
    \$db = getDB();
    echo 'Conexión OK';
} catch (Exception \$e) {
    echo 'Error: ' . \$e->getMessage();
}
?>" > C:\inetpub\wwwroot\metricas-it\test-db.php
# Visitar y ELIMINAR después

# 3. Sesiones funcionan
# Login en el sistema

# 4. HTTPS funciona
# Verificar que https:// funciona y redirige de http://

# 5. Permisos correctos
# Subir avatar de perfil
```

---

## 🔄 Actualización del Sistema

### Proceso de Actualización

```powershell
# 1. Backup de BD
cd C:\backups
mysqldump -u metricas_user -p metricas_it_dev > metricas_backup_%date:~-4,4%%date:~-10,2%%date:~-7,2%.sql

# 2. Backup de archivos (opcional)
xcopy C:\inetpub\wwwroot\metricas-it C:\backups\metricas-it-backup /E /I /Y

# 3. Descargar cambios (Git)
cd C:\inetpub\wwwroot\metricas-it
git pull origin main

# 4. Aplicar migraciones de BD (si hay)
mysql -u metricas_user -p metricas_it_dev < database/migrations/nueva_migracion.sql

# 5. Limpiar caché (si aplica)
del /s /q uploads\cache\*

# 6. Reiniciar IIS
iisreset
```

---

## 💾 Backup Automatizado

### Script de Backup

**Crear**: `C:\scripts\backup-metricas.bat`

```batch
@echo off
REM Backup automático de Dashboard Métricas IT

SET FECHA=%date:~-4,4%%date:~-10,2%%date:~-7,2%
SET BACKUP_DIR=C:\backups\metricas

REM Crear directorio si no existe
if not exist %BACKUP_DIR% mkdir %BACKUP_DIR%

REM Backup de Base de Datos
echo Backing up database...
mysqldump -u metricas_user -pPASSWORD metricas_it_dev > %BACKUP_DIR%\db_%FECHA%.sql

REM Backup de archivos uploads
echo Backing up uploads...
xcopy C:\inetpub\wwwroot\metricas-it\uploads %BACKUP_DIR%\uploads_%FECHA% /E /I /Y

REM Limpiar backups antiguos (más de 30 días)
forfiles /p %BACKUP_DIR% /m *.sql /d -30 /c "cmd /c del @path"

echo Backup completado: %FECHA%
```

### Programar Tarea

1. **Task Scheduler** → Create Task
2. General:
   - Name: `Backup Metricas IT`
   - Run whether user is logged on or not
   - Run with highest privileges
3. Triggers:
   - Daily at 2:00 AM
4. Actions:
   - Program: `C:\scripts\backup-metricas.bat`
5. Save

---

## 📊 Monitoreo

### Logs a Revisar

```
IIS Logs:
C:\inetpub\logs\LogFiles\W3SVC1\

PHP Error Log:
C:\inetpub\wwwroot\metricas-it\logs\php_error.log

MySQL Error Log:
C:\ProgramData\MySQL\MySQL Server 8.0\Data\*.err

Windows Event Viewer:
Application logs
```

### Métricas a Monitorear

- **CPU Usage**: Debe estar < 70%
- **RAM Usage**: Debe estar < 80%
- **Disk Space**: Mantener > 20% libre
- **IIS Requests**: Monitorear picos anormales
- **MySQL Connections**: No debe saturarse

### Herramientas

- **Performance Monitor** (perfmon.exe)
- **Resource Monitor** (resmon.exe)
- **Task Manager** (taskmgr.exe)

---

## 🔧 Troubleshooting Producción

### Error 500 en Producción

```powershell
# 1. Ver logs de IIS
Get-Content C:\inetpub\logs\LogFiles\W3SVC1\*.log -Tail 50

# 2. Ver logs de PHP
Get-Content C:\inetpub\wwwroot\metricas-it\logs\php_error.log -Tail 50

# 3. Activar errores temporalmente (SOLO para debug)
# Editar config.php:
# ini_set('display_errors', 1);

# 4. Verificar permisos
icacls C:\inetpub\wwwroot\metricas-it
```

### MySQL No Conecta

```powershell
# 1. Verificar servicio
Get-Service MySQL80

# 2. Si está detenido, iniciar
Start-Service MySQL80

# 3. Probar conexión
mysql -u metricas_user -p -h localhost metricas_it_dev
```

### SSL No Funciona

```powershell
# 1. Verificar binding en IIS
Get-WebBinding -Name "metricas-it"

# 2. Verificar certificado
Get-ChildItem Cert:\LocalMachine\My

# 3. Verificar firewall
Get-NetFirewallRule -DisplayName "*443*"
```

---

## 🔒 Hardening de Seguridad

### IIS

```xml
<!-- web.config -->
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <!-- Ocultar versión de PHP -->
        <httpProtocol>
            <customHeaders>
                <remove name="X-Powered-By" />
            </customHeaders>
        </httpProtocol>
        
        <!-- Forzar HTTPS -->
        <rewrite>
            <rules>
                <rule name="Redirect to HTTPS" stopProcessing="true">
                    <match url="(.*)" />
                    <conditions>
                        <add input="{HTTPS}" pattern="off" />
                    </conditions>
                    <action type="Redirect" url="https://{HTTP_HOST}/{R:1}" />
                </rule>
            </rules>
        </rewrite>
    </system.webServer>
</configuration>
```

### PHP

```php
// config.php - Security headers
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
```

### MySQL

```sql
-- Remover usuarios anónimos
DELETE FROM mysql.user WHERE User='';

-- Remover bases de datos de prueba
DROP DATABASE IF EXISTS test;

-- Flush
FLUSH PRIVILEGES;
```

### Windows Firewall

```powershell
# Solo permitir puertos necesarios
# 80, 443 para web
# 3389 para RDP (solo tu IP)
# MySQL NO debe estar expuesto externamente
```

---

## 📈 Escalamiento

### Vertical (Escalar instancia)

1. AWS Console → EC2 → Instance
2. Stop instance
3. Change instance type (ej: t3.medium → t3.large)
4. Start instance

### Horizontal (Load Balancer)

```
┌──────────────┐
│ Application  │
│Load Balancer │
└──────┬───────┘
       │
   ┌───┴───┐
   │       │
┌──▼──┐ ┌──▼──┐
│ EC2 │ │ EC2 │
│  A  │ │  B  │
└─────┘ └─────┘
   │       │
   └───┬───┘
       │
  ┌────▼────┐
  │   RDS   │
  │  MySQL  │
  └─────────┘
```

Para alta disponibilidad:
1. Crear AMI de instancia actual
2. Lanzar múltiples instancias desde AMI
3. Configurar Application Load Balancer
4. Migrar MySQL a RDS (managed)
5. Compartir uploads via S3 o EFS

---

## 📚 Recursos AWS

- [EC2 Windows](https://docs.aws.amazon.com/ec2/index.html)
- [IIS on EC2](https://docs.aws.amazon.com/AWSEC2/latest/WindowsGuide/install-iis.html)
- [RDS MySQL](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_MySQL.html)
- [Application Load Balancer](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/)

---

**Versión**: 1.0  
**Última actualización**: Abril 2026  
**Ambiente**: AWS EC2 Windows Server + IIS + MySQL
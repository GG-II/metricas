# 💻 Guía de Desarrollo

Guía para desarrolladores que deseen extender o modificar el sistema.

## 🎯 Introducción

Esta guía cubre:
- Crear nuevos tipos de gráficos
- Agregar funcionalidades
- Modificar componentes existentes
- Mejores prácticas de desarrollo

---

## 🏗️ Entorno de Desarrollo

### Requisitos

- **PHP 8.0+** con extensiones PDO, MySQL
- **MySQL 8.0+**
- **Composer** (opcional, para dependencias futuras)
- **Git** para control de versiones
- **Editor**: VS Code, PHPStorm, o similar

### Configuración Local

```bash
# Clonar repositorio
git clone <URL_REPOSITORIO>
cd metricas-it

# Configurar entorno de desarrollo
cp config.example.php config.php

# Editar config.php
nano config.php
```

```php
<?php
// config.php - Desarrollo
define('ENVIRONMENT', 'development');
define('BASE_URL', 'http://localhost/metricas-it');
define('BASE_PATH', 'C:/xampp/htdocs/metricas-it');

// Habilitar errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

### Base de Datos Local

```bash
# Importar esquema
mysql -u root -p
CREATE DATABASE metricas_it_dev;
USE metricas_it_dev;
SOURCE database/schema.sql;
SOURCE database/seed.sql;
```

---

## 🎨 Crear Nuevo Tipo de Gráfico

### Paso 1: Crear Archivo del Componente

**Ubicación**: `components/charts/mi-grafico.php`

```php
<?php
/**
 * Mi Gráfico Personalizado
 * Descripción de qué hace este gráfico
 * 
 * @package Dashboard
 * @subpackage Charts
 */

// Metadata del componente (para registro automático)
$metadata = [
    'name' => 'Mi Gráfico',
    'description' => 'Descripción breve del gráfico',
    'icon' => 'ti-chart-dots',
    'config_fields' => ['titulo', 'color', 'metricas'],
    'min_metricas' => 1,
    'max_metricas' => 5
];

// Solo renderizar si NO es preview
if (!isset($preview)) {
    // Obtener configuración
    $config = json_decode($grafico['configuracion_json'], true);
    $metricas = $metricas ?? [];
    
    // Validar que hay métricas
    if (empty($metricas)) {
        echo '<div class="alert alert-warning">No hay métricas configuradas</div>';
        return;
    }
    
    ?>
    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo htmlspecialchars($config['titulo']); ?></h3>
        </div>
        <div class="card-body">
            <!-- Tu HTML aquí -->
            <div id="chart-<?php echo $grafico['id']; ?>"></div>
        </div>
    </div>
    
    <script>
    // Tu JavaScript aquí
    (function() {
        const chartElement = document.getElementById('chart-<?php echo $grafico['id']; ?>');
        const data = <?php echo json_encode($metricas); ?>;
        
        // Renderizar gráfico con Chart.js, D3, o lo que necesites
        // ...
    })();
    </script>
    
    <?php
}
?>
```

### Paso 2: Estructura Recomendada

```php
<?php
// 1. METADATA
$metadata = [...];

// 2. VALIDACIONES
if (!isset($preview)) {
    $config = json_decode($grafico['configuracion_json'], true);
    
    // Validar configuración
    if (empty($config['titulo'])) {
        $config['titulo'] = 'Sin título';
    }
    
    // Preparar datos
    $datos_procesados = [];
    foreach ($metricas as $metrica) {
        $datos_procesados[] = [
            'label' => $metrica['nombre'],
            'value' => $metrica['valor'] ?? 0
        ];
    }
}

// 3. HTML
?>
<div class="card">
    <!-- Markup -->
</div>

<!-- 4. JAVASCRIPT -->
<script>
(function() {
    // Código JavaScript encapsulado
})();
</script>

<?php
// 5. ESTILOS (si son específicos del gráfico)
?>
<style>
.mi-grafico-clase {
    /* Estilos específicos */
}
</style>
```

### Paso 3: Usar Librerías

#### Chart.js (Ya incluido)

```javascript
new Chart(chartElement, {
    type: 'bar',
    data: {
        labels: ['Ene', 'Feb', 'Mar'],
        datasets: [{
            label: 'Ventas',
            data: [12, 19, 3],
            backgroundColor: '#0d6efd'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});
```

#### Agregar Nueva Librería

```php
<!-- En partials/footer.php o en tu componente -->
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
```

### Paso 4: Configuración JSON

Define qué configuraciones acepta tu gráfico:

```json
{
    "titulo": "Mi Gráfico de Ejemplo",
    "color": "#0d6efd",
    "metricas": [12, 15, 18],
    "mostrar_leyenda": true,
    "tipo_visualizacion": "barras",
    "altura": 300
}
```

En PHP, accede con:

```php
$titulo = $config['titulo'] ?? 'Sin título';
$color = $config['color'] ?? '#0d6efd';
$metricas_ids = $config['metricas'] ?? [];
```

### Paso 5: Registro Automático

El sistema detecta automáticamente tu componente mediante `ChartRegistry::getAvailableTypes()`.

**No necesitas registrarlo manualmente**, solo:
1. Crear archivo en `components/charts/`
2. Incluir metadata
3. Listo!

---

## 🧩 Ejemplo Completo: Gráfico de Radar

```php
<?php
/**
 * Radar Chart - Gráfico de radar para comparar múltiples métricas
 */

$metadata = [
    'name' => 'Radar Chart',
    'description' => 'Compara múltiples métricas en ejes radiales',
    'icon' => 'ti-radar',
    'config_fields' => ['titulo', 'metricas', 'max_value'],
    'min_metricas' => 3,
    'max_metricas' => 8
];

if (!isset($preview)) {
    $config = json_decode($grafico['configuracion_json'], true);
    $max_value = $config['max_value'] ?? 100;
    
    // Preparar datos para Chart.js
    $labels = [];
    $values = [];
    
    foreach ($metricas as $metrica) {
        $labels[] = $metrica['nombre'];
        $values[] = $metrica['valor'] ?? 0;
    }
    
    $chart_id = 'radar-' . $grafico['id'];
    ?>
    
    <div class="card h-100">
        <div class="card-header">
            <h3 class="card-title"><?php echo htmlspecialchars($config['titulo']); ?></h3>
        </div>
        <div class="card-body">
            <canvas id="<?php echo $chart_id; ?>" height="300"></canvas>
        </div>
    </div>
    
    <script>
    (function() {
        const ctx = document.getElementById('<?php echo $chart_id; ?>');
        
        new Chart(ctx, {
            type: 'radar',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    label: 'Valores Actuales',
                    data: <?php echo json_encode($values); ?>,
                    fill: true,
                    backgroundColor: 'rgba(13, 110, 253, 0.2)',
                    borderColor: 'rgb(13, 110, 253)',
                    pointBackgroundColor: 'rgb(13, 110, 253)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgb(13, 110, 253)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        angleLines: {
                            display: true
                        },
                        suggestedMin: 0,
                        suggestedMax: <?php echo $max_value; ?>
                    }
                }
            }
        });
    })();
    </script>
    
    <?php
}
?>
```

---

## 🔧 Extender Modelos

### Crear Nuevo Modelo

**Ubicación**: `models/MiModelo.php`

```php
<?php
/**
 * Modelo MiModelo
 * Gestiona la entidad mi_tabla
 */

class MiModelo {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    /**
     * Obtener todos los registros activos
     * 
     * @return array
     */
    public function getAll() {
        $stmt = $this->db->query("
            SELECT * FROM mi_tabla 
            WHERE activo = 1 
            ORDER BY nombre
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Obtener por ID
     * 
     * @param int $id
     * @return array|false
     */
    public function getById($id) {
        $stmt = $this->db->prepare("
            SELECT * FROM mi_tabla WHERE id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Crear nuevo registro
     * 
     * @param array $data
     * @return int Last insert ID
     */
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO mi_tabla (campo1, campo2, campo3)
            VALUES (?, ?, ?)
        ");
        
        $stmt->execute([
            $data['campo1'],
            $data['campo2'],
            $data['campo3']
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Actualizar registro
     * 
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data) {
        $stmt = $this->db->prepare("
            UPDATE mi_tabla 
            SET campo1 = ?, campo2 = ?, campo3 = ?
            WHERE id = ?
        ");
        
        return $stmt->execute([
            $data['campo1'],
            $data['campo2'],
            $data['campo3'],
            $id
        ]);
    }
    
    /**
     * Eliminar registro (soft delete)
     * 
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $stmt = $this->db->prepare("
            UPDATE mi_tabla SET activo = 0 WHERE id = ?
        ");
        return $stmt->execute([$id]);
    }
}
```

### Uso del Modelo

```php
<?php
require_once 'models/MiModelo.php';

$miModelo = new MiModelo();

// Obtener todos
$registros = $miModelo->getAll();

// Obtener uno
$registro = $miModelo->getById(5);

// Crear
$nuevo_id = $miModelo->create([
    'campo1' => 'valor1',
    'campo2' => 'valor2',
    'campo3' => 'valor3'
]);

// Actualizar
$miModelo->update($id, [
    'campo1' => 'nuevo_valor'
]);

// Eliminar
$miModelo->delete($id);
?>
```

---

## 📄 Crear Nueva Página

### Estructura de Página

```php
<?php
/**
 * Mi Nueva Página
 * Descripción de la funcionalidad
 */

// 1. CONFIGURACIÓN
require_once 'config.php';
requireLogin(); // o requireAdmin()

// 2. MODELOS
require_once 'models/MiModelo.php';

// 3. LÓGICA
$miModelo = new MiModelo();

// POST Handler (si aplica)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Procesar formulario
    // ...
    
    // Redirigir con mensaje
    $_SESSION['mensaje'] = 'Operación exitosa';
    $_SESSION['mensaje_tipo'] = 'success';
    header("Location: " . BASE_URL . "/mi-pagina.php");
    exit();
}

// GET - Obtener datos
$datos = $miModelo->getAll();

// Variables para header
$page_title = 'Mi Nueva Página';
$is_admin = isAdmin();
?>

<?php include 'partials/header.php'; ?>

<!-- 4. HTML -->
<div class="page-body">
    <div class="container-xl">
        
        <div class="page-header">
            <h2 class="page-title">Mi Nueva Página</h2>
        </div>
        
        <div class="card">
            <div class="card-body">
                <!-- Contenido -->
            </div>
        </div>
        
    </div>
</div>

<!-- 5. JAVASCRIPT (opcional) -->
<script>
// JavaScript específico de la página
</script>

<?php include 'partials/footer.php'; ?>
```

---

## 🎨 Estilos y UI

### Usar Tabler UI

El sistema usa [Tabler](https://tabler.io) como framework CSS.

**Componentes comunes**:

```html
<!-- Botones -->
<button class="btn btn-primary">Primario</button>
<button class="btn btn-success">Éxito</button>
<button class="btn btn-danger">Peligro</button>

<!-- Cards -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Título</h3>
    </div>
    <div class="card-body">
        Contenido
    </div>
</div>

<!-- Alerts -->
<div class="alert alert-success">Mensaje de éxito</div>

<!-- Formularios -->
<div class="mb-3">
    <label class="form-label">Campo</label>
    <input type="text" class="form-control" placeholder="Placeholder">
</div>
```

### Iconos Tabler

```html
<i class="ti ti-chart-bar"></i>
<i class="ti ti-user"></i>
<i class="ti ti-settings"></i>
```

Ver todos: https://tabler-icons.io/

### CSS Personalizado

**Ubicación**: `assets/css/custom.css`

```css
/* Estilos específicos del proyecto */
.mi-clase-personalizada {
    background: #f0f0f0;
    padding: 1rem;
    border-radius: 8px;
}
```

---

## 🔌 Agregar Funcionalidad AJAX

### Frontend

```javascript
// Hacer petición AJAX
fetch('/metricas-it/admin/mi-endpoint.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        accion: 'actualizar',
        id: 123,
        valor: 'nuevo valor'
    })
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        alert('Éxito!');
    } else {
        alert('Error: ' + data.message);
    }
})
.catch(error => {
    console.error('Error:', error);
});
```

### Backend

```php
<?php
/**
 * mi-endpoint.php
 * Endpoint AJAX
 */

require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

try {
    // Obtener datos JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    $accion = $input['accion'] ?? '';
    
    switch ($accion) {
        case 'actualizar':
            // Lógica de actualización
            $id = (int)$input['id'];
            $valor = $input['valor'];
            
            // ... procesar ...
            
            echo json_encode([
                'success' => true,
                'message' => 'Actualizado correctamente'
            ]);
            break;
            
        default:
            echo json_encode([
                'success' => false,
                'message' => 'Acción no válida'
            ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
```

---

## 🗄️ Migraciones de Base de Datos

### Crear Migración

**Ubicación**: `database/migrations/2026_04_13_agregar_campo_nuevo.sql`

```sql
-- Migración: Agregar campo nuevo a tabla metricas
-- Fecha: 2026-04-13
-- Autor: Tu Nombre

-- UP
ALTER TABLE metricas 
ADD COLUMN campo_nuevo VARCHAR(100) DEFAULT NULL AFTER descripcion;

-- Crear índice si es necesario
CREATE INDEX idx_campo_nuevo ON metricas(campo_nuevo);

-- DOWN (para rollback)
-- ALTER TABLE metricas DROP COLUMN campo_nuevo;
-- DROP INDEX idx_campo_nuevo ON metricas;
```

### Aplicar Migración

```bash
mysql -u metricas_user -p metricas_it_dev < database/migrations/2026_04_13_agregar_campo_nuevo.sql
```

---

## 🧪 Testing

### Testing Manual

```php
<?php
/**
 * test/test-modelo.php
 * Tests manuales de MiModelo
 */

require_once '../config.php';
require_once '../models/MiModelo.php';

echo "<h1>Test: MiModelo</h1>";

$modelo = new MiModelo();

// Test 1: getAll()
echo "<h2>Test 1: getAll()</h2>";
$resultados = $modelo->getAll();
echo "Registros encontrados: " . count($resultados) . "<br>";
print_r($resultados);

// Test 2: getById()
echo "<h2>Test 2: getById(1)</h2>";
$registro = $modelo->getById(1);
print_r($registro);

// Test 3: create()
echo "<h2>Test 3: create()</h2>";
$nuevo_id = $modelo->create([
    'campo1' => 'test',
    'campo2' => 'test2',
    'campo3' => 'test3'
]);
echo "Nuevo ID: $nuevo_id<br>";

echo "<hr><strong>Todos los tests completados</strong>";
?>
```

---

## 📚 Mejores Prácticas

### Código PHP

✅ **Usar prepared statements siempre**:
```php
// ❌ MAL - SQL Injection
$stmt = $db->query("SELECT * FROM usuarios WHERE username = '$username'");

// ✅ BIEN
$stmt = $db->prepare("SELECT * FROM usuarios WHERE username = ?");
$stmt->execute([$username]);
```

✅ **Validar y sanitizar inputs**:
```php
$nombre = sanitize($_POST['nombre']);
$email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
```

✅ **Manejo de errores**:
```php
try {
    // Código que puede fallar
} catch (Exception $e) {
    error_log($e->getMessage());
    // Mostrar mensaje amigable al usuario
}
```

### JavaScript

✅ **Encapsular código**:
```javascript
(function() {
    // Tu código aquí
    // No contamina scope global
})();
```

✅ **Usar const/let en lugar de var**:
```javascript
const API_URL = '/api/endpoint';
let contador = 0;
```

### SQL

✅ **Índices en columnas frecuentes**:
```sql
CREATE INDEX idx_area_activo ON metricas(area_id, activo);
```

✅ **Foreign keys para integridad**:
```sql
FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE CASCADE
```

---

## 🔐 Seguridad

### Proteger Rutas

```php
// Al inicio de cada página administrativa
require_once 'config.php';
requireAdmin(); // Solo administradores

// Para páginas que requieren login
requireLogin(); // Cualquier usuario autenticado
```

### CSRF Protection

```php
// Generar token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// En formulario
<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

// Validar
if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die('CSRF token inválido');
}
```

### XSS Prevention

```php
// SIEMPRE escapar output
echo htmlspecialchars($user_input, ENT_QUOTES, 'UTF-8');
```

---

## 📦 Deployment

Ver [08-despliegue.md](08-despliegue.md) para guía completa de deployment.

---

## 📚 Recursos

- [Tabler UI](https://tabler.io/docs)
- [Chart.js](https://www.chartjs.org/docs/)
- [GridStack.js](https://gridstackjs.com/)
- [PHP PDO](https://www.php.net/manual/en/book.pdo.php)
- [Tabler Icons](https://tabler-icons.io/)

---

**Versión**: 1.0  
**Última actualización**: Abril 2026
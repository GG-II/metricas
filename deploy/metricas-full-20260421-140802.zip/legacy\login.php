<?php
/**
 * Página de login
 */

// ========================================
// INICIO DEL DIAGNÓSTICO
// ========================================

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Array para guardar los resultados
$diagnostico = [
    'timestamp' => date('Y-m-d H:i:s'),
    'tests' => []
];

// Función helper para testear includes
function testIncludeSeguro($nombre, $archivo, &$diagnostico) {
    $resultado = [
        'nombre' => $nombre,
        'archivo' => $archivo,
        'existe' => false,
        'cargado' => false,
        'error' => null,
        'size' => 0
    ];
    
    $ruta = __DIR__ . '/' . $archivo;
    
    if (file_exists($ruta)) {
        $resultado['existe'] = true;
        $resultado['size'] = filesize($ruta);
        
        try {
            ob_start();
            $incluido = include_once $ruta;
            ob_end_clean();
            $resultado['cargado'] = true;
            
        } catch (Throwable $e) {
            $resultado['error'] = [
                'tipo' => get_class($e),
                'mensaje' => $e->getMessage(),
                'archivo' => basename($e->getFile()),
                'linea' => $e->getLine()
            ];
        }
    } else {
        $resultado['error'] = ['mensaje' => 'Archivo no existe'];
    }
    
    $diagnostico['tests'][] = $resultado;
    return $resultado['cargado'];
}

// TEST 1: config.php
testIncludeSeguro('Config', 'config.php', $diagnostico);

// TEST 2: includes/db.php
if (file_exists(__DIR__ . '/includes/db.php')) {
    $diagnostico['tests'][] = [
        'nombre' => 'Database',
        'archivo' => 'includes/db.php',
        'existe' => true,
        'cargado' => function_exists('getDB'),
        'nota' => 'Cargado por config.php'
    ];
}

// TEST 3: includes/functions.php
if (file_exists(__DIR__ . '/includes/functions.php')) {
    $diagnostico['tests'][] = [
        'nombre' => 'Functions',
        'archivo' => 'includes/functions.php',
        'existe' => true,
        'cargado' => function_exists('sanitize'),
        'nota' => 'Cargado por config.php',
        'funciones_criticas' => [
            'sanitize' => function_exists('sanitize'),
            'isLoggedIn' => function_exists('isLoggedIn'),
            'calcularCumplimiento' => function_exists('calcularCumplimiento')
        ]
    ];
}

// TEST 4: models/Model.php
testIncludeSeguro('Model Base', 'models/Model.php', $diagnostico);

// TEST 5: models/Usuario.php
testIncludeSeguro('Usuario Model', 'models/Usuario.php', $diagnostico);

// TEST 6: models/ValorMetrica.php (EL SOSPECHOSO)
testIncludeSeguro('ValorMetrica Model', 'models/ValorMetrica.php', $diagnostico);

// TEST 7: models/Meta.php (NUEVO)
testIncludeSeguro('Meta Model', 'models/Meta.php', $diagnostico);

// TEST 8: Intentar instanciar clases
if (class_exists('Usuario')) {
    try {
        $test = new Usuario();
        $diagnostico['tests'][] = [
            'nombre' => 'Instanciar Usuario',
            'cargado' => true
        ];
    } catch (Throwable $e) {
        $diagnostico['tests'][] = [
            'nombre' => 'Instanciar Usuario',
            'cargado' => false,
            'error' => ['mensaje' => $e->getMessage()]
        ];
    }
}

if (class_exists('ValorMetrica')) {
    try {
        $test = new ValorMetrica();
        $diagnostico['tests'][] = [
            'nombre' => 'Instanciar ValorMetrica',
            'cargado' => true
        ];
    } catch (Throwable $e) {
        $diagnostico['tests'][] = [
            'nombre' => 'Instanciar ValorMetrica',
            'cargado' => false,
            'error' => ['mensaje' => $e->getMessage()]
        ];
    }
}

// Agregar info del sistema
$diagnostico['sistema'] = [
    'php_version' => phpversion(),
    'servidor' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown'
];

// Convertir a JSON para JavaScript
$diagnostico_json = json_encode($diagnostico, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// ========================================
// FIN DEL DIAGNÓSTICO
// ========================================

require_once 'config.php';

// Si ya está logueado, redirigir al dashboard
if (isLoggedIn()) {
    redirect('/index.php');
}

// Procesar el formulario de login
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Por favor, completa todos los campos.';
    } else {
        try {
            $db = getDB();
            
            // Buscar usuario
            $stmt = $db->prepare("
                SELECT id, username, password, nombre, email, rol, activo 
                FROM usuarios 
                WHERE username = ? AND activo = 1
            ");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && verifyPassword($password, $user['password'])) {
                // Login exitoso
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_name'] = $user['nombre'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['rol'];
                
                // Actualizar último acceso
                $stmt = $db->prepare("UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = ?");
                $stmt->execute([$user['id']]);
                
                // Registrar actividad
                logActivity('login');
                
                // Redirigir al dashboard
                redirect('/index.php');
            } else {
                $error = 'Usuario o contraseña incorrectos.';
                
                // Log de intento fallido
                error_log("Failed login attempt for username: $username from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
            }
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            $error = 'Error al procesar el login. Por favor, intenta nuevamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/core@latest/dist/css/tabler.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }
        .login-card {
            background: rgba(30, 41, 59, 0.8);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        .logo {
            width: 60px;
            height: 60px;
            background: #3b82f6;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            color: white;
            margin: 0 auto 20px;
        }
        .login-title {
            color: white;
            text-align: center;
            margin-bottom: 30px;
            font-size: 24px;
            font-weight: 600;
        }
        .form-label {
            color: #94a3b8;
            margin-bottom: 8px;
        }
        .form-control {
            background: rgba(15, 23, 42, 0.5);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            padding: 12px 16px;
            border-radius: 8px;
        }
        .form-control:focus {
            background: rgba(15, 23, 42, 0.7);
            border-color: #3b82f6;
            color: white;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        .btn-login {
            background: #3b82f6;
            border: none;
            padding: 12px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .btn-login:hover {
            background: #2563eb;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(59, 130, 246, 0.3);
        }
        .alert {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .version {
            text-align: center;
            color: #64748b;
            margin-top: 20px;
            font-size: 12px;
        }
    </style>
    
    <!-- SCRIPT DE DIAGNÓSTICO -->
    <script>
    (function() {
        const diagnostico = <?php echo $diagnostico_json; ?>;
        
        console.clear();
        console.log('%c🔍 DIAGNÓSTICO DEL SISTEMA', 'font-size: 20px; font-weight: bold; color: #61dafb;');
        console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #666;');
        console.log('Timestamp:', diagnostico.timestamp);
        console.log('PHP Version:', diagnostico.sistema.php_version);
        console.log('');
        
        console.log('%c📋 TESTS DE ARCHIVOS', 'font-size: 16px; font-weight: bold; color: #98c379;');
        console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #666;');
        
        let passed = 0;
        let failed = 0;
        
        diagnostico.tests.forEach((test, index) => {
            const num = (index + 1).toString().padStart(2, '0');
            
            if (test.cargado) {
                passed++;
                console.log(`%c✓ ${num}. ${test.nombre}`, 'color: #4CAF50; font-weight: bold;');
                if (test.archivo) {
                    console.log(`   📁 ${test.archivo} (${test.size} bytes)`);
                }
                if (test.nota) {
                    console.log(`   💡 ${test.nota}`);
                }
                if (test.funciones_criticas) {
                    console.log('   Funciones críticas:', test.funciones_criticas);
                }
            } else {
                failed++;
                console.log(`%c✗ ${num}. ${test.nombre}`, 'color: #f44336; font-weight: bold;');
                if (test.archivo) {
                    console.log(`   📁 ${test.archivo}`);
                }
                if (!test.existe) {
                    console.log(`   ❌ Archivo NO EXISTE`);
                }
                if (test.error) {
                    console.log(`   ❌ ERROR:`, test.error);
                }
            }
            console.log('');
        });
        
        console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #666;');
        console.log('%c📊 RESUMEN', 'font-size: 16px; font-weight: bold; color: #e5c07b;');
        console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #666;');
        console.log(`Total tests: ${passed + failed}`);
        console.log(`%c✓ Exitosos: ${passed}`, 'color: #4CAF50; font-weight: bold;');
        console.log(`%c✗ Fallidos: ${failed}`, 'color: #f44336; font-weight: bold;');
        
        if (failed > 0) {
            console.log('');
            console.log('%c⚠️ HAY ERRORES QUE CORREGIR', 'font-size: 14px; font-weight: bold; color: #f44336;');
            console.log('Revisa los tests marcados con ✗ arriba.');
        } else {
            console.log('');
            console.log('%c🎉 TODOS LOS TESTS PASARON', 'font-size: 14px; font-weight: bold; color: #4CAF50;');
        }
        
        console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #666;');
        
        // Guardar en window para poder accederlo
        window.diagnosticoSistema = diagnostico;
        console.log('');
        console.log('%c💡 TIP: Escribe "diagnosticoSistema" en la consola para ver el objeto completo', 'color: #888; font-style: italic;');
    })();
    </script>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="logo">IT</div>
            <h1 class="login-title"><?php echo APP_NAME; ?></h1>
            
            <?php if ($error): ?>
                <div class="alert">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Usuario</label>
                    <input type="text" name="username" class="form-control" 
                           placeholder="Ingresa tu usuario" 
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                           required autofocus>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Contraseña</label>
                    <input type="password" name="password" class="form-control" 
                           placeholder="Ingresa tu contraseña" 
                           required>
                </div>
                
                <button type="submit" class="btn-login">
                    Iniciar Sesión
                </button>
            </form>
            
            <div class="version">
                Versión <?php echo APP_VERSION; ?>
            </div>
        </div>
    </div>
</body>
</html>
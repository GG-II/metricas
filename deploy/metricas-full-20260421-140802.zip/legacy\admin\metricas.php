<?php
/**
 * Panel de administración - Editar métricas
 * Solo accesible por administradores
 */

require_once '../config.php';

// Proteger ruta (solo admin)
requireAdmin();

// Cargar modelos
require_once '../models/Area.php';
require_once '../models/Periodo.php';
require_once '../models/Metrica.php';
require_once '../models/ValorMetrica.php';

// Obtener área y período de la URL
$area_id = isset($_GET['area']) ? (int)$_GET['area'] : AREA_SOFTWARE;
$periodo_str = $_GET['periodo'] ?? getCurrentPeriod();

// Validar formato del período
if (strpos($periodo_str, '-') === false) {
    die('Formato de período inválido');
}

list($ejercicio, $periodo_mes) = explode('-', $periodo_str);

// Instanciar modelos
$areaModel = new Area();
$periodoModel = new Periodo();
$metricaModel = new Metrica();
$valorModel = new ValorMetrica();

// Obtener área
$area = $areaModel->getById($area_id);
if (!$area) {
    redirect('/index.php');
}

// Obtener período
$periodo = $periodoModel->getByEjercicioPeriodo($ejercicio, $periodo_mes);
if (!$periodo) {
    redirect('/index.php');
}

// ============================================
// PROCESAR FORMULARIO ANTES DE CUALQUIER OUTPUT
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_metricas'])) {
    try {
        $db = getDB();
        $db->beginTransaction();
        
        $cambios_realizados = 0;
        
        foreach ($_POST['metricas'] as $metrica_id => $datos) {
            $metrica_id = (int)$metrica_id;
            $valor = trim($datos['valor']);
            $nota = trim($datos['nota'] ?? '');
            
            // Guardar TANTO métricas normales como calculadas
            // Las calculadas ya vienen con el valor correcto desde JavaScript
            if ($valor !== '') {
                $valorModel->guardarValor(
                    $metrica_id,
                    $periodo['id'],
                    $valor,
                    $nota ?: null,
                    $_SESSION['user_id']
                );
                $cambios_realizados++;
            }
        }
        
        $db->commit();
        
        // Registrar en log
        try {
            logActivity(
                'actualizar_metricas',
                'valores_metricas',
                $periodo['id'],
                "Actualizadas $cambios_realizados métricas para {$area['nombre']} - {$periodo['nombre']}"
            );
        } catch (Exception $e) {
            error_log("Error al registrar actividad: " . $e->getMessage());
        }
        
        $_SESSION['mensaje'] = "Se guardaron correctamente $cambios_realizados métricas.";
        $_SESSION['mensaje_tipo'] = 'success';
        
        // REDIRIGIR ANTES DE CUALQUIER OUTPUT
        header("Location: " . BASE_URL . "/index.php");
        exit();
        
    } catch (Exception $e) {
        if (isset($db) && $db) {
            $db->rollBack();
        }
        
        error_log("Error guardando métricas: " . $e->getMessage());
        
        $mensaje = 'Error al guardar las métricas: ' . $e->getMessage();
        $mensaje_tipo = 'danger';
    }
}
// ============================================
// FIN DE PROCESAMIENTO POST
// ============================================

// Obtener todas las áreas para selector
$areas = $areaModel->getActivas();

// Obtener períodos para selector
$periodos = $periodoModel->getRecientes(12);

// Obtener métricas del área con valores
$metricas = $metricaModel->getByAreaConValores($area_id, $periodo['id']);

// Variables para header
$page_title = 'Administrar Métricas - ' . $area['nombre'] . ' - ' . $periodo['nombre'];
$is_admin = true;

// Mensaje de éxito/error (si no hubo redirección)
$mensaje = $mensaje ?? '';
$mensaje_tipo = $mensaje_tipo ?? '';
?>

<?php include '../partials/header.php'; ?>

<!-- Contenido -->
<div class="page-body">
    <div class="container-xl">
        
        <!-- Breadcrumb / Volver -->
        <div class="mb-3">
            <a href="<?php echo BASE_URL; ?>/index.php?area=<?php echo $area_id; ?>&periodo=<?php echo $periodo_str; ?>" 
               class="btn btn-ghost-secondary">
                <i class="ti ti-arrow-left me-1"></i>
                Volver al Dashboard
            </a>
        </div>
        
        <!-- Título -->
        <div class="page-header mb-4">
            <div class="row align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        <i class="ti ti-settings me-2" style="color: <?php echo $area['color']; ?>"></i>
                        Administrar Métricas
                    </h2>
                    <div class="text-muted mt-1">
                        <?php echo $area['nombre']; ?> - <?php echo $periodo['nombre']; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Selectores de área, período y botón configurar -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row g-3 align-items-end">
                    <div class="col-md-5">
                        <label class="form-label">Área</label>
                        <select class="form-select" id="area-selector" onchange="cambiarArea(this.value)">
                            <?php foreach ($areas as $a): ?>
                                <option value="<?php echo $a['id']; ?>" <?php echo ($a['id'] == $area_id) ? 'selected' : ''; ?>>
                                    <?php echo $a['nombre']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Período</label>
                        <select class="form-select" id="periodo-selector" onchange="cambiarPeriodo(this.value)">
                            <?php foreach ($periodos as $p): ?>
                                <option value="<?php echo $p['ejercicio'] . '-' . $p['periodo']; ?>"
                                        <?php echo ($p['ejercicio'] == $ejercicio && $p['periodo'] == $periodo_mes) ? 'selected' : ''; ?>>
                                    <?php echo $p['nombre']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo BASE_URL; ?>/admin/configurar-metricas.php?area=<?php echo $area_id; ?>" 
                           class="btn btn-outline-primary w-100">
                            <i class="ti ti-adjustments me-1"></i>
                            Configurar
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Mensaje de éxito/error -->
        <?php if ($mensaje): ?>
            <div class="alert alert-<?php echo $mensaje_tipo; ?> alert-dismissible fade show" role="alert">
                <i class="ti ti-<?php echo $mensaje_tipo === 'success' ? 'check' : 'alert-circle'; ?> me-2"></i>
                <?php echo $mensaje; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- Formulario de métricas -->
        <form method="POST" action="?area=<?php echo $area_id; ?>&periodo=<?php echo $periodo_str; ?>" id="form-metricas" novalidate>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Métricas de <?php echo $area['nombre']; ?></h3>
                    <div class="card-actions">
                        <span class="text-muted">Última actualización: 
                            <?php 
                            $ultima_mod = null;
                            foreach ($metricas as $m) {
                                if (!empty($m['fecha_actualizacion'])) {
                                    if (!$ultima_mod || $m['fecha_actualizacion'] > $ultima_mod) {
                                        $ultima_mod = $m['fecha_actualizacion'];
                                    }
                                }
                            }
                            echo $ultima_mod ? formatDateTime($ultima_mod) : 'Nunca';
                            ?>
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    
                    <?php if (empty($metricas)): ?>
                        <div class="empty">
                            <div class="empty-icon">
                                <i class="ti ti-database-off"></i>
                            </div>
                            <p class="empty-title">No hay métricas configuradas</p>
                            <p class="empty-subtitle text-muted">
                                Esta área no tiene métricas definidas.
                            </p>
                        </div>
                    <?php else: ?>
                        
                        <div class="row g-4">
                            <?php foreach ($metricas as $metrica): ?>
                                <div class="col-md-6">
                                    <div class="metric-form-item <?php echo $metrica['es_calculada'] ? 'metric-calculada-item' : ''; ?>">
                                        <div class="d-flex align-items-start mb-2">
                                            <div class="metric-icon-small me-3" style="background: <?php echo $area['color']; ?>20;">
                                                <i class="ti ti-<?php echo $metrica['icono'] ?? 'chart-bar'; ?>" 
                                                   style="color: <?php echo $area['color']; ?>"></i>
                                            </div>
                                            <div class="flex-fill">
                                                <label class="form-label mb-1">
                                                    <strong><?php echo htmlspecialchars($metrica['nombre']); ?></strong>
                                                    <?php if ($metrica['unidad']): ?>
                                                        <span class="text-muted">(<?php echo $metrica['unidad']; ?>)</span>
                                                    <?php endif; ?>
                                                    <?php if ($metrica['es_calculada']): ?>
                                                        <span class="badge bg-success-lt ms-2">
                                                            <i class="ti ti-calculator"></i> AUTO
                                                        </span>
                                                    <?php endif; ?>
                                                </label>
                                                <?php if ($metrica['descripcion']): ?>
                                                    <div class="text-muted small mb-2"><?php echo htmlspecialchars($metrica['descripcion']); ?></div>
                                                <?php endif; ?>
                                                
                                                <?php if ($metrica['es_calculada']): ?>
                                                    <!-- Métrica calculada (no editable pero SÍ se envía) -->
                                                    <div class="input-group mb-2">
                                                        <span class="input-group-text bg-success-lt">
                                                            <i class="ti ti-calculator"></i>
                                                        </span>
                                                        <input type="number" 
                                                               step="<?php echo ($metrica['tipo_valor'] === 'decimal' || $metrica['tipo_valor'] === 'porcentaje') ? '0.01' : '1'; ?>"
                                                               class="form-control metrica-calculada" 
                                                               id="metrica-<?php echo $metrica['id']; ?>"
                                                               data-metrica-id="<?php echo $metrica['id']; ?>"
                                                               name="metricas[<?php echo $metrica['id']; ?>][valor]"
                                                               value="<?php echo $metrica['valor'] ?? '0'; ?>"
                                                               onclick="this.blur()"
                                                               tabindex="-1"
                                                               style="background: rgba(16, 185, 129, 0.1); font-weight: bold; color: #10b981; pointer-events: none; cursor: not-allowed;">
                                                    </div>
                                                    <small class="text-success d-block mb-2">
                                                        <i class="ti ti-info-circle me-1"></i>
                                                        Este valor se calcula automáticamente
                                                    </small>
                                                <?php else: ?>
                                                    <!-- Métrica normal (editable) -->
                                                    <input type="number" 
                                                           step="<?php echo ($metrica['tipo_valor'] === 'decimal' || $metrica['tipo_valor'] === 'porcentaje') ? '0.01' : '1'; ?>"
                                                           class="form-control mb-2 metrica-normal" 
                                                           id="metrica-<?php echo $metrica['id']; ?>"
                                                           data-metrica-id="<?php echo $metrica['id']; ?>"
                                                           name="metricas[<?php echo $metrica['id']; ?>][valor]"
                                                           value="<?php echo $metrica['valor'] ?? ''; ?>"
                                                           placeholder="Ingresa el valor">
                                                <?php endif; ?>
                                                
                                                <input type="text" 
                                                       class="form-control form-control-sm" 
                                                       name="metricas[<?php echo $metrica['id']; ?>][nota]"
                                                       value="<?php echo htmlspecialchars($metrica['nota'] ?? ''); ?>"
                                                       placeholder="Nota opcional">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                    <?php endif; ?>
                    
                </div>
                
                <?php if (!empty($metricas)): ?>
                    <div class="card-footer text-end">
                        <button type="submit" name="guardar_metricas" class="btn btn-primary">
                            <i class="ti ti-device-floppy me-1"></i>
                            Guardar Cambios
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </form>
        
    </div>
</div>

<script>
// Variables globales
let recalculandoAhora = false;

function cambiarArea(areaId) {
    const periodo = document.getElementById('periodo-selector').value;
    window.location.href = '?area=' + areaId + '&periodo=' + periodo;
}

function cambiarPeriodo(periodo) {
    const area = document.getElementById('area-selector').value;
    window.location.href = '?area=' + area + '&periodo=' + periodo;
}

// Configuración de métricas calculadas
const metricasCalculadas = {
    <?php 
    $db = getDB();
    $stmt = $db->query("
        SELECT 
            mc.metrica_calculada_id,
            GROUP_CONCAT(mc.metrica_componente_id ORDER BY mc.orden) as componentes
        FROM metricas_componentes mc
        INNER JOIN metricas m ON mc.metrica_calculada_id = m.id
        WHERE m.area_id = {$area_id} AND mc.activo = 1
        GROUP BY mc.metrica_calculada_id
    ");
    $relaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($relaciones as $rel) {
        echo $rel['metrica_calculada_id'] . ': [' . $rel['componentes'] . '],';
    }
    ?>
};

// Función para recalcular métricas
function recalcularMetricas() {
    if (recalculandoAhora) return;
    recalculandoAhora = true;
    
    setTimeout(function() {
        if (Object.keys(metricasCalculadas).length === 0) {
            recalculandoAhora = false;
            return;
        }
        
        for (const metricaId in metricasCalculadas) {
            const componentesIds = metricasCalculadas[metricaId];
            let total = 0;
            
            for (let i = 0; i < componentesIds.length; i++) {
                const input = document.getElementById('metrica-' + componentesIds[i]);
                if (input && input.value) {
                    total += parseFloat(input.value) || 0;
                }
            }
            
            const inputCalculado = document.getElementById('metrica-' + metricaId);
            if (inputCalculado) {
                const step = inputCalculado.getAttribute('step');
                if (step === '1') {
                    inputCalculado.value = Math.round(total);
                } else {
                    inputCalculado.value = total.toFixed(2);
                }
            }
        }
        
        recalculandoAhora = false;
    }, 50);
}

// Inicialización
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializar);
} else {
    inicializar();
}

function inicializar() {
    console.log('Métricas calculadas:', metricasCalculadas);
    
    // Event listeners para métricas normales
    const inputs = document.querySelectorAll('.metrica-normal');
    for (let i = 0; i < inputs.length; i++) {
        inputs[i].addEventListener('input', recalcularMetricas);
        inputs[i].addEventListener('change', recalcularMetricas);
    }
    
    // Calcular inicial
    setTimeout(recalcularMetricas, 200);
}

// IMPORTANTE: Recalcular antes de enviar el formulario
document.getElementById('form-metricas').addEventListener('submit', function(e) {
    // Asegurar que los valores calculados estén actualizados antes de enviar
    recalcularMetricas();
    
    console.log('Formulario enviado con métricas calculadas actualizadas');
});
</script>

<style>
.metric-form-item {
    background: rgba(30, 41, 59, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    padding: 16px;
    transition: all 0.3s;
}

.metric-form-item:hover {
    background: rgba(30, 41, 59, 0.5);
    border-color: rgba(255, 255, 255, 0.2);
}

.metric-calculada-item {
    border: 2px solid rgba(16, 185, 129, 0.3);
    background: rgba(16, 185, 129, 0.05);
}

.metric-calculada-item:hover {
    border-color: rgba(16, 185, 129, 0.5);
    background: rgba(16, 185, 129, 0.1);
}

.metric-icon-small {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    flex-shrink: 0;
}

.metrica-calculada {
    transition: background 0.3s ease;
}

.bg-success-lt {
    background-color: rgba(16, 185, 129, 0.1) !important;
    color: #10b981 !important;
    border-color: rgba(16, 185, 129, 0.3) !important;
}

.text-success {
    color: #10b981 !important;
}
</style>

<?php include '../partials/footer.php'; ?>
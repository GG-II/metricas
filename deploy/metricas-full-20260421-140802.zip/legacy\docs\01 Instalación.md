# 🚀 Guía de Instalación

Esta guía cubre la instalación del Dashboard de Métricas IT en un servidor Windows con IIS y MySQL.

## 📋 Requisitos Previos

### Software Requerido
- **Windows Server 2016** o superior
- **IIS 10** o superior
- **PHP 8.0+** (Recomendado: 8.5.4)
- **MySQL 8.0** o superior
- **Git** (opcional, para clonar repositorio)

### Extensiones PHP Requeridas
```ini
extension=pdo_mysql
extension=mysqli
extension=mbstring
extension=openssl
extension=curl
extension=fileinfo
extension=gd
```

---

## 📥 Instalación Paso a Paso

### 1. Preparar el Servidor

#### 1.1 Instalar IIS
```powershell
# Abrir PowerShell como Administrador
Install-WindowsFeature -name Web-Server -IncludeManagementTools
```

#### 1.2 Instalar PHP
1. Descargar PHP 8.5.4 desde [windows.php.net](https://windows.php.net/download/)
2. Extraer en `C:\php`
3. Copiar `php.ini-production` a `php.ini`
4. Editar `php.ini`:

```ini
; Habilitar extensiones
extension_dir = "C:\php\ext"
extension=pdo_mysql
extension=mysqli
extension=mbstring
extension=openssl
extension=curl

; Configuración de sesiones
session.save_path = "C:\php\sessions"

; Zona horaria
date.timezone = America/Guatemala

; Límites
upload_max_filesize = 10M
post_max_size = 10M
memory_limit = 256M
```

5. Crear carpeta de sesiones:
```powershell
New-Item -Path "C:\php\sessions" -ItemType Directory
```

#### 1.3 Configurar PHP en IIS
1. Abrir **IIS Manager**
2. Seleccionar servidor → **Handler Mappings**
3. Click **Add Module Mapping**:
   - Request path: `*.php`
   - Module: `FastCgiModule`
   - Executable: `C:\php\php-cgi.exe`
   - Name: `PHP_via_FastCGI`

#### 1.4 Instalar MySQL
1. Descargar MySQL 8.0 desde [dev.mysql.com](https://dev.mysql.com/downloads/installer/)
2. Ejecutar instalador
3. Configurar:
   - Port: `3306`
   - Root password: `(guardar seguro)`
   - Create Windows Service: `MySQL80`

---

### 2. Instalar la Aplicación

#### 2.1 Descargar Código
```powershell
# Opción A: Clonar repositorio
cd C:\inetpub\wwwroot
git clone <URL_REPOSITORIO> metricas-it

# Opción B: Descargar ZIP y extraer
# Extraer en C:\inetpub\wwwroot\metricas-it
```

#### 2.2 Configurar Permisos
```powershell
# Dar permisos a IIS_IUSRS
icacls "C:\inetpub\wwwroot\metricas-it" /grant "IIS_IUSRS:(OI)(CI)F" /T
```

#### 2.3 Crear Base de Datos

```sql
-- Conectar a MySQL
mysql -u root -p

-- Crear base de datos
CREATE DATABASE metricas_it_dev CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Crear usuario
CREATE USER 'metricas_user'@'localhost' IDENTIFIED BY 'password_seguro_aqui';
GRANT ALL PRIVILEGES ON metricas_it_dev.* TO 'metricas_user'@'localhost';
FLUSH PRIVILEGES;
```

#### 2.4 Importar Esquema

```powershell
# Importar schema.sql
cd C:\inetpub\wwwroot\metricas-it
mysql -u root -p metricas_it_dev < database/schema.sql
```

O manualmente ejecutar el SQL que está en [03-base-de-datos.md](03-base-de-datos.md)

---

### 3. Configurar la Aplicación

#### 3.1 Editar config.php

**Archivo**: `C:\inetpub\wwwroot\metricas-it\config.php`

```php
<?php
// Entorno
define('ENVIRONMENT', 'production'); // 'development' o 'production'

// Base URL
define('BASE_URL', 'https://siscoop.cicrl.com.gt/metricas-it');
define('BASE_PATH', 'C:/inetpub/wwwroot/metricas-it');

// Base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'metricas_it_dev');
define('DB_USER', 'metricas_user');
define('DB_PASS', 'password_seguro_aqui');
define('DB_CHARSET', 'utf8mb4');

// Roles
define('ROLE_ADMIN', 'admin');
define('ROLE_USER', 'user');

// Áreas (IDs)
define('AREA_SOFTWARE', 1);
define('AREA_INFRAESTRUCTURA', 2);
define('AREA_SOPORTE', 3);
define('AREA_CIBERSEGURIDAD', 4);
define('AREA_MEDIOS_DIGITALES', 5);

// Configuración de sesión
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', ENVIRONMENT === 'production' ? 1 : 0);

session_start();
```

#### 3.2 Crear Usuario Administrador

```sql
-- Conectar a MySQL
mysql -u metricas_user -p metricas_it_dev

-- Insertar usuario admin
INSERT INTO usuarios (username, password, email, nombre_completo, rol, activo, fecha_creacion)
VALUES (
    'admin',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: Admin123!
    'admin@empresa.com',
    'Administrador del Sistema',
    'admin',
    1,
    NOW()
);
```

**Nota**: Para generar un nuevo hash de password:
```php
<?php
echo password_hash('TuPasswordAqui', PASSWORD_BCRYPT);
?>
```

---

### 4. Configurar IIS

#### 4.1 Crear Sitio Web en IIS

1. Abrir **IIS Manager**
2. Click derecho en **Sites** → **Add Website**
3. Configurar:
   - Site name: `metricas-it`
   - Physical path: `C:\inetpub\wwwroot\metricas-it`
   - Binding:
     - Type: `https`
     - IP: `(All Unassigned)`
     - Port: `443`
     - Host name: `siscoop.cicrl.com.gt`
     - SSL Certificate: (seleccionar certificado)

#### 4.2 Configurar URL Rewrite (Opcional)

Si necesitas rewrite rules, instalar **URL Rewrite Module** y crear `web.config`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <rewrite>
            <rules>
                <rule name="Redirect to HTTPS" stopProcessing="true">
                    <match url="(.*)" />
                    <conditions>
                        <add input="{HTTPS}" pattern="off" ignoreCase="true" />
                    </conditions>
                    <action type="Redirect" url="https://{HTTP_HOST}/{R:1}" redirectType="Permanent" />
                </rule>
            </rules>
        </rewrite>
        <defaultDocument>
            <files>
                <add value="index.php" />
            </files>
        </defaultDocument>
    </system.webServer>
</configuration>
```

---

### 5. Verificación

#### 5.1 Probar PHP
Crear archivo `C:\inetpub\wwwroot\metricas-it\test.php`:

```php
<?php
phpinfo();
?>
```

Acceder a: `https://siscoop.cicrl.com.gt/metricas-it/test.php`

**Eliminar después de verificar**

#### 5.2 Probar Conexión BD
Crear archivo `C:\inetpub\wwwroot\metricas-it\test-db.php`:

```php
<?php
require_once 'config.php';
require_once 'includes/db.php';

try {
    $db = getDB();
    echo "✅ Conexión exitosa a la base de datos<br>";
    
    $stmt = $db->query("SELECT COUNT(*) as total FROM usuarios");
    $result = $stmt->fetch();
    echo "✅ Usuarios en BD: " . $result['total'];
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
```

**Eliminar después de verificar**

#### 5.3 Acceder al Sistema

1. Ir a: `https://siscoop.cicrl.com.gt/metricas-it/`
2. Login con:
   - Usuario: `admin`
   - Password: `Admin123!`

---

## 🔒 Seguridad Post-Instalación

### 1. Cambiar Password de Admin
```sql
UPDATE usuarios 
SET password = '$2y$10$NUEVO_HASH_AQUI'
WHERE username = 'admin';
```

### 2. Eliminar Archivos de Test
```powershell
del C:\inetpub\wwwroot\metricas-it\test.php
del C:\inetpub\wwwroot\metricas-it\test-db.php
```

### 3. Configurar Backups Automáticos
```powershell
# Crear script de backup
# Ver sección en 08-despliegue.md
```

### 4. Habilitar Logs
```php
// En config.php (solo development)
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
    ini_set('error_log', BASE_PATH . '/logs/php_errors.log');
}
```

---

## ✅ Checklist de Instalación

- [ ] IIS instalado y funcionando
- [ ] PHP 8.5+ instalado con extensiones
- [ ] MySQL 8.0+ instalado
- [ ] Base de datos creada
- [ ] Usuario de BD creado
- [ ] Esquema importado
- [ ] config.php configurado
- [ ] Usuario admin creado
- [ ] Permisos de carpetas configurados
- [ ] Sitio web en IIS creado
- [ ] Certificado SSL configurado
- [ ] Pruebas de PHP exitosas
- [ ] Pruebas de BD exitosas
- [ ] Login funcionando
- [ ] Archivos de test eliminados
- [ ] Password de admin cambiado

---

## 🆘 Problemas Comunes

### Error: "Cannot connect to MySQL"
- Verificar que MySQL80 service esté corriendo
- Verificar credenciales en config.php
- Verificar firewall no bloquee puerto 3306

### Error: "Session could not be started"
- Verificar que carpeta `C:\php\sessions` existe
- Verificar permisos en carpeta de sesiones

### Error 500 en IIS
- Revisar Event Viewer → Application
- Habilitar `display_errors` temporalmente
- Verificar permisos de IIS_IUSRS

### Páginas sin estilos
- Verificar BASE_URL en config.php
- Verificar permisos en carpeta `assets/`

---

## 📚 Siguiente Paso

Continuar con [02-arquitectura.md](02-arquitectura.md) para entender la estructura del sistema.
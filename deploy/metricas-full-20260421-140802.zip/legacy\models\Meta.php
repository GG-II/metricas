<?php
/**
 * Modelo: Meta
 * Gestión de metas/objetivos para métricas por período
 */

require_once __DIR__ . '/Model.php';

class Meta extends Model {
    protected $table = 'metas_metricas';
    
    /**
     * Obtener meta de una métrica para un período específico
     * Si la métrica es calculada, suma las metas de los componentes
     */
    public function getByMetricaYPeriodo($metrica_id, $periodo_id) {
        // Primero verificar si la métrica es calculada
        $stmt = $this->db->prepare("SELECT es_calculada FROM metricas WHERE id = ?");
        $stmt->execute([$metrica_id]);
        $metrica = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$metrica) {
            return null;
        }
        
        // Si es calculada, intentar calcular la meta
        if ($metrica['es_calculada']) {
            $meta_calculada = $this->calcularMetaCalculada($metrica_id, $periodo_id);
            if ($meta_calculada !== null) {
                return $meta_calculada;
            }
        }
        
        // Buscar meta directa
        $sql = "SELECT * FROM {$this->table} 
                WHERE metrica_id = ? AND periodo_id = ? AND activo = 1";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$metrica_id, $periodo_id]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Calcular meta para métrica calculada (suma de metas de componentes)
     * Retorna array con estructura de meta si TODAS las componentes tienen meta
     * Retorna null si no todas tienen meta o no hay componentes
     */
    public function calcularMetaCalculada($metrica_id, $periodo_id) {
        // Obtener componentes de la métrica calculada
        $sql = "SELECT metrica_componente_id 
                FROM metricas_componentes 
                WHERE metrica_calculada_id = ? AND activo = 1
                ORDER BY orden";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$metrica_id]);
        $componentes = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (empty($componentes)) {
            return null;
        }
        
        // Obtener metas de todos los componentes
        $placeholders = implode(',', array_fill(0, count($componentes), '?'));
        $sql = "SELECT metrica_id, valor_objetivo, tipo_comparacion, valor_min, valor_max
                FROM {$this->table}
                WHERE metrica_id IN ($placeholders) 
                  AND periodo_id = ? 
                  AND activo = 1";
        
        $params = array_merge($componentes, [$periodo_id]);
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $metas_componentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Verificar que TODAS las componentes tengan meta
        if (count($metas_componentes) !== count($componentes)) {
            return null; // No todas tienen meta
        }
        
        // Sumar las metas (solo valores_objetivo)
        $suma_objetivos = 0;
        $tipo_comparacion = $metas_componentes[0]['tipo_comparacion']; // Usar el tipo de la primera
        
        foreach ($metas_componentes as $meta) {
            $suma_objetivos += $meta['valor_objetivo'];
        }
        
        // Retornar estructura de meta calculada
        return [
            'id' => null, // No existe en BD
            'metrica_id' => $metrica_id,
            'periodo_id' => $periodo_id,
            'valor_objetivo' => $suma_objetivos,
            'tipo_comparacion' => $tipo_comparacion,
            'valor_min' => null,
            'valor_max' => null,
            'activo' => 1,
            'es_calculada' => true // Flag para identificarla
        ];
    }
    
    /**
     * Obtener todas las metas de un período
     * Opcionalmente filtrar por área
     */
    public function getByPeriodo($periodo_id, $area_id = null) {
        $sql = "SELECT mm.*, m.nombre as metrica_nombre, m.slug as metrica_slug,
                       m.area_id, a.nombre as area_nombre
                FROM {$this->table} mm
                INNER JOIN metricas m ON mm.metrica_id = m.id
                INNER JOIN areas a ON m.area_id = a.id
                WHERE mm.periodo_id = ? AND mm.activo = 1";
        
        $params = [$periodo_id];
        
        if ($area_id !== null) {
            $sql .= " AND m.area_id = ?";
            $params[] = $area_id;
        }
        
        $sql .= " ORDER BY a.orden, m.orden";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Obtener metas de un área para un período
     * Incluye información de la métrica
     */
    public function getByAreaYPeriodo($area_id, $periodo_id) {
        $sql = "SELECT 
                    m.id as metrica_id,
                    m.nombre as metrica_nombre,
                    m.slug as metrica_slug,
                    m.tipo_valor,
                    m.unidad,
                    m.es_calculada,
                    mm.id as meta_id,
                    mm.valor_objetivo,
                    mm.tipo_comparacion,
                    mm.valor_min,
                    mm.valor_max
                FROM metricas m
                LEFT JOIN {$this->table} mm ON m.id = mm.metrica_id 
                    AND mm.periodo_id = ? 
                    AND mm.activo = 1
                WHERE m.area_id = ? AND m.activo = 1
                ORDER BY m.orden";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$periodo_id, $area_id]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Crear o actualizar meta
     * Si ya existe para esa métrica+período, actualiza; si no, crea
     */
    public function createOrUpdate($data) {
        // Verificar si ya existe
        $sql = "SELECT id FROM {$this->table} 
                WHERE metrica_id = ? AND periodo_id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$data['metrica_id'], $data['periodo_id']]);
        $existe = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existe) {
            // Actualizar
            return $this->update($existe['id'], $data);
        } else {
            // Crear
            return $this->create($data);
        }
    }
    
    /**
     * Copiar metas de un período a otro
     * Opcionalmente filtrar por área
     */
    public function copiarMetas($periodo_origen_id, $periodo_destino_id, $area_id = null, $sobrescribir = false) {
        $this->db->beginTransaction();
        
        try {
            // Si sobrescribir, eliminar metas existentes en destino
            if ($sobrescribir) {
                $sql = "DELETE mm FROM {$this->table} mm
                        INNER JOIN metricas m ON mm.metrica_id = m.id
                        WHERE mm.periodo_id = ?";
                
                $params = [$periodo_destino_id];
                
                if ($area_id !== null) {
                    $sql .= " AND m.area_id = ?";
                    $params[] = $area_id;
                }
                
                $stmt = $this->db->prepare($sql);
                $stmt->execute($params);
            }
            
            // Obtener metas del período origen
            $sql = "SELECT mm.metrica_id, mm.valor_objetivo, mm.tipo_comparacion,
                           mm.valor_min, mm.valor_max
                    FROM {$this->table} mm
                    INNER JOIN metricas m ON mm.metrica_id = m.id
                    WHERE mm.periodo_id = ? AND mm.activo = 1";
            
            $params = [$periodo_origen_id];
            
            if ($area_id !== null) {
                $sql .= " AND m.area_id = ?";
                $params[] = $area_id;
            }
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $metas_origen = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $copiadas = 0;
            $saltadas = 0;
            
            foreach ($metas_origen as $meta) {
                // Verificar si ya existe en destino
                $sql_check = "SELECT id FROM {$this->table} 
                              WHERE metrica_id = ? AND periodo_id = ?";
                $stmt_check = $this->db->prepare($sql_check);
                $stmt_check->execute([$meta['metrica_id'], $periodo_destino_id]);
                
                if ($stmt_check->fetch() && !$sobrescribir) {
                    $saltadas++;
                    continue;
                }
                
                // Insertar nueva meta
                $sql_insert = "INSERT INTO {$this->table} 
                               (metrica_id, periodo_id, valor_objetivo, tipo_comparacion, 
                                valor_min, valor_max, activo)
                               VALUES (?, ?, ?, ?, ?, ?, 1)
                               ON DUPLICATE KEY UPDATE
                               valor_objetivo = VALUES(valor_objetivo),
                               tipo_comparacion = VALUES(tipo_comparacion),
                               valor_min = VALUES(valor_min),
                               valor_max = VALUES(valor_max)";
                
                $stmt_insert = $this->db->prepare($sql_insert);
                $stmt_insert->execute([
                    $meta['metrica_id'],
                    $periodo_destino_id,
                    $meta['valor_objetivo'],
                    $meta['tipo_comparacion'],
                    $meta['valor_min'],
                    $meta['valor_max']
                ]);
                
                $copiadas++;
            }
            
            $this->db->commit();
            
            return [
                'success' => true,
                'copiadas' => $copiadas,
                'saltadas' => $saltadas,
                'total' => count($metas_origen)
            ];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
    
    /**
     * Eliminar meta (soft delete)
     */
    public function eliminar($id) {
        return $this->update($id, ['activo' => 0]);
    }
    
    /**
     * Eliminar meta de una métrica en un período específico
     */
    public function eliminarPorMetricaYPeriodo($metrica_id, $periodo_id) {
        $sql = "UPDATE {$this->table} 
                SET activo = 0 
                WHERE metrica_id = ? AND periodo_id = ?";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$metrica_id, $periodo_id]);
    }
    
    /**
     * Validar consistencia de meta
     * Retorna array con errores o null si todo está bien
     */
    public function validarMeta($data) {
        $errores = [];
        
        // Validar que valor_objetivo sea positivo
        if (isset($data['valor_objetivo']) && $data['valor_objetivo'] <= 0) {
            $errores[] = "El valor objetivo debe ser mayor a 0";
        }
        
        // Validar rango
        if (isset($data['tipo_comparacion']) && $data['tipo_comparacion'] === 'rango') {
            if (!isset($data['valor_min']) || !isset($data['valor_max'])) {
                $errores[] = "Para tipo 'rango' debe especificar valor mínimo y máximo";
            } elseif ($data['valor_min'] >= $data['valor_max']) {
                $errores[] = "El valor mínimo debe ser menor que el máximo";
            }
            
            // Validar que objetivo esté dentro del rango
            if (isset($data['valor_objetivo'])) {
                if ($data['valor_objetivo'] < $data['valor_min'] || 
                    $data['valor_objetivo'] > $data['valor_max']) {
                    $errores[] = "El valor objetivo debe estar dentro del rango especificado";
                }
            }
        }
        
        return empty($errores) ? null : $errores;
    }
    
    /**
     * Obtener estadísticas de cumplimiento de metas para un período
     */
    public function getEstadisticasCumplimiento($periodo_id, $area_id = null) {
        $sql = "SELECT 
                    COUNT(*) as total_metas,
                    SUM(CASE 
                        WHEN mm.tipo_comparacion = 'mayor_igual' AND COALESCE(vm.valor_numero, vm.valor_decimal) >= mm.valor_objetivo THEN 1
                        WHEN mm.tipo_comparacion = 'menor_igual' AND COALESCE(vm.valor_numero, vm.valor_decimal) <= mm.valor_objetivo THEN 1
                        WHEN mm.tipo_comparacion = 'rango' AND COALESCE(vm.valor_numero, vm.valor_decimal) BETWEEN mm.valor_min AND mm.valor_max THEN 1
                        WHEN mm.tipo_comparacion = 'igual' AND COALESCE(vm.valor_numero, vm.valor_decimal) = mm.valor_objetivo THEN 1
                        ELSE 0
                    END) as metas_cumplidas,
                    AVG(CASE 
                        WHEN mm.tipo_comparacion = 'mayor_igual' THEN 
                            (COALESCE(vm.valor_numero, vm.valor_decimal) / mm.valor_objetivo) * 100
                        WHEN mm.tipo_comparacion = 'menor_igual' THEN 
                            CASE WHEN COALESCE(vm.valor_numero, vm.valor_decimal) <= mm.valor_objetivo THEN 100 ELSE 0 END
                        ELSE 100
                    END) as cumplimiento_promedio
                FROM {$this->table} mm
                INNER JOIN metricas m ON mm.metrica_id = m.id
                LEFT JOIN valores_metricas vm ON mm.metrica_id = vm.metrica_id AND mm.periodo_id = vm.periodo_id
                WHERE mm.periodo_id = ? AND mm.activo = 1";
        
        $params = [$periodo_id];
        
        if ($area_id !== null) {
            $sql .= " AND m.area_id = ?";
            $params[] = $area_id;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
# 👨‍💼 Guía de Administrador

Manual completo para administradores del Dashboard de Métricas IT.

## 🎯 Introducción

Como administrador, tienes acceso completo al sistema para:
- ✅ Configurar métricas y gráficos
- ✅ Capturar valores de métricas
- ✅ Gestionar usuarios
- ✅ Crear métricas calculadas automáticas

---

## 🔐 Acceso Administrativo

### Login

1. Accede a: `https://siscoop.cicrl.com.gt/metricas-it/`
2. Usuario: `admin`
3. Contraseña: (la que configuraste)

### Panel de Administración

Después de login, verás opciones adicionales en el menú:
- **⚙️ Configurar Métricas**
- **📊 Configurar Gráficos**
- **👥 Gestionar Usuarios**
- **📝 Administrar Métricas** (captura de valores)

---

## 📊 Gestión de Métricas

### Ver Métricas Configuradas

1. Click en **Configurar Métricas** en el menú
2. Selecciona el **Área**
3. Verás lista de métricas existentes:

```
┌────────────────────────────────────────────────────┐
│ Métricas de Software Factory                       │
├────────────────────────────────────────────────────┤
│ [Editar] [Eliminar] Tickets Resueltos             │
│ [Editar] [Eliminar] Tiempo Promedio Respuesta     │
│ [Editar] [Eliminar] Satisfacción Cliente          │
└────────────────────────────────────────────────────┘
```

---

### Crear Nueva Métrica

#### Paso 1: Datos Básicos

1. Click en **Nueva Métrica**
2. Completa el formulario:

**Información General:**
- **Nombre**: Descriptivo y único (ej: "Tickets Resueltos")
- **Descripción**: Qué mide esta métrica
- **Área**: A qué departamento pertenece

**Tipo de Valor:**
- **Entero**: Para números sin decimales (ej: 150)
- **Decimal**: Para números con decimales (ej: 98.5)
- **Porcentaje**: Se muestra con % (ej: 87%)
- **Moneda**: Se muestra con $ (ej: $5,000)

**Configuración:**
- **Unidad**: tickets, horas, %, GB, etc.
- **Valor Objetivo**: Meta a alcanzar (opcional)
- **Ícono**: De la librería Tabler Icons
- **Color**: Código hexadecimal (#0d6efd)

**Ejemplo**:
```
Nombre: Disponibilidad de Servidores
Descripción: Porcentaje de tiempo que los servidores están disponibles
Tipo de Valor: Porcentaje
Unidad: %
Valor Objetivo: 95
Ícono: ti-server
Color: #198754
```

#### Paso 2: Métrica Calculada (Opcional)

Si esta métrica se calcula automáticamente:

1. ✅ Marcar: **"Esta métrica se calcula sumando otras métricas"**
2. Aparecerá lista de métricas del área
3. Selecciona los **componentes** que suman:

**Ejemplo**:
```
Métrica: Total Transacciones CIC Virtual
Componentes:
  ☑ Transacciones Operativo
  ☑ Transacciones Créditos
  ☐ Otras métricas...
```

**Resultado**: Total = Operativo + Créditos (automático)

#### Paso 3: Guardar

1. Click en **Guardar**
2. Verás mensaje de confirmación
3. La métrica aparece en la lista

---

### Editar Métrica Existente

1. En lista de métricas, click **Editar** (ícono lápiz)
2. Modifica los campos necesarios
3. **Guardar Cambios**

**Cambios permitidos**:
- ✅ Nombre, descripción
- ✅ Objetivo, color, ícono
- ✅ Componentes (si es calculada)
- ⚠️ Cambiar tipo de valor puede afectar datos históricos

---

### Eliminar Métrica

1. Click en **Eliminar** (ícono basura)
2. Confirma la eliminación
3. ⚠️ **CUIDADO**: Se eliminarán también todos los valores históricos

**Alternativa**: Desactivar en lugar de eliminar:
1. Editar métrica
2. Desmarcar **"Activo"**
3. Guardar

La métrica se oculta pero conserva datos históricos.

---

## 📈 Captura de Valores de Métricas

### Proceso Mensual

1. Click en **Administrar Métricas**
2. Selecciona **Área** y **Período**
3. Verás formulario con todas las métricas:

```
┌────────────────────────────────────────────────────┐
│ Métricas de Software Factory - Marzo 2026         │
├────────────────────────────────────────────────────┤
│ 📋 Tickets Resueltos                               │
│ [    150    ]  💬 Nota: Incluye tickets nivel 1-3 │
│                                                     │
│ ⏱️ Tiempo Promedio Respuesta                       │
│ [    2.5    ] horas  💬 Nota opcional...           │
│                                                     │
│ 🧮 Total Transacciones        [AUTO]              │
│ [   10,049  ]  ← Calculado automáticamente        │
└────────────────────────────────────────────────────┘
```

### Ingresar Valores

#### Métricas Normales

1. Click en el campo de valor
2. Ingresa el número
3. (Opcional) Agrega una nota
4. Continúa con la siguiente métrica

**Ejemplo**:
```
Tickets Resueltos: 150
Nota: Incluye tickets nivel 1, 2 y 3
```

#### Métricas Calculadas

**NO necesitas ingresar valor**, se calcula automáticamente:

```
Métrica Calculada:
  Input: [10,049] ← Verde, readonly
  Badge: 🧮 AUTO
  
Componentes:
  Trans. Operativo:  1,904  ←
  Trans. Créditos:   8,145  ←  Ingresaste estos
  ─────────────────────────
  Total automático: 10,049  ← Se suma solo
```

**En tiempo real**:
- Mientras ingresas los componentes
- El total se actualiza automáticamente
- No puedes editar el campo calculado

---

### Guardar Datos

1. Revisa que todos los valores sean correctos
2. Click en **Guardar Cambios**
3. Sistema guarda:
   - ✅ Valores normales
   - ✅ Valores calculados
   - ✅ Notas
   - ✅ Fecha/hora de actualización
4. Redirige al dashboard con mensaje de éxito

---

### Editar Valores Existentes

Para corregir valores ya guardados:

1. **Administrar Métricas**
2. Selecciona **Área** y **Período**
3. Los valores actuales aparecen pre-llenados
4. Modifica los necesarios
5. **Guardar Cambios**

⚠️ **Nota**: Se sobreescriben los valores anteriores.

---

## 🎨 Configuración de Gráficos

### Ver Gráficos del Dashboard

1. Click en **Configurar Gráficos**
2. Selecciona **Área**
3. Verás lista de gráficos:

```
┌────────────────────────────────────────────────────┐
│ Gráficos de Software Factory                       │
├────────────────────────────────────────────────────┤
│ [Editar] [Eliminar] KPI - Tickets Resueltos       │
│ [Editar] [Eliminar] Progress - Disponibilidad     │
│ [Editar] [Eliminar] Bar - Tickets por Prioridad   │
└────────────────────────────────────────────────────┘
```

---

### Crear Nuevo Gráfico

#### Paso 1: Tipo de Gráfico

Elige el tipo según tus necesidades:

| Tipo | Cuándo Usarlo |
|------|---------------|
| **KPI Card** | Mostrar un solo valor destacado |
| **Progress** | Comparar valor vs objetivo |
| **Bar** | Comparar múltiples categorías |
| **Line** | Mostrar tendencia temporal |
| **Comparison** | Comparar actual vs anterior |
| **Multi-Bar** | Varias métricas en barras |
| **Donut** | Distribución en porcentajes |
| **Gauge** | Valor en rango con zonas |
| **Data Table** | Ranking o listado |

#### Paso 2: Configuración Básica

**Todos los gráficos requieren**:
- **Título**: Nombre del gráfico
- **Descripción**: Explicación breve
- **Métricas**: Qué métricas mostrar

**Ejemplo KPI Card**:
```
Título: Tickets Resueltos del Mes
Descripción: Total de tickets cerrados satisfactoriamente
Métricas: [Tickets Resueltos]
Color: #0d6efd (Azul)
Ícono: ti-checkbox
```

**Ejemplo Gráfico de Barras**:
```
Título: Tickets por Prioridad
Descripción: Distribución de tickets según urgencia
Métricas: 
  - Tickets Alta Prioridad
  - Tickets Media Prioridad
  - Tickets Baja Prioridad
```

#### Paso 3: Configuración Avanzada

**Progress Bar**:
- ✅ Mostrar Objetivo: Sí/No
- Color de fondo de barra
- Color de progreso

**Line Chart**:
- Número de períodos a mostrar: 6, 12, etc.
- Tipo de línea: Recta, Curva
- Mostrar puntos: Sí/No

**Gauge**:
- Valor Mínimo: 0
- Valor Máximo: 100
- Zonas de Color:
  - 0-60: Rojo (Crítico)
  - 60-80: Amarillo (Advertencia)
  - 80-100: Verde (Óptimo)

#### Paso 4: Posición y Tamaño

**GridStack usa unidades de cuadrícula (12 columnas)**:

```
Ancho:
  4 = 1/3 del ancho (3 gráficos por fila)
  6 = 1/2 del ancho (2 gráficos por fila)
  12 = Ancho completo

Alto:
  3 = Pequeño
  4 = Mediano
  5 = Grande
```

**Ejemplo**:
```
KPI Card:      Ancho: 4,  Alto: 3
Progress Bar:  Ancho: 6,  Alto: 4
Line Chart:    Ancho: 12, Alto: 5
```

#### Paso 5: Guardar

1. Click en **Crear Gráfico**
2. Aparecerá en el dashboard del área seleccionada
3. Usuarios pueden reorganizarlo con drag & drop

---

### Editar Gráfico Existente

1. **Configurar Gráficos**
2. Click en **Editar**
3. Modifica configuración
4. **Guardar Cambios**

**Cambios comunes**:
- Cambiar métricas mostradas
- Ajustar colores y título
- Modificar tamaño inicial

---

### Eliminar Gráfico

1. Click en **Eliminar**
2. Confirmar
3. Se elimina del dashboard

⚠️ **Nota**: Los datos de métricas NO se eliminan, solo el gráfico.

---

## 👥 Gestión de Usuarios

### Crear Nuevo Usuario

1. **Gestionar Usuarios** → **Nuevo Usuario**
2. Completa:

```
Username: jperez
Email: jperez@empresa.com
Nombre Completo: Juan Pérez
Rol: 
  ○ Usuario (solo lectura)
  ● Administrador (control total)
Contraseña: ****** (temporal)
```

3. **Guardar**
4. Comparte credenciales con el usuario
5. Pídele que cambie su contraseña al primer login

---

### Roles y Permisos

| Permiso | Usuario | Admin |
|---------|---------|-------|
| Ver dashboard | ✅ | ✅ |
| Cambiar área/período | ✅ | ✅ |
| Reorganizar gráficos | ✅ | ✅ |
| Capturar métricas | ❌ | ✅ |
| Configurar métricas | ❌ | ✅ |
| Configurar gráficos | ❌ | ✅ |
| Gestionar usuarios | ❌ | ✅ |

---

### Editar Usuario

1. En lista de usuarios, click **Editar**
2. Modifica datos
3. **Guardar Cambios**

**Cambios permitidos**:
- Nombre, email
- Rol (Usuario ↔ Admin)
- Estado (Activo/Inactivo)
- Foto de perfil

---

### Desactivar Usuario

En lugar de eliminar:

1. **Editar** usuario
2. Cambiar estado a **Inactivo**
3. **Guardar**

**Efecto**:
- No puede iniciar sesión
- Datos históricos se conservan
- Puede reactivarse después

---

### Resetear Contraseña

1. **Editar** usuario
2. Click en **Resetear Contraseña**
3. Genera contraseña temporal
4. Comparte con el usuario
5. Usuario debe cambiarla al login

---

## 🧮 Métricas Calculadas Avanzado

### Conceptos

**Métrica Calculada**: Se obtiene sumando otras métricas (componentes).

**Ejemplo Real**:
```
Total Transacciones = Trans. Operativo + Trans. Créditos + Trans. Otros
                    = 1,904 + 8,145 + 500
                    = 10,549
```

---

### Crear Métrica Calculada

#### Paso 1: Identificar Componentes

**Pregúntate**:
- ¿Qué métricas necesito sumar?
- ¿Ya existen en el sistema?
- ¿Pertenecen a la misma área?

**Ejemplo**:
```
Objetivo: Total de Ventas Online

Componentes existentes:
  ✅ Ventas Sitio Web
  ✅ Ventas App Móvil
  ✅ Ventas Marketplace

Todos en área: Medios Digitales ✅
```

#### Paso 2: Crear Componentes Primero

Si no existen, créalos como métricas normales:

```
1. Crear: Ventas Sitio Web (normal)
2. Crear: Ventas App Móvil (normal)
3. Crear: Ventas Marketplace (normal)
```

#### Paso 3: Crear Métrica Calculada

1. **Nueva Métrica**
2. Nombre: "Total Ventas Online"
3. ✅ Marcar: **"Esta métrica se calcula sumando otras métricas"**
4. Aparece lista de métricas del área
5. Seleccionar componentes:
   ```
   ☑ Ventas Sitio Web
   ☑ Ventas App Móvil
   ☑ Ventas Marketplace
   ```
6. **Guardar**

#### Paso 4: Verificar Funcionamiento

1. **Administrar Métricas** → Área correspondiente
2. Ingresar valores en componentes:
   ```
   Sitio Web:    $5,000
   App Móvil:    $3,000
   Marketplace:  $2,000
   ```
3. Ver que Total se calcula automático:
   ```
   Total Ventas Online: $10,000 [AUTO]
   ```

---

### Buenas Prácticas

✅ **Usa nombres descriptivos**:
- ❌ "Total 1", "Suma A+B"
- ✅ "Total Transacciones CIC Virtual"

✅ **Documenta en descripción**:
```
Descripción: Suma de transacciones operativas y de créditos 
realizadas en CIC Virtual
```

✅ **Agrupa por área**:
- Componentes y calculada en la misma área
- Facilita búsqueda y mantenimiento

✅ **Verifica unidades compatibles**:
- ❌ Sumar "tickets" + "horas"
- ✅ Sumar "transacciones" + "transacciones"

---

### Limitaciones Actuales

⚠️ **Solo operación SUMA**:
- ✅ A + B + C
- ❌ A - B
- ❌ A × B
- ❌ A ÷ B

⚠️ **Componentes del mismo tipo**:
- Todos enteros, o todos decimales
- No mezclar tipos diferentes

⚠️ **Sin fórmulas complejas**:
- ❌ (A + B) / C × 100
- ✅ Crear métricas intermedias si es necesario

---

## 📅 Gestión de Períodos

### Crear Nuevo Período

Los períodos se crean automáticamente, pero puedes hacerlo manualmente:

```sql
INSERT INTO periodos (ejercicio, periodo, nombre, fecha_inicio, fecha_fin)
VALUES (2027, 1, 'Enero 2027', '2027-01-01', '2027-01-31');
```

### Cerrar Período

Para evitar modificaciones accidentales:

1. Acceder a BD
2. Ejecutar:
```sql
UPDATE periodos 
SET activo = 0 
WHERE ejercicio = 2025 AND periodo = 12;
```

**Efecto**:
- No aparece en selector de períodos
- Datos se conservan
- Solo lectura vía BD

---

## 📊 Reportes y Análisis

### Exportar Datos

**Opción 1: Via BD**

```sql
-- Exportar métricas de un período
SELECT 
    a.nombre as area,
    m.nombre as metrica,
    COALESCE(vm.valor_numero, vm.valor_decimal) as valor,
    m.unidad
FROM metricas m
INNER JOIN areas a ON m.area_id = a.id
LEFT JOIN valores_metricas vm ON m.id = vm.metrica_id
WHERE vm.periodo_id = 15  -- Período deseado
ORDER BY a.nombre, m.nombre;
```

**Opción 2: Crear Vista SQL**

```sql
CREATE VIEW vista_metricas_actual AS
SELECT 
    a.nombre as area,
    m.nombre as metrica,
    p.nombre as periodo,
    COALESCE(vm.valor_numero, vm.valor_decimal) as valor,
    m.unidad,
    m.valor_objetivo,
    vm.fecha_actualizacion
FROM valores_metricas vm
INNER JOIN metricas m ON vm.metrica_id = m.id
INNER JOIN areas a ON m.area_id = a.id
INNER JOIN periodos p ON vm.periodo_id = p.id
WHERE p.ejercicio = YEAR(CURDATE());
```

---

## 🔧 Mantenimiento del Sistema

### Limpieza de Logs

```sql
-- Eliminar logs antiguos (más de 6 meses)
DELETE FROM log_actividad 
WHERE fecha < DATE_SUB(NOW(), INTERVAL 6 MONTH);
```

### Backup de Base de Datos

**Mensual (manual)**:
```bash
mysqldump -u metricas_user -p metricas_it_dev > backup_abril_2026.sql
```

**Automatizado** (crear script .bat):
```batch
@echo off
set FECHA=%date:~-4,4%%date:~-10,2%%date:~-7,2%
mysqldump -u metricas_user -pPASSWORD metricas_it_dev > C:\backups\metricas_%FECHA%.sql
```

Programar en Task Scheduler (Windows) para ejecutar cada noche.

---

### Verificar Integridad de Datos

```sql
-- Métricas calculadas sin componentes
SELECT m.id, m.nombre
FROM metricas m
LEFT JOIN metricas_componentes mc ON m.id = mc.metrica_calculada_id
WHERE m.es_calculada = 1 AND mc.id IS NULL;

-- Valores fuera de rango
SELECT m.nombre, vm.valor_numero, m.valor_objetivo
FROM valores_metricas vm
INNER JOIN metricas m ON vm.metrica_id = m.id
WHERE vm.valor_numero > m.valor_objetivo * 2;  -- 2x objetivo
```

---

## 🚨 Resolución de Problemas Comunes

### Usuario No Puede Iniciar Sesión

**Verificar**:
1. Usuario está **Activo**
2. Contraseña correcta
3. No hay caracteres especiales en username

**Solución**:
```sql
-- Verificar estado
SELECT username, activo FROM usuarios WHERE username = 'jperez';

-- Reactivar si está inactivo
UPDATE usuarios SET activo = 1 WHERE username = 'jperez';

-- Resetear password
UPDATE usuarios 
SET password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
WHERE username = 'jperez';
-- Nueva contraseña: Admin123!
```

---

### Gráfico No Muestra Datos

**Diagnóstico**:
1. ¿Existen valores para el período?
```sql
SELECT * FROM valores_metricas 
WHERE metrica_id = 12 AND periodo_id = 15;
```

2. ¿Métrica está activa?
```sql
SELECT activo FROM metricas WHERE id = 12;
```

3. ¿JSON del gráfico es válido?
```sql
SELECT JSON_VALID(configuracion_json) FROM graficos WHERE id = 5;
```

---

### Métrica Calculada No Se Actualiza

**Ver troubleshooting completo**: [09-troubleshooting.md](09-troubleshooting.md#métricas-calculadas-no-se-actualizan)

**Quick fix**:
1. F12 → Console
2. Ejecutar: `recalcularMetricas()`
3. Si funciona → problema de event listeners
4. Si no funciona → verificar configuración

---

## 📚 Checklist Mensual

### Al Inicio del Mes

- [ ] Verificar que período nuevo existe en BD
- [ ] Revisar que todas las áreas tienen métricas activas
- [ ] Recordar a equipos que capturen valores

### Durante el Mes

- [ ] Capturar valores conforme estén disponibles
- [ ] Verificar que métricas calculadas sumen correctamente
- [ ] Responder dudas de usuarios

### Fin de Mes

- [ ] Completar métricas faltantes
- [ ] Revisar anomalías en valores
- [ ] Generar reportes si es necesario
- [ ] Backup de base de datos

---

## 🎓 Capacitación de Nuevos Admins

### Temas a Cubrir

1. **Sesión 1: Conceptos** (1 hora)
   - Áreas, Períodos, Métricas
   - Dashboard y navegación
   - Roles y permisos

2. **Sesión 2: Configuración** (2 horas)
   - Crear métricas normales
   - Crear métricas calculadas
   - Configurar gráficos

3. **Sesión 3: Captura** (1 hora)
   - Proceso mensual
   - Validación de datos
   - Corrección de errores

4. **Sesión 4: Administración** (1 hora)
   - Gestión de usuarios
   - Backup y mantenimiento
   - Troubleshooting básico

---

## 📖 Referencias Rápidas

### Códigos de Color Recomendados

```
Azul:      #0d6efd  (Principal)
Verde:     #198754  (Éxito/Positivo)
Amarillo:  #ffc107  (Advertencia)
Rojo:      #dc3545  (Error/Crítico)
Púrpura:   #6f42c1  (Especial)
Naranja:   #fd7e14  (Información)
Cyan:      #0dcaf0  (Neutral)
```

### Iconos Tabler Comunes

```
ti-chart-bar     Gráficos
ti-server        Servidores
ti-headset       Soporte
ti-shield-lock   Seguridad
ti-code          Desarrollo
ti-users         Usuarios
ti-calendar      Períodos
ti-settings      Configuración
```

Ver más: https://tabler-icons.io/

---

**Versión**: 1.0  
**Última actualización**: Abril 2026  
**Mantenedor**: Equipo IT
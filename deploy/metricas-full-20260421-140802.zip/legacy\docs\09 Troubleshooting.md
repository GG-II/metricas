# 🆘 Troubleshooting - Solución de Problemas

Guía de resolución de problemas comunes del sistema.

## 📑 Índice Rápido

- [Error 500 al guardar métricas](#error-500-al-guardar-métricas)
- [Métricas calculadas no se actualizan](#métricas-calculadas-no-se-actualizan)
- [Dashboard no carga gráficos](#dashboard-no-carga-gráficos)
- [GridStack no guarda posiciones](#gridstack-no-guarda-posiciones)
- [Estilos rotos o sin CSS](#estilos-rotos-o-sin-css)
- [Error de conexión a BD](#error-de-conexión-a-bd)
- [Sesiones no funcionan](#sesiones-no-funcionan)
- [Headers already sent](#headers-already-sent)

---

## 🔴 Error 500 al Guardar Métricas

### Síntomas
```
POST https://siscoop.cicrl.com.gt/metricas-it/admin/metricas.php 500 (Internal Server Error)
```

Los datos SE guardan en BD, pero la redirección falla y muestra error 500.

### Causa Raíz
El archivo `includes/calcular-metricas.php` tiene errores que rompen el flujo después del guardado exitoso.

### Solución

**Opción 1: Deshabilitar cálculo backend (Recomendado)**

El cálculo ya se hace en frontend con JavaScript, así que el backend es redundante.

**Editar**: `admin/metricas.php`

```php
// COMENTAR o ELIMINAR estas líneas (85-94):
/*
try {
    if (file_exists(BASE_PATH . '/includes/calcular-metricas.php')) {
        require_once BASE_PATH . '/includes/calcular-metricas.php';
        calcularMetricasAutomaticas($periodo['id']);
    }
} catch (Exception $e) {
    error_log("Error al calcular métricas automáticas: " . $e->getMessage());
}
*/
```

**Opción 2: Arreglar calcular-metricas.php**

Si necesitas el cálculo backend, asegúrate que el archivo existe y tiene manejo de errores:

```php
<?php
function calcularMetricasAutomaticas($periodo_id) {
    try {
        $db = getDB();
        
        if (!$db) {
            error_log("ERROR: No hay conexión a BD");
            return false;
        }
        
        $stmt = $db->prepare("SELECT id FROM metricas WHERE es_calculada = 1 AND activo = 1");
        $stmt->execute();
        $metricas_calculadas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($metricas_calculadas as $metrica_calc) {
            // ... resto del código con try-catch ...
        }
        
        return true;
    } catch (Exception $e) {
        error_log("Error en calcularMetricasAutomaticas: " . $e->getMessage());
        return false;
    }
}
```

### Verificación
1. Ingresar valores en métricas
2. Click "Guardar Cambios"
3. Debe redirigir a dashboard sin error
4. Ver mensaje verde de éxito

---

## 🟡 Métricas Calculadas No Se Actualizan

### Síntomas
- Inputs de métricas calculadas muestran `0`
- No cambian al modificar componentes
- Badge "AUTO" se muestra correctamente

### Diagnóstico

**1. Verificar consola JavaScript**

Abrir DevTools → Console, buscar errores.

**2. Verificar configuración cargada**

```javascript
console.log('Métricas calculadas:', metricasCalculadas);
```

Debe mostrar:
```javascript
{
  51: [45, 47],
  50: [44, 46]
}
```

Si muestra `{}` vacío → problema en query PHP.

### Soluciones

**Problema: Query PHP falla**

```php
// VERIFICAR que esta query esté en metricas.php (línea ~430)
$stmt = $db->query("
    SELECT 
        mc.metrica_calculada_id,
        GROUP_CONCAT(mc.metrica_componente_id ORDER BY mc.orden) as componentes
    FROM metricas_componentes mc
    INNER JOIN metricas m ON mc.metrica_calculada_id = m.id
    WHERE m.area_id = {$area_id} AND mc.activo = 1
    GROUP BY mc.metrica_calculada_id
");
```

**Problema: Event listeners no se registran**

```javascript
// Verificar que esto exista al final del script
document.getElementById('form-metricas').addEventListener('submit', function(e) {
    recalcularMetricas();
});
```

**Problema: Inputs tienen `readonly`**

Los inputs calculados NO deben tener atributo `readonly`:

```php
<!-- MAL -->
<input ... readonly>

<!-- BIEN -->
<input ... onclick="this.blur()" style="pointer-events: none;">
```

### Verificación
1. Abrir DevTools → Console
2. Escribir: `recalcularMetricas()`
3. Los valores deben actualizarse

---

## 🟠 Dashboard No Carga Gráficos

### Síntomas
- Dashboard aparece vacío
- No se ven tarjetas de gráficos
- Consola muestra errores JavaScript

### Diagnóstico

**1. Verificar si hay gráficos configurados**

```sql
SELECT * FROM graficos WHERE area_id = 1 AND activo = 1;
```

Si retorna 0 filas → no hay gráficos configurados.

**2. Verificar errores PHP**

```php
// Agregar al inicio de index.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

**3. Verificar consola JavaScript**

Buscar errores de Chart.js o GridStack.

### Soluciones

**Problema: No hay gráficos**

```php
// Crear gráfico de prueba
INSERT INTO graficos (area_id, titulo, tipo, configuracion_json, activo)
VALUES (1, 'Test KPI', 'kpi-card', 
        '{"metricas":[1],"color":"#0d6efd"}', 1);
```

**Problema: componente de gráfico no existe**

```bash
# Verificar que existe
ls -la components/charts/kpi-card.php
```

**Problema: JSON inválido en configuracion_json**

```sql
-- Verificar JSON válido
SELECT id, titulo, 
       JSON_VALID(configuracion_json) as es_valido
FROM graficos;

-- Corregir JSON inválido
UPDATE graficos 
SET configuracion_json = '{}'
WHERE JSON_VALID(configuracion_json) = 0;
```

---

## 🔵 GridStack No Guarda Posiciones

### Síntomas
- Mover gráficos funciona
- Al recargar, vuelven a posición original
- No aparecen errores

### Diagnóstico

**1. Verificar AJAX en consola**

DevTools → Network → Filtrar "XHR" → Buscar `/admin/save-grid-layout.php`

Si no aparece → JavaScript no se está ejecutando.

**2. Verificar endpoint existe**

```bash
ls -la admin/save-grid-layout.php
```

### Soluciones

**Problema: Archivo no existe**

Crear `admin/save-grid-layout.php`:

```php
<?php
require_once '../config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $area_id = (int)$_POST['area_id'];
    $positions = json_decode($_POST['positions'], true);
    
    $db = getDB();
    
    foreach ($positions as $item) {
        $stmt = $db->prepare("
            UPDATE graficos 
            SET posicion_x = ?, posicion_y = ?, ancho = ?, alto = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $item['x'],
            $item['y'],
            $item['w'],
            $item['h'],
            $item['i']
        ]);
    }
    
    echo json_encode(['success' => true]);
}
```

**Problema: JavaScript no envía AJAX**

Verificar en `assets/js/dashboard.js`:

```javascript
grid.on('change', function(event, items) {
    saveGridLayout();
});

function saveGridLayout() {
    const positions = grid.save();
    
    fetch('/metricas-it/admin/save-grid-layout.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            area_id: currentAreaId,
            positions: JSON.stringify(positions)
        })
    });
}
```

---

## 🟣 Estilos Rotos o Sin CSS

### Síntomas
- Página aparece sin estilos
- Fuentes por defecto del navegador
- Botones y cards sin formato

### Diagnóstico

**1. Verificar en DevTools → Network**

Filtrar "CSS" → Ver si carga:
- `tabler.min.css` (200 OK)
- `dashboard.css` (200 OK)

Si aparece 404 → problema de ruta.

**2. Ver código fuente de la página**

```html
<link rel="stylesheet" href="/metricas-it/assets/css/tabler.min.css">
```

Hacer clic en el href → debe cargar el CSS.

### Soluciones

**Problema: BASE_URL incorrecto**

```php
// Editar config.php
define('BASE_URL', 'https://siscoop.cicrl.com.gt/metricas-it');  // Sin slash final

// NO:
define('BASE_URL', 'https://siscoop.cicrl.com.gt/metricas-it/');  // ❌ Slash extra
define('BASE_URL', '/metricas-it');  // ❌ Sin dominio
```

**Problema: Archivos no existen**

```bash
# Verificar
ls -la assets/css/
ls -la assets/js/

# Si no existen, descargar
mkdir -p assets/css assets/js
cd assets/css
curl -O https://cdn.jsdelivr.net/npm/@tabler/core@latest/dist/css/tabler.min.css
```

**Problema: Permisos**

```powershell
# En Windows/IIS
icacls "C:\inetpub\wwwroot\metricas-it\assets" /grant "IIS_IUSRS:(OI)(CI)R" /T
```

---

## 🔴 Error de Conexión a BD

### Síntomas
```
Error de conexión a la base de datos
```

O:
```
SQLSTATE[HY000] [1045] Access denied for user 'metricas_user'@'localhost'
```

### Diagnóstico

**1. Verificar servicio MySQL**

```powershell
# Ver si está corriendo
Get-Service MySQL80

# Si está detenido, iniciar
Start-Service MySQL80
```

**2. Probar conexión manual**

```bash
mysql -u metricas_user -p metricas_it_dev
```

### Soluciones

**Problema: Credenciales incorrectas**

```php
// Editar config.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'metricas_it_dev');
define('DB_USER', 'metricas_user');
define('DB_PASS', 'password_correcto_aqui');  // ← Verificar
```

**Problema: Usuario no existe**

```sql
-- Conectar como root
mysql -u root -p

-- Crear usuario
CREATE USER 'metricas_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON metricas_it_dev.* TO 'metricas_user'@'localhost';
FLUSH PRIVILEGES;
```

**Problema: BD no existe**

```sql
CREATE DATABASE metricas_it_dev CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

**Problema: Puerto incorrecto**

```php
// Si MySQL usa puerto diferente a 3306
define('DB_HOST', 'localhost:3307');  // Especificar puerto
```

---

## 🟡 Sesiones No Funcionan

### Síntomas
- Login exitoso pero redirige de vuelta al login
- Variables de sesión no persisten
- `$_SESSION['user_id']` siempre vacío

### Diagnóstico

**1. Verificar que session_start() se llama**

```php
// Debe estar en config.php o al inicio de cada archivo
session_start();
```

**2. Verificar carpeta de sesiones**

```powershell
# Verificar que existe
Test-Path "C:\php\sessions"

# Si no existe, crear
New-Item -Path "C:\php\sessions" -ItemType Directory
```

**3. Ver permisos**

```powershell
icacls "C:\php\sessions"
```

Debe tener permisos de escritura para IIS_IUSRS.

### Soluciones

**Problema: session_start() falta**

```php
// config.php (DEBE estar ANTES de cualquier output)
<?php
session_start();

// Luego el resto de configuración
define('BASE_URL', '...');
```

**Problema: Headers already sent**

```php
<?php  // ← Sin espacios antes
session_start();

// NO:
    <?php  // ❌ Espacios antes rompen sesiones
```

**Problema: Carpeta no existe**

```php
// php.ini
session.save_path = "C:\php\sessions"

// Crear carpeta
mkdir C:\php\sessions
```

**Problema: Cookies bloqueadas por HTTPS**

```php
// config.php
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);

// Solo en producción con HTTPS:
if (ENVIRONMENT === 'production') {
    ini_set('session.cookie_secure', 1);
}
```

---

## 🟠 Headers Already Sent

### Síntomas
```
Warning: Cannot modify header information - headers already sent by 
(output started at /path/to/file.php:10)
```

### Causa
Se intentó usar `header()` o `session_start()` después de enviar output (HTML, espacios, echo).

### Diagnóstico

**Ver el archivo y línea en el error:**
```
headers already sent by (output started at /path/to/metricas.php:10)
                                                                   ^^
```

Ir a `metricas.php` línea 10 y buscar output antes de header().

### Soluciones

**Problema: Espacios antes de <?php**

```php
    <?php  // ❌ MAL - Espacios antes
    
<?php  // ✅ BIEN - Sin espacios
```

**Problema: Output antes de header()**

```php
// ❌ MAL
<?php
echo "Guardando...";
header("Location: index.php");  // Falla

// ✅ BIEN
<?php
header("Location: index.php");
exit();
// Nunca se ejecuta código después
```

**Problema: HTML antes de procesamiento POST**

```php
// ❌ MAL
<?php include 'header.php'; ?>  // Output HTML
<?php
if ($_POST) {
    header("Location: index.php");  // Falla
}

// ✅ BIEN
<?php
if ($_POST) {
    header("Location: index.php");
    exit();
}
include 'header.php';  // Output después
```

**Problema: BOM en archivo**

Algunos editores agregan BOM (Byte Order Mark) invisible.

```bash
# Verificar con hexdump
hexdump -C config.php | head

# Si inicia con EF BB BF → tiene BOM
# Re-guardar sin BOM en editor
```

**Solución temporal: Output Buffering**

```php
<?php
ob_start();  // Iniciar buffer

// ... tu código ...

if ($_POST) {
    ob_end_clean();  // Limpiar buffer
    header("Location: index.php");
    exit();
}

ob_end_flush();  // Enviar buffer
?>
```

---

## 🔧 Herramientas de Diagnóstico

### Script de Verificación del Sistema

Crear `admin/diagnostico.php`:

```php
<?php
require_once '../config.php';
requireAdmin();

echo "<h1>Diagnóstico del Sistema</h1>";

// 1. PHP
echo "<h2>PHP</h2>";
echo "Versión: " . phpversion() . "<br>";
echo "Extensiones PDO: " . (extension_loaded('pdo_mysql') ? '✅' : '❌') . "<br>";

// 2. Base de Datos
echo "<h2>Base de Datos</h2>";
try {
    $db = getDB();
    echo "Conexión: ✅<br>";
    
    $stmt = $db->query("SELECT COUNT(*) as total FROM usuarios");
    $result = $stmt->fetch();
    echo "Usuarios: {$result['total']}<br>";
    
    $stmt = $db->query("SELECT COUNT(*) as total FROM metricas");
    $result = $stmt->fetch();
    echo "Métricas: {$result['total']}<br>";
    
} catch (Exception $e) {
    echo "Conexión: ❌ " . $e->getMessage() . "<br>";
}

// 3. Archivos
echo "<h2>Archivos</h2>";
$archivos = [
    'config.php',
    'includes/db.php',
    'includes/functions.php',
    'models/Metrica.php',
    'assets/css/tabler.min.css'
];

foreach ($archivos as $archivo) {
    $existe = file_exists(BASE_PATH . '/' . $archivo);
    echo "$archivo: " . ($existe ? '✅' : '❌') . "<br>";
}

// 4. Sesiones
echo "<h2>Sesiones</h2>";
echo "Session ID: " . session_id() . "<br>";
echo "User ID: " . ($_SESSION['user_id'] ?? 'No definido') . "<br>";

// 5. Permisos
echo "<h2>Permisos</h2>";
$carpetas = ['assets', 'uploads', 'uploads/avatars'];
foreach ($carpetas as $carpeta) {
    $path = BASE_PATH . '/' . $carpeta;
    $escribible = is_writable($path);
    echo "$carpeta: " . ($escribible ? '✅' : '❌') . "<br>";
}
?>
```

Acceder a: `https://siscoop.cicrl.com.gt/metricas-it/admin/diagnostico.php`

**¡IMPORTANTE!** Eliminar después de diagnosticar.

---

## 📚 Recursos Adicionales

- [Event Viewer (Windows)](https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/eventvwr)
- [IIS Logs](https://docs.microsoft.com/en-us/iis/manage/provisioning-and-managing-iis/configure-logging-in-iis)
- [PHP Error Log](https://www.php.net/manual/en/errorfunc.configuration.php#ini.error-log)
- [MySQL Error Log](https://dev.mysql.com/doc/refman/8.0/en/error-log.html)

---

## 🆘 ¿Problema No Listado?

1. **Revisar logs**:
   - IIS: `C:\inetpub\logs\LogFiles\`
   - PHP: `C:\php\php_error.log`
   - MySQL: Event Viewer → Application

2. **Habilitar modo debug**:
   ```php
   // config.php
   define('ENVIRONMENT', 'development');
   error_reporting(E_ALL);
   ini_set('display_errors', 1);
   ```

3. **Crear issue** con:
   - Descripción del problema
   - Pasos para reproducir
   - Mensaje de error completo
   - Capturas de pantalla
# 🧮 Sistema de Métricas Calculadas

Documentación completa del sistema de cálculo automático de métricas.

## 📖 Introducción

El sistema de métricas calculadas permite crear métricas que se **calculan automáticamente** sumando otras métricas (componentes), sin necesidad de ingreso manual.

### Caso de Uso Real

**Medios Digitales** tiene:
- Transacciones CIC Virtual Operativo: 1,904
- Transacciones CIC Virtual Créditos: 8,145

En lugar de sumar manualmente cada mes, creamos:
- **Total Transacciones CIC Virtual** (calculada) = Operativo + Créditos = **10,049**

---

## 🎯 Características

✅ **Cálculo en Tiempo Real** - Se actualiza mientras ingresas valores  
✅ **Sin Código Backend** - Todo el cálculo sucede en JavaScript  
✅ **Validación Visual** - Campo verde con badge "AUTO"  
✅ **No Editable** - Usuario no puede modificar directamente  
✅ **Se Guarda Automáticamente** - Valor calculado se persiste en BD  

---

## 🏗️ Arquitectura del Sistema

### Componentes

```
┌─────────────────────────────────────────────────────────┐
│  1. CONFIGURACIÓN (Base de Datos)                       │
│     ┌──────────────┐        ┌─────────────────────┐    │
│     │   metricas   │        │ metricas_componentes│    │
│     │ es_calculada │◄───────│  relación M:N       │    │
│     └──────────────┘        └─────────────────────┘    │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  2. INTERFAZ (metricas.php)                              │
│     ┌──────────────────────────────────────────────┐    │
│     │  Renderizado PHP                             │    │
│     │  - Badge "AUTO" si es_calculada=1           │    │
│     │  - Input readonly con pointer-events: none   │    │
│     │  - Input NORMAL para componentes            │    │
│     └──────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  3. CÁLCULO (JavaScript Frontend)                        │
│     ┌──────────────────────────────────────────────┐    │
│     │  recalcularMetricas()                        │    │
│     │  - Escucha cambios en inputs normales       │    │
│     │  - Suma valores de componentes              │    │
│     │  - Actualiza input calculado                │    │
│     └──────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  4. GUARDADO (POST Handler)                              │
│     ┌──────────────────────────────────────────────┐    │
│     │  Guardar TODOS los valores                   │    │
│     │  - Métricas normales (ingresadas)           │    │
│     │  - Métricas calculadas (desde JavaScript)   │    │
│     └──────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
```

---

## 🗄️ Esquema de Base de Datos

### Tabla: metricas

```sql
CREATE TABLE metricas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    es_calculada TINYINT(1) DEFAULT 0,  -- ← FLAG CLAVE
    -- ... otros campos ...
);
```

### Tabla: metricas_componentes

```sql
CREATE TABLE metricas_componentes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    metrica_calculada_id INT NOT NULL,    -- Métrica que se calcula
    metrica_componente_id INT NOT NULL,   -- Métrica que suma
    operacion ENUM('suma','resta','multiplicacion','division') DEFAULT 'suma',
    orden INT DEFAULT 0,
    activo TINYINT(1) DEFAULT 1,
    
    FOREIGN KEY (metrica_calculada_id) REFERENCES metricas(id) ON DELETE CASCADE,
    FOREIGN KEY (metrica_componente_id) REFERENCES metricas(id) ON DELETE CASCADE,
    UNIQUE KEY unique_componente (metrica_calculada_id, metrica_componente_id)
);
```

### Ejemplo de Datos

```sql
-- Métrica calculada
INSERT INTO metricas (id, area_id, nombre, es_calculada, activo)
VALUES (51, 5, 'Total Transacciones CIC Virtual', 1, 1);

-- Componentes
INSERT INTO metricas_componentes (metrica_calculada_id, metrica_componente_id, operacion, orden)
VALUES 
(51, 45, 'suma', 1),  -- 45: Trans. Operativo
(51, 47, 'suma', 2);  -- 47: Trans. Créditos
```

**Resultado**: Métrica 51 = Métrica 45 + Métrica 47

---

## 💻 Implementación Frontend

### 1. Renderizado del Input

**Archivo**: `admin/metricas.php`

```php
<?php if ($metrica['es_calculada']): ?>
    <!-- Métrica calculada (no editable pero SÍ se envía) -->
    <div class="input-group mb-2">
        <span class="input-group-text bg-success-lt">
            <i class="ti ti-calculator"></i>
        </span>
        <input type="number" 
               step="1"
               class="form-control metrica-calculada" 
               id="metrica-<?php echo $metrica['id']; ?>"
               name="metricas[<?php echo $metrica['id']; ?>][valor]"
               value="<?php echo $metrica['valor'] ?? '0'; ?>"
               onclick="this.blur()"
               tabindex="-1"
               style="background: rgba(16, 185, 129, 0.1); 
                      font-weight: bold; 
                      color: #10b981; 
                      pointer-events: none; 
                      cursor: not-allowed;">
    </div>
    <small class="text-success d-block mb-2">
        <i class="ti ti-info-circle me-1"></i>
        Este valor se calcula automáticamente
    </small>
<?php else: ?>
    <!-- Métrica normal (editable) -->
    <input type="number" 
           class="form-control mb-2 metrica-normal" 
           id="metrica-<?php echo $metrica['id']; ?>"
           name="metricas[<?php echo $metrica['id']; ?>][valor]"
           value="<?php echo $metrica['valor'] ?? ''; ?>"
           placeholder="Ingresa el valor">
<?php endif; ?>
```

**Detalles importantes**:
- ✅ `pointer-events: none` - Evita edición pero permite envío en POST
- ✅ `name="metricas[X][valor]"` - Se incluye en el formulario
- ✅ Sin `readonly` - Los inputs readonly no se envían en forms
- ✅ `tabindex="-1"` - No se puede enfocar con Tab
- ✅ `onclick="this.blur()"` - Si se hace clic, pierde foco inmediatamente

---

### 2. Configuración JavaScript

```javascript
// Cargar configuración desde BD
const metricasCalculadas = {
    <?php 
    $db = getDB();
    $stmt = $db->query("
        SELECT 
            mc.metrica_calculada_id,
            GROUP_CONCAT(mc.metrica_componente_id ORDER BY mc.orden) as componentes
        FROM metricas_componentes mc
        INNER JOIN metricas m ON mc.metrica_calculada_id = m.id
        WHERE m.area_id = {$area_id} AND mc.activo = 1
        GROUP BY mc.metrica_calculada_id
    ");
    $relaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($relaciones as $rel) {
        echo $rel['metrica_calculada_id'] . ': [' . $rel['componentes'] . '],';
    }
    ?>
};

// Resultado ejemplo:
// metricasCalculadas = {
//     51: [45, 47],  // Métrica 51 suma 45 y 47
//     50: [44, 46]   // Métrica 50 suma 44 y 46
// };
```

---

### 3. Función de Cálculo

```javascript
let recalculandoAhora = false;

function recalcularMetricas() {
    if (recalculandoAhora) return;  // Evitar recálculos simultáneos
    recalculandoAhora = true;
    
    setTimeout(function() {
        if (Object.keys(metricasCalculadas).length === 0) {
            recalculandoAhora = false;
            return;
        }
        
        // Por cada métrica calculada
        for (const metricaId in metricasCalculadas) {
            const componentesIds = metricasCalculadas[metricaId];
            let total = 0;
            
            // Sumar componentes
            for (let i = 0; i < componentesIds.length; i++) {
                const input = document.getElementById('metrica-' + componentesIds[i]);
                if (input && input.value) {
                    total += parseFloat(input.value) || 0;
                }
            }
            
            // Actualizar input calculado
            const inputCalculado = document.getElementById('metrica-' + metricaId);
            if (inputCalculado) {
                const step = inputCalculado.getAttribute('step');
                if (step === '1') {
                    inputCalculado.value = Math.round(total);  // Enteros
                } else {
                    inputCalculado.value = total.toFixed(2);   // Decimales
                }
            }
        }
        
        recalculandoAhora = false;
    }, 50);  // Debounce de 50ms
}
```

**Optimizaciones**:
- ✅ Debounce de 50ms - Evita recálculos excesivos
- ✅ Flag `recalculandoAhora` - Previene condiciones de carrera
- ✅ Validación `parseFloat() || 0` - Maneja valores vacíos
- ✅ Respeta `step` - Enteros vs decimales

---

### 4. Event Listeners

```javascript
function inicializar() {
    // Event listeners para métricas normales
    const inputs = document.querySelectorAll('.metrica-normal');
    for (let i = 0; i < inputs.length; i++) {
        inputs[i].addEventListener('input', recalcularMetricas);
        inputs[i].addEventListener('change', recalcularMetricas);
    }
    
    // Cálculo inicial al cargar
    setTimeout(recalcularMetricas, 200);
}

// Recalcular antes de enviar formulario
document.getElementById('form-metricas').addEventListener('submit', function(e) {
    recalcularMetricas();
    console.log('Formulario enviado con métricas calculadas actualizadas');
});

// Inicializar cuando DOM esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializar);
} else {
    inicializar();
}
```

---

## 🔧 Implementación Backend

### Guardado de Valores

**Archivo**: `admin/metricas.php`

```php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_metricas'])) {
    try {
        $db = getDB();
        $db->beginTransaction();
        
        $cambios_realizados = 0;
        
        foreach ($_POST['metricas'] as $metrica_id => $datos) {
            $metrica_id = (int)$metrica_id;
            $valor = trim($datos['valor']);
            $nota = trim($datos['nota'] ?? '');
            
            // Guardar TANTO métricas normales como calculadas
            // Las calculadas ya vienen con el valor correcto desde JavaScript
            if ($valor !== '') {
                $valorModel->guardarValor(
                    $metrica_id,
                    $periodo['id'],
                    $valor,
                    $nota ?: null,
                    $_SESSION['user_id']
                );
                $cambios_realizados++;
            }
        }
        
        $db->commit();
        
        $_SESSION['mensaje'] = "Se guardaron correctamente $cambios_realizados métricas.";
        $_SESSION['mensaje_tipo'] = 'success';
        
        header("Location: " . BASE_URL . "/index.php");
        exit();
        
    } catch (Exception $e) {
        if (isset($db) && $db) {
            $db->rollBack();
        }
        error_log("Error guardando métricas: " . $e->getMessage());
        $mensaje = 'Error al guardar las métricas: ' . $e->getMessage();
        $mensaje_tipo = 'danger';
    }
}
```

**Puntos clave**:
- ✅ No distingue entre normales y calculadas al guardar
- ✅ JavaScript ya calculó el valor correcto
- ✅ Se guarda como cualquier otra métrica
- ✅ INSERT ON DUPLICATE KEY UPDATE maneja actualizaciones

---

### Modelo de Guardado

**Archivo**: `models/ValorMetrica.php`

```php
public function guardarValor($metrica_id, $periodo_id, $valor, $nota = null, $usuario_id = null) {
    // Determinar si es entero o decimal
    $es_decimal = (strpos($valor, '.') !== false);
    
    $stmt = $this->db->prepare("
        INSERT INTO valores_metricas 
        (metrica_id, periodo_id, valor_numero, valor_decimal, nota, usuario_registro_id, fecha_registro)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE 
            valor_numero = VALUES(valor_numero),
            valor_decimal = VALUES(valor_decimal),
            nota = VALUES(nota),
            fecha_actualizacion = NOW()
    ");
    
    return $stmt->execute([
        $metrica_id,
        $periodo_id,
        $es_decimal ? null : $valor,
        $es_decimal ? $valor : null,
        $nota,
        $usuario_id
    ]);
}
```

---

## 🎨 Estilos CSS

```css
.metric-calculada-item {
    border: 2px solid rgba(16, 185, 129, 0.3);
    background: rgba(16, 185, 129, 0.05);
}

.metric-calculada-item:hover {
    border-color: rgba(16, 185, 129, 0.5);
    background: rgba(16, 185, 129, 0.1);
}

.metrica-calculada {
    transition: background 0.3s ease;
}

.bg-success-lt {
    background-color: rgba(16, 185, 129, 0.1) !important;
    color: #10b981 !important;
    border-color: rgba(16, 185, 129, 0.3) !important;
}

.text-success {
    color: #10b981 !important;
}
```

---

## 📝 Configuración de Métricas Calculadas

### Interfaz de Configuración

**Archivo**: `admin/configurar-metricas.php`

```php
// CREAR métrica calculada
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crear_metrica'])) {
    $es_calculada = isset($_POST['es_calculada']) ? 1 : 0;
    
    $data = [
        'nombre' => $nombre,
        'es_calculada' => $es_calculada,
        // ... otros campos ...
    ];
    
    $metrica_id = $metricaModel->create($data);
    
    // Si es calculada, guardar componentes
    if ($es_calculada && isset($_POST['metricas_componentes'])) {
        $db = getDB();
        foreach ($_POST['metricas_componentes'] as $componente_id) {
            $stmt = $db->prepare("
                INSERT INTO metricas_componentes 
                (metrica_calculada_id, metrica_componente_id, operacion, orden)
                VALUES (?, ?, 'suma', ?)
            ");
            $stmt->execute([$metrica_id, $componente_id, $orden++]);
        }
    }
}
```

### Formulario de Componentes

**Archivo**: `admin/partials/metrica-form.php`

```php
<!-- Checkbox para marcar como calculada -->
<div class="mb-3">
    <label class="form-check form-switch form-switch-lg">
        <input type="checkbox" 
               class="form-check-input" 
               id="checkbox-es-calculada" 
               name="es_calculada"
               onchange="toggleMetricasComponentes(this.checked)">
        <span class="form-check-label">
            Esta métrica se calcula sumando otras métricas
        </span>
    </label>
</div>

<!-- Selector de componentes (oculto por defecto) -->
<div id="metricas-componentes-container" style="display: none;">
    <div class="card border-success">
        <div class="card-header bg-success-lt">
            <h4 class="card-title">
                <i class="ti ti-calculator me-2"></i>
                Componentes del Cálculo
            </h4>
        </div>
        <div class="card-body" id="metricas-componentes-list">
            <!-- Checkboxes de métricas del área -->
        </div>
    </div>
</div>

<script>
function toggleMetricasComponentes(mostrar) {
    document.getElementById('metricas-componentes-container').style.display = 
        mostrar ? 'block' : 'none';
    
    if (mostrar) {
        cargarMetricasComponentes();
    }
}

function cargarMetricasComponentes() {
    const metricasDelArea = <?php echo json_encode($metricasDelArea); ?>;
    const container = document.getElementById('metricas-componentes-list');
    
    let html = '';
    metricasDelArea.forEach(metrica => {
        html += `
            <div class="form-check mb-2">
                <input class="form-check-input" 
                       type="checkbox" 
                       name="metricas_componentes[]" 
                       value="${metrica.id}"
                       id="comp-${metrica.id}">
                <label class="form-check-label" for="comp-${metrica.id}">
                    ${metrica.nombre}
                    ${metrica.unidad ? '(' + metrica.unidad + ')' : ''}
                </label>
            </div>
        `;
    });
    
    container.innerHTML = html;
}
</script>
```

---

## 🧪 Casos de Prueba

### Prueba 1: Cálculo Básico
```
Componentes:
- Métrica A: 100
- Métrica B: 200

Esperado:
- Métrica Calculada: 300 ✅
```

### Prueba 2: Valores Decimales
```
Componentes:
- Métrica A: 10.50
- Métrica B: 20.75

Esperado:
- Métrica Calculada: 31.25 ✅
```

### Prueba 3: Componente Vacío
```
Componentes:
- Métrica A: 100
- Métrica B: (vacío)

Esperado:
- Métrica Calculada: 100 ✅
```

### Prueba 4: Guardado en BD
```
1. Ingresar valores: A=1904, B=8145
2. Verificar cálculo frontend: 10049
3. Guardar formulario
4. Verificar BD:
   SELECT valor_numero FROM valores_metricas 
   WHERE metrica_id = 51 AND periodo_id = 3;
   
Esperado: 10049 ✅
```

---

## ⚠️ Limitaciones Actuales

### Operaciones Soportadas
- ✅ **Suma** - Implementado completamente
- ❌ **Resta** - No implementado
- ❌ **Multiplicación** - No implementado
- ❌ **División** - No implementado

### Restricciones
- Solo suma de 2 o más componentes
- No soporta fórmulas complejas
- No soporta operaciones mixtas
- Componentes deben ser del mismo `tipo_valor`

---

## 🚀 Mejoras Futuras

### Fase 2: Operaciones Avanzadas
```javascript
// Soportar resta, multiplicación, división
const operaciones = {
    51: {
        componentes: [45, 47],
        formula: 'A + B'
    },
    52: {
        componentes: [48, 49],
        formula: 'A - B'
    },
    53: {
        componentes: [50, 51],
        formula: '(A / B) * 100'  // Porcentaje
    }
};
```

### Fase 3: Editor Visual
- Drag & drop de métricas
- Preview del cálculo
- Validación de fórmulas

### Fase 4: Cálculo Backend como Respaldo
```php
// Cron job nocturno que recalcula todas las métricas calculadas
// Por si hay inconsistencias entre frontend y BD
php /path/to/recalcular-todas-metricas.php
```

---

## 📚 Referencias

- [02-arquitectura.md](02-arquitectura.md) - Arquitectura general
- [03-base-de-datos.md](03-base-de-datos.md) - Esquema de BD
- [07-desarrollo.md](07-desarrollo.md) - Extender funcionalidades
- [09-troubleshooting.md](09-troubleshooting.md) - Solución de problemas
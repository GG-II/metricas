# 🗄️ Base de Datos - Esquema Completo

Documentación completa del esquema de base de datos del sistema.

## 📊 Diagrama ER

```
┌─────────────┐         ┌──────────────┐
│   usuarios  │────┬────│   areas      │
└─────────────┘    │    └──────────────┘
                   │            │
                   │            │
                   │    ┌───────▼───────┐         ┌─────────────────┐
                   │    │   metricas    │◄────────│ metricas_       │
                   │    └───────┬───────┘         │ componentes     │
                   │            │                 └─────────────────┘
                   │            │
                   │    ┌───────▼──────────┐
                   │    │ valores_metricas │
                   │    └──────────────────┘
                   │            │
                   │    ┌───────▼───────┐
                   ├────│   periodos    │
                   │    └───────────────┘
                   │
                   │    ┌──────────────┐
                   └────│  graficos    │
                        └──────────────┘
```

---

## 📋 Tablas Principales

### 1. usuarios
**Descripción**: Almacena los usuarios del sistema y sus credenciales.

```sql
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    nombre_completo VARCHAR(150) NOT NULL,
    rol ENUM('admin', 'user') DEFAULT 'user',
    foto_perfil VARCHAR(255) DEFAULT NULL,
    activo TINYINT(1) DEFAULT 1,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    ultimo_acceso TIMESTAMP NULL,
    
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_rol (rol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos clave**:
- `password`: Hash bcrypt
- `rol`: 'admin' tiene acceso completo, 'user' solo lectura
- `activo`: Permite deshabilitar usuarios sin eliminarlos

**Datos iniciales**:
```sql
INSERT INTO usuarios (username, password, email, nombre_completo, rol, activo)
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
        'admin@empresa.com', 'Administrador del Sistema', 'admin', 1);
-- Password: Admin123!
```

---

### 2. areas
**Descripción**: Áreas o departamentos de TI que tienen métricas.

```sql
CREATE TABLE areas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    color VARCHAR(7) DEFAULT '#0d6efd',
    icono VARCHAR(50) DEFAULT 'ti-chart-bar',
    orden INT DEFAULT 0,
    activo TINYINT(1) DEFAULT 1,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_orden (orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos clave**:
- `color`: Código hexadecimal para identificación visual
- `icono`: Clase de Tabler Icons
- `orden`: Para ordenar en el frontend

**Datos iniciales**:
```sql
INSERT INTO areas (id, nombre, descripcion, color, icono, orden, activo) VALUES
(1, 'Software Factory', 'Desarrollo y entrega de software', '#0d6efd', 'ti-code', 1, 1),
(2, 'Infraestructura', 'Servidores, redes y almacenamiento', '#198754', 'ti-server', 2, 1),
(3, 'Soporte Técnico', 'Mesa de ayuda y soporte a usuarios', '#fd7e14', 'ti-headset', 3, 1),
(4, 'Ciberseguridad', 'Seguridad de la información', '#dc3545', 'ti-shield-lock', 4, 1),
(5, 'Medios Digitales', 'Canales digitales y aplicaciones móviles', '#6f42c1', 'ti-device-mobile', 5, 1);
```

---

### 3. metricas
**Descripción**: Definición de métricas que se miden por área.

```sql
CREATE TABLE metricas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    area_id INT NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT,
    tipo_valor ENUM('entero', 'decimal', 'porcentaje', 'moneda') DEFAULT 'entero',
    unidad VARCHAR(50),
    valor_objetivo DECIMAL(15,2) DEFAULT NULL,
    tipo_grafico ENUM('barra', 'linea', 'progreso', 'dona', 'numero', 'area') DEFAULT 'numero',
    icono VARCHAR(50) DEFAULT 'ti-chart-bar',
    color VARCHAR(7) DEFAULT '#0d6efd',
    orden INT DEFAULT 0,
    es_calculada TINYINT(1) DEFAULT 0,
    activo TINYINT(1) DEFAULT 1,
    usuario_creacion_id INT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_creacion_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    
    INDEX idx_area (area_id),
    INDEX idx_activo (activo),
    INDEX idx_es_calculada (es_calculada)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos clave**:
- `tipo_valor`: Determina formato de visualización
- `valor_objetivo`: Para comparaciones y gráficos de progreso
- `es_calculada`: 1 si se calcula automáticamente, 0 si se ingresa manual
- `tipo_grafico`: Tipo preferido para visualización (legacy)

**Ejemplo**:
```sql
INSERT INTO metricas (area_id, nombre, descripcion, tipo_valor, unidad, valor_objetivo, icono, es_calculada, activo)
VALUES (5, 'Total Transacciones CIC Virtual', 
        'Suma automática de transacciones operativas y de créditos', 
        'entero', 'transacciones', 50000, 'ti-credit-card', 1, 1);
```

---

### 4. metricas_componentes
**Descripción**: Relación entre métricas calculadas y sus componentes.

```sql
CREATE TABLE metricas_componentes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    metrica_calculada_id INT NOT NULL,
    metrica_componente_id INT NOT NULL,
    operacion ENUM('suma','resta','multiplicacion','division') DEFAULT 'suma',
    orden INT DEFAULT 0,
    activo TINYINT(1) DEFAULT 1,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (metrica_calculada_id) REFERENCES metricas(id) ON DELETE CASCADE,
    FOREIGN KEY (metrica_componente_id) REFERENCES metricas(id) ON DELETE CASCADE,
    UNIQUE KEY unique_componente (metrica_calculada_id, metrica_componente_id),
    
    INDEX idx_calculada (metrica_calculada_id),
    INDEX idx_componente (metrica_componente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos clave**:
- `metrica_calculada_id`: Métrica que se calcula (con es_calculada=1)
- `metrica_componente_id`: Métrica que suma para calcular
- `operacion`: Tipo de operación (actualmente solo 'suma' implementado)
- `orden`: Orden en que se aplican operaciones

**Ejemplo**:
```sql
-- Total Trans. CIC Virtual = Trans. Operativo + Trans. Créditos
INSERT INTO metricas_componentes (metrica_calculada_id, metrica_componente_id, operacion, orden)
VALUES 
(51, 45, 'suma', 1),  -- 51: Total, 45: Operativo
(51, 47, 'suma', 2);  -- 51: Total, 47: Créditos
```

---

### 5. periodos
**Descripción**: Períodos temporales para agrupar métricas.

```sql
CREATE TABLE periodos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ejercicio INT NOT NULL,
    periodo TINYINT NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    activo TINYINT(1) DEFAULT 1,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_periodo (ejercicio, periodo),
    INDEX idx_ejercicio (ejercicio),
    INDEX idx_fecha_fin (fecha_fin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos clave**:
- `ejercicio`: Año (2026, 2027, etc.)
- `periodo`: Mes (1-12)
- `nombre`: Texto descriptivo ("Marzo 2026")

**Datos iniciales (2026)**:
```sql
INSERT INTO periodos (ejercicio, periodo, nombre, fecha_inicio, fecha_fin) VALUES
(2026, 1,  'Enero 2026',      '2026-01-01', '2026-01-31'),
(2026, 2,  'Febrero 2026',    '2026-02-01', '2026-02-28'),
(2026, 3,  'Marzo 2026',      '2026-03-01', '2026-03-31'),
(2026, 4,  'Abril 2026',      '2026-04-01', '2026-04-30'),
(2026, 5,  'Mayo 2026',       '2026-05-01', '2026-05-31'),
(2026, 6,  'Junio 2026',      '2026-06-01', '2026-06-30'),
(2026, 7,  'Julio 2026',      '2026-07-01', '2026-07-31'),
(2026, 8,  'Agosto 2026',     '2026-08-01', '2026-08-31'),
(2026, 9,  'Septiembre 2026', '2026-09-01', '2026-09-30'),
(2026, 10, 'Octubre 2026',    '2026-10-01', '2026-10-31'),
(2026, 11, 'Noviembre 2026',  '2026-11-01', '2026-11-30'),
(2026, 12, 'Diciembre 2026',  '2026-12-01', '2026-12-31');
```

---

### 6. valores_metricas
**Descripción**: Valores históricos de cada métrica por período.

```sql
CREATE TABLE valores_metricas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    metrica_id INT NOT NULL,
    periodo_id INT NOT NULL,
    valor_numero BIGINT DEFAULT NULL,
    valor_decimal DECIMAL(15,2) DEFAULT NULL,
    nota TEXT,
    usuario_registro_id INT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (metrica_id) REFERENCES metricas(id) ON DELETE CASCADE,
    FOREIGN KEY (periodo_id) REFERENCES periodos(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_registro_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    UNIQUE KEY unique_metrica_periodo (metrica_id, periodo_id),
    
    INDEX idx_metrica (metrica_id),
    INDEX idx_periodo (periodo_id),
    INDEX idx_fecha (fecha_registro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos clave**:
- `valor_numero`: Para enteros y porcentajes
- `valor_decimal`: Para decimales y monedas
- `nota`: Comentario opcional del registro
- Constraint UNIQUE: Solo un valor por métrica-período

**Lógica de guardado**:
```sql
INSERT INTO valores_metricas (metrica_id, periodo_id, valor_numero, usuario_registro_id)
VALUES (?, ?, ?, ?)
ON DUPLICATE KEY UPDATE 
    valor_numero = VALUES(valor_numero),
    fecha_actualizacion = NOW();
```

---

### 7. graficos
**Descripción**: Configuración de gráficos del dashboard.

```sql
CREATE TABLE graficos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    area_id INT NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    descripcion TEXT,
    tipo VARCHAR(50) NOT NULL,
    configuracion_json TEXT,
    posicion_x INT DEFAULT 0,
    posicion_y INT DEFAULT 0,
    ancho INT DEFAULT 4,
    alto INT DEFAULT 3,
    orden INT DEFAULT 0,
    activo TINYINT(1) DEFAULT 1,
    usuario_creacion_id INT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_creacion_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    
    INDEX idx_area (area_id),
    INDEX idx_tipo (tipo),
    INDEX idx_orden (orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos clave**:
- `tipo`: Nombre del componente (kpi-card, bar, line, etc.)
- `configuracion_json`: JSON con config específica del gráfico
- `posicion_x, posicion_y, ancho, alto`: Para GridStack
- `orden`: Orden de aparición inicial

**Ejemplo de configuracion_json**:
```json
{
  "metricas": [12, 13],
  "color": "#0d6efd",
  "mostrar_objetivo": true,
  "titulo": "Transacciones Mensuales"
}
```

---

### 8. log_actividad
**Descripción**: Auditoría de acciones en el sistema.

```sql
CREATE TABLE log_actividad (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    accion VARCHAR(100) NOT NULL,
    tabla_afectada VARCHAR(50),
    registro_id INT,
    descripcion TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    
    INDEX idx_usuario (usuario_id),
    INDEX idx_accion (accion),
    INDEX idx_fecha (fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Acciones típicas**:
- `login`, `logout`
- `crear_metrica`, `actualizar_metrica`, `eliminar_metrica`
- `actualizar_metricas` (captura de valores)
- `crear_grafico`, `actualizar_grafico`, `eliminar_grafico`

---

## 🔗 Relaciones Entre Tablas

### Métricas y Áreas
```sql
-- Una área tiene muchas métricas
SELECT m.* FROM metricas m
WHERE m.area_id = 5 AND m.activo = 1;
```

### Métricas y Valores
```sql
-- Una métrica tiene un valor por período
SELECT vm.* FROM valores_metricas vm
WHERE vm.metrica_id = 12 AND vm.periodo_id = 3;
```

### Métricas Calculadas
```sql
-- Obtener componentes de una métrica calculada
SELECT 
    m.id,
    m.nombre,
    GROUP_CONCAT(mc.metrica_componente_id) as componentes
FROM metricas m
INNER JOIN metricas_componentes mc ON m.id = mc.metrica_calculada_id
WHERE m.es_calculada = 1 AND m.area_id = 5
GROUP BY m.id;
```

### Gráficos con Métricas
```sql
-- Gráficos de un área con sus métricas (desde JSON)
SELECT 
    g.*,
    JSON_EXTRACT(g.configuracion_json, '$.metricas') as metricas_ids
FROM graficos g
WHERE g.area_id = 1 AND g.activo = 1
ORDER BY g.orden;
```

---

## 📈 Queries Comunes

### Dashboard Principal
```sql
-- Obtener todas las métricas de un área con sus valores del período
SELECT 
    m.*,
    vm.valor_numero,
    vm.valor_decimal,
    vm.nota,
    vm.fecha_actualizacion
FROM metricas m
LEFT JOIN valores_metricas vm ON m.id = vm.metrica_id 
    AND vm.periodo_id = :periodo_id
WHERE m.area_id = :area_id 
    AND m.activo = 1
ORDER BY m.orden, m.nombre;
```

### Histórico de Métrica
```sql
-- Valores históricos de una métrica
SELECT 
    p.ejercicio,
    p.periodo,
    p.nombre as periodo_nombre,
    COALESCE(vm.valor_numero, vm.valor_decimal) as valor
FROM periodos p
LEFT JOIN valores_metricas vm ON p.id = vm.periodo_id 
    AND vm.metrica_id = :metrica_id
WHERE p.ejercicio IN (2025, 2026)
ORDER BY p.ejercicio DESC, p.periodo DESC
LIMIT 12;
```

### Calcular Métrica Automática
```sql
-- Sumar componentes de una métrica calculada
SELECT 
    SUM(COALESCE(vm.valor_numero, vm.valor_decimal)) as total
FROM metricas_componentes mc
INNER JOIN valores_metricas vm ON mc.metrica_componente_id = vm.metrica_id
WHERE mc.metrica_calculada_id = :metrica_calculada_id
    AND vm.periodo_id = :periodo_id
    AND mc.activo = 1;
```

---

## 🔒 Índices y Optimización

### Índices Importantes
```sql
-- Índices para búsquedas frecuentes
ALTER TABLE valores_metricas ADD INDEX idx_metrica_periodo (metrica_id, periodo_id);
ALTER TABLE metricas ADD INDEX idx_area_activo (area_id, activo);
ALTER TABLE graficos ADD INDEX idx_area_activo (area_id, activo);
```

### Análisis de Rendimiento
```sql
-- Ver uso de índices
EXPLAIN SELECT * FROM valores_metricas 
WHERE metrica_id = 12 AND periodo_id = 3;

-- Ver tamaño de tablas
SELECT 
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS "Size (MB)"
FROM information_schema.TABLES
WHERE table_schema = 'metricas_it_dev'
ORDER BY (data_length + index_length) DESC;
```

---

## 🗑️ Mantenimiento

### Limpieza de Datos Antiguos
```sql
-- Eliminar logs de más de 1 año
DELETE FROM log_actividad 
WHERE fecha < DATE_SUB(NOW(), INTERVAL 1 YEAR);

-- Archivar períodos antiguos
UPDATE periodos 
SET activo = 0 
WHERE ejercicio < YEAR(NOW()) - 2;
```

### Respaldo
```bash
# Backup completo
mysqldump -u metricas_user -p metricas_it_dev > backup_$(date +%Y%m%d).sql

# Backup solo estructura
mysqldump -u metricas_user -p --no-data metricas_it_dev > schema.sql

# Backup solo datos
mysqldump -u metricas_user -p --no-create-info metricas_it_dev > data.sql
```

---

## 📚 Próximos Pasos

- [06-metricas-calculadas.md](06-metricas-calculadas.md) - Sistema de cálculo
- [07-desarrollo.md](07-desarrollo.md) - Extender el esquema
- [09-troubleshooting.md](09-troubleshooting.md) - Problemas comunes de BD
# 🏗️ Arquitectura del Sistema

Descripción técnica de la arquitectura, componentes y flujos del Dashboard de Métricas IT.

## 📐 Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│                      CLIENTE (Navegador)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  Dashboard   │  │   Admin      │  │    Login     │      │
│  │  (GridStack) │  │   Panel      │  │              │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└────────────┬────────────────────────────────┬───────────────┘
             │                                 │
             │ AJAX/Forms                      │ POST
             ▼                                 ▼
┌─────────────────────────────────────────────────────────────┐
│                    SERVIDOR WEB (IIS)                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                   PHP 8.5.4                          │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │   │
│  │  │ Controllers │  │   Models    │  │   Views     │ │   │
│  │  │ (index.php) │  │  (Classes)  │  │ (partials)  │ │   │
│  │  └─────────────┘  └──────┬──────┘  └─────────────┘ │   │
│  │                           │                          │   │
│  │                           │ PDO                      │   │
│  │                           ▼                          │   │
│  │                    ┌─────────────┐                   │   │
│  │                    │   DB Layer  │                   │   │
│  │                    │  (db.php)   │                   │   │
│  │                    └──────┬──────┘                   │   │
│  └───────────────────────────┼──────────────────────────┘   │
└────────────────────────────────┼──────────────────────────┘
                                 │ MySQL Protocol
                                 ▼
┌─────────────────────────────────────────────────────────────┐
│                   BASE DE DATOS (MySQL 8.0)                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ usuarios │  │ metricas │  │ graficos │  │ periodos │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│  ┌──────────────┐  ┌───────────────────┐                   │
│  │valores_metricas│  │metricas_componentes│                 │
│  └──────────────┘  └───────────────────┘                   │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Patrón de Arquitectura: MVC Simplificado

### Model (Modelos)
**Ubicación**: `/models/`

Clases que manejan la lógica de datos y acceso a BD:

```
models/
├── Area.php           # Gestión de áreas
├── Periodo.php        # Gestión de períodos
├── Metrica.php        # Gestión de métricas
├── ValorMetrica.php   # Valores históricos
├── Grafico.php        # Configuración de gráficos
├── User.php           # Usuarios
└── ChartRegistry.php  # Registro de tipos de gráficos
```

**Ejemplo de Modelo**:
```php
class Metrica {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    public function getByArea($area_id, $activas = true) {
        $sql = "SELECT * FROM metricas WHERE area_id = ?";
        if ($activas) $sql .= " AND activo = 1";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$area_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
```

### View (Vistas)
**Ubicación**: `/partials/` y archivos `.php` principales

Componentes de interfaz:

```
partials/
├── header.php         # Header con navbar
├── footer.php         # Footer con scripts
└── sidebar.php        # Sidebar de navegación (futuro)

components/
└── charts/            # Componentes de gráficos
    ├── kpi-card.php
    ├── progress.php
    ├── bar.php
    ├── line.php
    ├── comparison.php
    ├── multi-bar.php
    ├── donut.php
    ├── gauge.php
    └── data-table.php
```

### Controller (Controladores)
**Ubicación**: Archivos principales `.php`

Lógica de flujo y coordinación:

```
/
├── index.php                    # Dashboard principal
├── login.php                    # Autenticación
admin/
├── metricas.php                 # Captura de valores
├── configurar-metricas.php      # CRUD métricas
├── graficos.php                 # CRUD gráficos
└── usuarios.php                 # CRUD usuarios
```

---

## 🔄 Flujos Principales

### 1. Flujo de Visualización de Dashboard

```
Usuario accede a index.php
        │
        ├─→ Verificar sesión activa
        │   ├─→ No → Redirigir a login.php
        │   └─→ Sí → Continuar
        │
        ├─→ Obtener área y período (GET params)
        │
        ├─→ Cargar modelos:
        │   ├─→ Area::getById($area_id)
        │   ├─→ Periodo::getByEjercicioPeriodo()
        │   └─→ Grafico::getByArea($area_id)
        │
        ├─→ Por cada gráfico:
        │   ├─→ Obtener configuración JSON
        │   ├─→ Cargar métricas asociadas
        │   ├─→ Obtener valores del período
        │   └─→ Renderizar componente
        │
        └─→ Renderizar GridStack con posiciones guardadas
```

### 2. Flujo de Captura de Métricas

```
Admin accede a metricas.php?area=X&periodo=Y
        │
        ├─→ Verificar rol admin
        │
        ├─→ GET: Mostrar formulario
        │   ├─→ Metrica::getByAreaConValores()
        │   ├─→ Distinguir métricas normales vs calculadas
        │   └─→ Renderizar inputs
        │
        └─→ POST: Guardar valores
            ├─→ Iniciar transacción BD
            ├─→ foreach métricas:
            │   └─→ ValorMetrica::guardarValor()
            │       ├─→ INSERT ON DUPLICATE KEY UPDATE
            │       └─→ Guardar normales Y calculadas
            ├─→ Commit transacción
            ├─→ logActivity()
            ├─→ Guardar mensaje en $_SESSION
            └─→ header("Location: index.php")
```

### 3. Flujo de Métricas Calculadas

```
Usuario ingresa valores en formulario
        │
        ├─→ JavaScript detecta cambio en metrica-normal
        │
        ├─→ Trigger: recalcularMetricas()
        │   ├─→ Por cada métrica calculada:
        │   │   ├─→ Obtener IDs de componentes
        │   │   ├─→ Leer valores de inputs componentes
        │   │   ├─→ total = SUM(componentes)
        │   │   └─→ Actualizar input calculado
        │
        ├─→ Usuario hace submit
        │   └─→ Último recalculo antes de enviar
        │
        └─→ POST envía valores normales + calculados
            └─→ Se guardan TODOS en valores_metricas
```

---

## 🗂️ Estructura de Directorios Completa

```
metricas-it/
│
├── admin/                          # Panel de administración
│   ├── metricas.php               # Captura de valores
│   ├── configurar-metricas.php    # CRUD métricas
│   ├── graficos.php               # CRUD gráficos
│   ├── usuarios.php               # CRUD usuarios
│   └── partials/
│       ├── metrica-form.php       # Form crear/editar métrica
│       └── grafico-form.php       # Form crear/editar gráfico
│
├── assets/                         # Recursos estáticos
│   ├── css/
│   │   ├── dashboard.css          # Estilos del dashboard
│   │   └── admin.css              # Estilos del admin
│   ├── js/
│   │   ├── dashboard.js           # GridStack + AJAX
│   │   └── charts.js              # Helpers de Chart.js
│   └── img/
│       └── logo.png
│
├── components/                     # Componentes reutilizables
│   └── charts/                    # Tipos de gráficos
│       ├── kpi-card.php
│       ├── progress.php
│       ├── bar.php
│       ├── line.php
│       ├── comparison.php
│       ├── multi-bar.php
│       ├── donut.php
│       ├── gauge.php
│       └── data-table.php
│
├── database/                       # Scripts de BD
│   ├── schema.sql                 # Esquema completo
│   ├── seed.sql                   # Datos iniciales
│   └── migrations/                # Migraciones
│
├── docs/                           # Documentación
│   └── (archivos .md)
│
├── includes/                       # Funciones y utilidades
│   ├── db.php                     # Conexión PDO
│   ├── functions.php              # Helpers generales
│   ├── auth.php                   # Autenticación
│   └── calcular-metricas.php      # Cálculo backend (legacy)
│
├── models/                         # Modelos de datos
│   ├── Area.php
│   ├── ChartRegistry.php
│   ├── Grafico.php
│   ├── Metrica.php
│   ├── Periodo.php
│   ├── User.php
│   └── ValorMetrica.php
│
├── partials/                       # Componentes de layout
│   ├── header.php
│   └── footer.php
│
├── uploads/                        # Archivos subidos
│   └── avatars/                   # Fotos de perfil
│
├── config.php                      # Configuración principal
├── index.php                       # Dashboard
├── login.php                       # Login
└── logout.php                      # Logout
```

---

## 🔌 Capa de Datos (PDO)

### Conexión a BD
**Archivo**: `includes/db.php`

```php
function getDB() {
    static $db = null;
    
    if ($db === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $db = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("DB Connection Error: " . $e->getMessage());
            die("Error de conexión a la base de datos");
        }
    }
    
    return $db;
}
```

### Patrón de Acceso a Datos

```php
// Modelo típico
class Metrica {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    // SELECT con parámetros
    public function getById($id) {
        $stmt = $this->db->prepare("SELECT * FROM metricas WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    // INSERT
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO metricas (nombre, tipo_valor, unidad, area_id)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['nombre'],
            $data['tipo_valor'],
            $data['unidad'],
            $data['area_id']
        ]);
        return $this->db->lastInsertId();
    }
    
    // UPDATE
    public function update($id, $data) {
        $stmt = $this->db->prepare("
            UPDATE metricas
            SET nombre = ?, tipo_valor = ?, unidad = ?
            WHERE id = ?
        ");
        return $stmt->execute([
            $data['nombre'],
            $data['tipo_valor'],
            $data['unidad'],
            $id
        ]);
    }
    
    // DELETE
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM metricas WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
```

---

## 🎨 Sistema de Componentes de Gráficos

### Registro Automático
**Archivo**: `models/ChartRegistry.php`

```php
class ChartRegistry {
    public static function getAvailableTypes() {
        $types = [];
        $chartDir = BASE_PATH . '/components/charts/';
        
        foreach (glob($chartDir . '*.php') as $file) {
            $name = basename($file, '.php');
            $types[$name] = self::getMetadata($file);
        }
        
        return $types;
    }
}
```

### Estructura de Componente
**Archivo**: `components/charts/kpi-card.php`

```php
<?php
/*
 * KPI Card - Tarjeta de indicador clave
 * Muestra un valor con título, ícono y color
 */

// Metadata del componente
$metadata = [
    'name' => 'KPI Card',
    'description' => 'Tarjeta simple con valor destacado',
    'icon' => 'ti-chart-line',
    'config_fields' => ['titulo', 'color', 'icono']
];

// Renderizar
if (!isset($preview)) {
    $config = json_decode($grafico['configuracion_json'], true);
    $metrica = $metricas[0] ?? null;
    $valor = $metrica['valor'] ?? 0;
    ?>
    
    <div class="card" style="border-top: 3px solid <?= $config['color'] ?>">
        <div class="card-body">
            <div class="d-flex align-items-center">
                <div class="subheader"><?= $config['titulo'] ?></div>
            </div>
            <div class="h1 mt-2"><?= number_format($valor) ?></div>
        </div>
    </div>
    
    <?php
}
?>
```

---

## 🔐 Capa de Seguridad

### Autenticación
```php
// includes/auth.php
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        redirect('/login.php');
    }
}

function requireAdmin() {
    requireLogin();
    if ($_SESSION['user_role'] !== 'admin') {
        redirect('/index.php');
    }
}
```

### Sanitización
```php
// includes/functions.php
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}
```

### Passwords
```php
// Hashear
$hash = password_hash($password, PASSWORD_BCRYPT);

// Verificar
if (password_verify($input_password, $stored_hash)) {
    // Login exitoso
}
```

---

## 📊 Gestión de Estado

### Sesiones PHP
```php
// Variables de sesión
$_SESSION['user_id']      // ID del usuario
$_SESSION['username']     // Nombre de usuario
$_SESSION['user_role']    // Rol (admin/user)
$_SESSION['nombre_completo']

// Mensajes flash
$_SESSION['mensaje']      // Mensaje de éxito/error
$_SESSION['mensaje_tipo'] // success/danger/warning
```

### LocalStorage (JavaScript)
```javascript
// Posiciones de GridStack
localStorage.setItem('grid_positions_' + areaId, JSON.stringify(positions));

// Última área visitada
localStorage.setItem('last_area', areaId);
```

---

## 🚀 Optimizaciones

### Queries Eficientes
```php
// JOIN para evitar N+1
$sql = "
    SELECT m.*, vm.valor_numero, vm.valor_decimal
    FROM metricas m
    LEFT JOIN valores_metricas vm ON m.id = vm.metrica_id AND vm.periodo_id = ?
    WHERE m.area_id = ? AND m.activo = 1
";
```

### Caching (Futuro)
```php
// Redis/Memcached para métricas frecuentes
$cache_key = "metricas_area_{$area_id}_periodo_{$periodo_id}";
$metricas = $cache->get($cache_key);

if (!$metricas) {
    $metricas = $metricaModel->getByAreaConValores($area_id, $periodo_id);
    $cache->set($cache_key, $metricas, 300); // 5 minutos
}
```

---

## 📚 Próximos Pasos

- [03-base-de-datos.md](03-base-de-datos.md) - Esquema detallado de BD
- [06-metricas-calculadas.md](06-metricas-calculadas.md) - Sistema de cálculo
- [07-desarrollo.md](07-desarrollo.md) - Extender funcionalidades
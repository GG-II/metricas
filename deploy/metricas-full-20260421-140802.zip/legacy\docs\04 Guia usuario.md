# 👤 Guía de Usuario

Manual de usuario para visualizar y navegar el Dashboard de Métricas IT.

## 🎯 Introducción

El Dashboard de Métricas IT te permite visualizar indicadores clave de diferentes áreas de TI en tiempo real, cambiar entre períodos y reorganizar gráficos según tus preferencias.

---

## 🚀 Acceso al Sistema

### Iniciar Sesión

1. Accede a: `https://siscoop.cicrl.com.gt/metricas-it/`
2. Ingresa tus credenciales:
   - **Usuario**: (proporcionado por tu administrador)
   - **Contraseña**: (proporcionada por tu administrador)
3. Click en **"Iniciar Sesión"**

![Login Screen](../assets/img/docs/login.png)

### Primera Vez

Si es tu primera vez, cambia tu contraseña:

1. Click en tu nombre (esquina superior derecha)
2. **Perfil**
3. **Cambiar Contraseña**
4. Ingresa contraseña actual y nueva contraseña
5. **Guardar**

---

## 📊 Navegación del Dashboard

### Componentes Principales

```
┌─────────────────────────────────────────────────────────┐
│  [Logo]  Dashboard IT           [Área ▼] [Período ▼]   │  ← Header
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐             │
│  │ Gráfico  │  │ Gráfico  │  │ Gráfico  │             │  ← Grid de
│  │    1     │  │    2     │  │    3     │             │    Gráficos
│  └──────────┘  └──────────┘  └──────────┘             │
│                                                          │
│  ┌──────────────────┐  ┌──────────────────┐           │
│  │    Gráfico 4     │  │    Gráfico 5     │           │
│  └──────────────────┘  └──────────────────┘           │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

### Header

- **Logo**: Click para volver al inicio
- **Selector de Área**: Cambiar entre Software, Infraestructura, Soporte, etc.
- **Selector de Período**: Ver métricas de diferentes meses/años
- **Usuario**: Acceder a perfil y cerrar sesión

---

## 🎨 Tipos de Gráficos

### 1. KPI Card (Tarjeta de Indicador)

Muestra un valor destacado con ícono y color.

```
┌─────────────────────────┐
│ 📊 Tickets Resueltos    │
│                         │
│        1,234            │
│                         │
└─────────────────────────┘
```

**Uso**: Ver valor actual de una métrica individual.

---

### 2. Barra de Progreso

Muestra el avance hacia un objetivo.

```
┌─────────────────────────┐
│ Disponibilidad Servidores│
│                         │
│ ████████████░░░  87%    │
│ Objetivo: 95%           │
└─────────────────────────┘
```

**Uso**: Ver qué tan cerca estás del objetivo.

**Colores**:
- 🟢 Verde: Objetivo alcanzado
- 🟡 Amarillo: 80-99% del objetivo
- 🔴 Rojo: Menos del 80%

---

### 3. Gráfico de Barras

Compara múltiples valores lado a lado.

```
┌─────────────────────────┐
│ Tickets por Prioridad   │
│                         │
│  ████ Alta              │
│  ██████ Media           │
│  ███ Baja               │
└─────────────────────────┘
```

**Uso**: Comparar diferentes categorías.

---

### 4. Gráfico de Líneas

Muestra tendencia a lo largo del tiempo.

```
┌─────────────────────────┐
│ Usuarios Activos        │
│     ╱╲                  │
│    ╱  ╲   ╱╲            │
│   ╱    ╲ ╱  ╲           │
│  ╱      ╲    ╲          │
└─────────────────────────┘
```

**Uso**: Ver evolución de una métrica.

---

### 5. Comparación (Actual vs Anterior)

Compara período actual con el anterior.

```
┌─────────────────────────┐
│ Ventas Mensuales        │
│                         │
│ Actual:    $50,000      │
│ Anterior:  $45,000  ↗️  │
│ Cambio:    +11.1%       │
└─────────────────────────┘
```

**Iconos**:
- ↗️ Aumento
- ↘️ Disminución
- → Sin cambio

---

### 6. Gráfico de Dona

Muestra distribución en porcentajes.

```
┌─────────────────────────┐
│ Canales de Soporte      │
│        ◯                │
│      ◯   ◯              │
│    ◯       ◯            │
│      ◯   ◯              │
│        ◯                │
└─────────────────────────┘
```

**Uso**: Ver proporción de cada categoría.

---

### 7. Velocímetro (Gauge)

Muestra valor en un rango con zonas de color.

```
┌─────────────────────────┐
│ Satisfacción Cliente    │
│        ╱───╲            │
│       │  85 │           │
│        ╲───╱            │
│   🔴  🟡  🟢            │
└─────────────────────────┘
```

**Uso**: Ver si métrica está en zona buena/mala.

---

### 8. Tabla de Datos

Lista de valores en formato tabla.

```
┌─────────────────────────┐
│ Top 5 Aplicaciones      │
│ CIC Virtual    10,049   │
│ App iOS         8,145   │
│ Web Portal      5,320   │
│ API REST        3,890   │
│ Dashboard       2,150   │
└─────────────────────────┘
```

**Uso**: Ver ranking o listado detallado.

---

## 🔄 Cambiar de Área

### Paso a Paso

1. En el header, localiza el **selector de área**
2. Click en el dropdown
3. Selecciona el área deseada:
   - 🔵 Software Factory
   - 🟢 Infraestructura
   - 🟠 Soporte Técnico
   - 🔴 Ciberseguridad
   - 🟣 Medios Digitales
4. El dashboard se recarga automáticamente

**Nota**: Cada área tiene su propio conjunto de métricas y gráficos.

---

## 📅 Cambiar de Período

### Paso a Paso

1. En el header, localiza el **selector de período**
2. Click en el dropdown
3. Selecciona el mes/año deseado:
   - Enero 2026
   - Febrero 2026
   - Marzo 2026
   - etc.
4. El dashboard se actualiza con los datos del período

### Ver Histórico

Para comparar diferentes períodos:

1. Toma nota de los valores del período actual
2. Cambia al período anterior
3. Compara visualmente

**Tip**: Los gráficos de "Comparación" hacen esto automáticamente.

---

## 🎨 Reorganizar Gráficos (Drag & Drop)

### Mover Gráficos

1. **Haz clic y mantén presionado** sobre el título de un gráfico
2. **Arrastra** a la nueva posición deseada
3. **Suelta** para colocar el gráfico

```
Antes:                    Después:
┌─────┐ ┌─────┐          ┌─────┐ ┌─────┐
│  A  │ │  B  │    →     │  B  │ │  A  │
└─────┘ └─────┘          └─────┘ └─────┘
```

### Cambiar Tamaño

1. **Coloca el cursor** en la esquina inferior derecha del gráfico
2. Aparecerá un **ícono de redimensión** (⌟)
3. **Arrastra** para cambiar el tamaño
4. **Suelta** cuando tengas el tamaño deseado

**Nota**: El sistema guarda tu configuración automáticamente.

---

## 📈 Interpretar Gráficos

### KPI con Objetivo

Si el gráfico muestra un objetivo:

```
┌─────────────────────────┐
│ Disponibilidad          │
│        98.5%            │
│ Objetivo: 95%      ✅   │
└─────────────────────────┘
```

- ✅ = Objetivo alcanzado
- ⚠️ = Cerca del objetivo
- ❌ = Por debajo del objetivo

### Tendencias

En gráficos de líneas:

- **Línea ascendente** (╱): Crecimiento
- **Línea descendente** (╲): Decrecimiento
- **Línea plana** (─): Estable

### Comparaciones

En gráficos de comparación:

```
Actual:    150
Anterior:  120
Cambio:    +25%  ↗️
```

- **+25%** = Aumento del 25%
- **Verde** = Crecimiento positivo
- **Rojo** = Decrecimiento

---

## 🔍 Ver Detalles de una Métrica

Algunos gráficos permiten ver más información:

1. **Pasa el mouse** sobre un gráfico
2. Aparecerá información adicional en un **tooltip**
3. En gráficos de barras/líneas, puedes ver valores exactos

**Ejemplo**:
```
[Gráfico de Barras]
Al pasar mouse sobre barra:
  ┌──────────────┐
  │ Enero: 1,234 │
  └──────────────┘
```

---

## 🖨️ Imprimir o Exportar

### Imprimir Dashboard

1. **Ctrl + P** (Windows) o **Cmd + P** (Mac)
2. Selecciona opciones de impresión
3. **Imprimir** o **Guardar como PDF**

### Captura de Pantalla

**Windows**:
- **Win + Shift + S**: Recorte de pantalla
- Selecciona el área del dashboard
- Se copia al portapapeles

**Mac**:
- **Cmd + Shift + 4**: Captura de área
- Click y arrastra sobre el dashboard

---

## ⚙️ Configuración Personal

### Cambiar Contraseña

1. Click en tu **nombre** (esquina superior derecha)
2. **Perfil**
3. **Cambiar Contraseña**
4. Ingresa:
   - Contraseña actual
   - Nueva contraseña
   - Confirmar nueva contraseña
5. **Guardar**

**Requisitos de contraseña**:
- Mínimo 8 caracteres
- Al menos 1 mayúscula
- Al menos 1 número
- Al menos 1 carácter especial

### Actualizar Datos de Perfil

1. Click en tu **nombre**
2. **Perfil**
3. Edita:
   - Nombre completo
   - Email
   - Foto de perfil
4. **Guardar Cambios**

---

## 🔐 Cerrar Sesión

### Paso a Paso

1. Click en tu **nombre** (esquina superior derecha)
2. **Cerrar Sesión**
3. Confirma si es necesario

**Nota**: Por seguridad, cierra sesión siempre que uses una computadora compartida.

---

## ❓ Preguntas Frecuentes

### ¿Por qué algunos gráficos están vacíos?

**R**: No hay datos capturados para ese período. Contacta al administrador para que ingrese los valores.

### ¿Puedo ver datos de años anteriores?

**R**: Sí, usa el selector de período y elige el mes/año deseado.

### ¿Se guardan mis cambios de layout?

**R**: Sí, cuando reorganizas gráficos, el sistema guarda tu configuración automáticamente.

### ¿Puedo agregar nuevos gráficos?

**R**: No, solo los administradores pueden crear gráficos. Solicita nuevos gráficos a tu administrador.

### ¿Cada cuánto se actualizan los datos?

**R**: Los datos se capturan mensualmente. Los valores se actualizan cuando el administrador ingresa nuevos datos.

### ¿Puedo exportar los datos a Excel?

**R**: Actualmente no hay exportación directa. Puedes copiar valores de las tablas o hacer captura de pantalla.

### ¿Qué significan las métricas con badge "AUTO"?

**R**: Son métricas calculadas automáticamente sumando otras métricas. No requieren ingreso manual.

### ¿Por qué veo "No hay datos disponibles"?

**R**: El administrador aún no ha capturado valores para ese período y área.

---

## 🆘 Soporte

### Contacto

Si encuentras problemas:

1. **Reporta al Administrador del Sistema**
2. Describe el problema:
   - ¿Qué estabas haciendo?
   - ¿Qué esperabas que sucediera?
   - ¿Qué sucedió en su lugar?
3. Incluye captura de pantalla si es posible

### Horarios de Soporte

- Lunes a Viernes: 8:00 AM - 5:00 PM
- Email: soporte@empresa.com
- Teléfono: +502 XXXX-XXXX

---

## 📚 Glosario

- **Área**: Departamento o división de TI (Software, Infraestructura, etc.)
- **Métrica**: Indicador que se mide (ej: Tickets resueltos, Disponibilidad)
- **Período**: Mes/año al que corresponden los datos
- **Objetivo**: Meta establecida para una métrica
- **Dashboard**: Tablero visual con todos los gráficos
- **KPI**: Key Performance Indicator (Indicador Clave de Desempeño)
- **Layout**: Distribución y posición de los gráficos en pantalla

---

## 🎓 Consejos y Mejores Prácticas

### Para Mejorar tu Experiencia

✅ **Usa pantalla completa**: Presiona F11 para maximizar el dashboard  
✅ **Revisa diariamente**: Mantente al tanto de las métricas actuales  
✅ **Compara períodos**: Usa el histórico para identificar tendencias  
✅ **Personaliza tu vista**: Reorganiza gráficos según tu prioridad  
✅ **Reporta anomalías**: Si ves datos extraños, notifica al administrador  

### Navegación Rápida

- **F5**: Recargar dashboard
- **Ctrl + F**: Buscar texto en página
- **Tab**: Navegar entre selectores
- **Escape**: Cerrar modales o tooltips

---

## 📝 Notas Importantes

⚠️ **No compartas tu contraseña** con nadie  
⚠️ **Cierra sesión** en computadoras compartidas  
⚠️ **Los datos son confidenciales** - No tomes capturas sin autorización  
⚠️ **Reporta errores** inmediatamente al administrador  

---

**Versión**: 1.0  
**Última actualización**: Abril 2026
<?php
/**
 * Test Ultra Minimalista - No depende de ningún archivo
 * Solo prueba PHP básico y detecta dónde está el error
 */

// Guardar errores en archivo de log
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/test-error.log');

// Forzar mostrar errores en pantalla
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Función para escribir en log Y mostrar
function log_and_echo($mensaje) {
    echo $mensaje . "<br>\n";
    error_log($mensaje);
    flush();
    ob_flush();
}

// Iniciar output buffering para capturar todo
ob_start();

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Test Ultra Minimalista</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #000; color: #0f0; }
        .ok { color: #0f0; }
        .error { color: #f00; }
        .warning { color: #ff0; }
    </style>
</head>
<body>
<h1>🔍 Test Ultra Minimalista</h1>
<pre>
<?php

log_and_echo("===========================================");
log_and_echo("INICIANDO TEST - " . date('Y-m-d H:i:s'));
log_and_echo("===========================================");
log_and_echo("");

// TEST 1: PHP funciona
log_and_echo("✓ TEST 1: PHP funciona");
log_and_echo("  Versión PHP: " . phpversion());
log_and_echo("");

// TEST 2: Directorio actual
log_and_echo("✓ TEST 2: Directorio");
log_and_echo("  __DIR__: " . __DIR__);
log_and_echo("  __FILE__: " . __FILE__);
log_and_echo("");

// TEST 3: Verificar archivos clave existen
log_and_echo("TEST 3: Verificar archivos existen");

$archivos_criticos = [
    'config.php',
    'includes/db.php',
    'includes/functions.php',
    'models/Model.php',
    'models/ValorMetrica.php',
    'models/Meta.php'
];

foreach ($archivos_criticos as $archivo) {
    $ruta = __DIR__ . '/' . $archivo;
    if (file_exists($ruta)) {
        $size = filesize($ruta);
        log_and_echo("  ✓ $archivo ($size bytes)");
    } else {
        log_and_echo("  ✗ $archivo NO EXISTE");
    }
}
log_and_echo("");

// TEST 4: Intentar cargar config.php
log_and_echo("TEST 4: Cargar config.php");
log_and_echo("  Intentando require_once 'config.php'...");

try {
    require_once 'config.php';
    log_and_echo("  ✓ config.php cargado sin errores");
} catch (Throwable $e) {
    log_and_echo("  ✗ ERROR en config.php:");
    log_and_echo("    Mensaje: " . $e->getMessage());
    log_and_echo("    Archivo: " . $e->getFile());
    log_and_echo("    Línea: " . $e->getLine());
    log_and_echo("");
    log_and_echo("===========================================");
    log_and_echo("DETENIÉNDOSE AQUÍ - config.php tiene errores");
    log_and_echo("===========================================");
    die();
}
log_and_echo("");

// TEST 5: Verificar constantes definidas
log_and_echo("TEST 5: Constantes de config.php");
$constantes = ['DB_HOST', 'DB_NAME', 'DB_USER', 'BASE_PATH', 'BASE_URL'];
foreach ($constantes as $const) {
    if (defined($const)) {
        $valor = constant($const);
        $valor_mostrar = ($const === 'DB_PASS') ? '***' : $valor;
        log_and_echo("  ✓ $const = $valor_mostrar");
    } else {
        log_and_echo("  ✗ $const NO DEFINIDA");
    }
}
log_and_echo("");

// TEST 6: Intentar cargar includes/db.php
log_and_echo("TEST 6: Cargar includes/db.php");
if (file_exists(__DIR__ . '/includes/db.php')) {
    try {
        require_once 'includes/db.php';
        log_and_echo("  ✓ db.php cargado");
    } catch (Throwable $e) {
        log_and_echo("  ✗ ERROR en db.php:");
        log_and_echo("    " . $e->getMessage());
        log_and_echo("    Línea: " . $e->getLine());
    }
} else {
    log_and_echo("  ✗ db.php NO EXISTE");
}
log_and_echo("");

// TEST 7: Intentar cargar includes/functions.php
log_and_echo("TEST 7: Cargar includes/functions.php");
if (file_exists(__DIR__ . '/includes/functions.php')) {
    try {
        require_once 'includes/functions.php';
        log_and_echo("  ✓ functions.php cargado");
        
        // Verificar funciones básicas
        $funciones = ['sanitize', 'isLoggedIn', 'getDB'];
        foreach ($funciones as $func) {
            if (function_exists($func)) {
                log_and_echo("    ✓ función $func() existe");
            } else {
                log_and_echo("    ✗ función $func() NO EXISTE");
            }
        }
    } catch (Throwable $e) {
        log_and_echo("  ✗ ERROR en functions.php:");
        log_and_echo("    " . $e->getMessage());
        log_and_echo("    Línea: " . $e->getLine());
    }
} else {
    log_and_echo("  ✗ functions.php NO EXISTE");
}
log_and_echo("");

// TEST 8: Intentar cargar Model.php
log_and_echo("TEST 8: Cargar models/Model.php");
if (file_exists(__DIR__ . '/models/Model.php')) {
    try {
        require_once 'models/Model.php';
        log_and_echo("  ✓ Model.php cargado");
        
        if (class_exists('Model')) {
            log_and_echo("    ✓ clase Model existe");
        }
    } catch (Throwable $e) {
        log_and_echo("  ✗ ERROR en Model.php:");
        log_and_echo("    " . $e->getMessage());
        log_and_echo("    Línea: " . $e->getLine());
    }
} else {
    log_and_echo("  ✗ Model.php NO EXISTE");
}
log_and_echo("");

// TEST 9: Intentar cargar ValorMetrica.php (EL SOSPECHOSO)
log_and_echo("TEST 9: Cargar models/ValorMetrica.php (CRÍTICO)");
if (file_exists(__DIR__ . '/models/ValorMetrica.php')) {
    $size = filesize(__DIR__ . '/models/ValorMetrica.php');
    log_and_echo("  Archivo existe ($size bytes)");
    log_and_echo("  Intentando cargar...");
    
    try {
        require_once 'models/ValorMetrica.php';
        log_and_echo("  ✓ ValorMetrica.php cargado sin errores");
        
        if (class_exists('ValorMetrica')) {
            log_and_echo("    ✓ clase ValorMetrica existe");
            
            // Intentar instanciarla
            try {
                $test = new ValorMetrica();
                log_and_echo("    ✓ ValorMetrica instanciada correctamente");
            } catch (Throwable $e) {
                log_and_echo("    ✗ ERROR al instanciar ValorMetrica:");
                log_and_echo("      " . $e->getMessage());
            }
        } else {
            log_and_echo("    ✗ clase ValorMetrica NO EXISTE después de cargar");
        }
        
    } catch (ParseError $e) {
        log_and_echo("  ✗ ERROR DE SINTAXIS en ValorMetrica.php:");
        log_and_echo("    Mensaje: " . $e->getMessage());
        log_and_echo("    Archivo: " . $e->getFile());
        log_and_echo("    Línea: " . $e->getLine());
        log_and_echo("");
        log_and_echo("  >>> ESTE ES EL PROBLEMA <<<");
        log_and_echo("  Hay un error de sintaxis PHP en ValorMetrica.php");
        log_and_echo("  Probablemente una llave mal cerrada o similar");
        
    } catch (Throwable $e) {
        log_and_echo("  ✗ ERROR en ValorMetrica.php:");
        log_and_echo("    Tipo: " . get_class($e));
        log_and_echo("    Mensaje: " . $e->getMessage());
        log_and_echo("    Archivo: " . $e->getFile());
        log_and_echo("    Línea: " . $e->getLine());
        log_and_echo("");
        log_and_echo("  Trace:");
        log_and_echo("    " . $e->getTraceAsString());
    }
} else {
    log_and_echo("  ✗ ValorMetrica.php NO EXISTE");
}
log_and_echo("");

// TEST 10: Intentar cargar Meta.php
log_and_echo("TEST 10: Cargar models/Meta.php");
if (file_exists(__DIR__ . '/models/Meta.php')) {
    try {
        require_once 'models/Meta.php';
        log_and_echo("  ✓ Meta.php cargado");
        
        if (class_exists('Meta')) {
            log_and_echo("    ✓ clase Meta existe");
        }
    } catch (Throwable $e) {
        log_and_echo("  ✗ ERROR en Meta.php:");
        log_and_echo("    " . $e->getMessage());
        log_and_echo("    Línea: " . $e->getLine());
    }
} else {
    log_and_echo("  ✗ Meta.php NO EXISTE");
}
log_and_echo("");

log_and_echo("===========================================");
log_and_echo("TEST COMPLETADO");
log_and_echo("===========================================");
log_and_echo("");
log_and_echo("NOTA: Revisa también el archivo test-error.log");
log_and_echo("ubicado en: " . __DIR__ . "/test-error.log");

?>
</pre>
</body>
</html>
<?php
$output = ob_get_clean();
echo $output;

// Guardar también en archivo
file_put_contents(__DIR__ . '/test-output.html', $output);
echo "<br><br>Salida guardada en: test-output.html";
?>